@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8

where py >nul 2>nul
if %errorlevel%==0 (
  set "PY_CMD=py -3"
) else (
  set "PY_CMD=python"
)

if not exist ".venv\Scripts\python.exe" (
  %PY_CMD% -m venv .venv
  if errorlevel 1 goto :error
)

".venv\Scripts\python.exe" "scripts\install_env.py"
if errorlevel 1 goto :error

echo.
echo 설치가 완료되었습니다.
goto :end

:error
echo.
echo 설치에 실패했습니다. logs 폴더의 최신 install 로그를 확인하세요.
:end
echo.
pause
endlocal
