from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

from huggingface_hub import get_token, hf_hub_download, whoami
from safetensors import safe_open

from constants import EXPECTED_CONFIGS, MODEL_REPOS
from prompts import ask_yes_no


def _hf_cli() -> str:
    name = "hf.exe" if os.name == "nt" else "hf"
    candidate = Path(sys.executable).parent / name
    return str(candidate) if candidate.exists() else name


def ensure_hf_token() -> str:
    token = get_token()
    if token:
        try:
            info = whoami(token=token)
            account = info.get("name") or info.get("fullname") or "unknown"
            print("Hugging Face 계정:", account)
            return token
        except Exception:
            token = None

    print("\nHugging Face 로그인이 필요합니다.")
    print("먼저 사용할 MuScriptor 모델 페이지에서 라이선스와 이용조건에 동의하세요.")
    result = subprocess.run(
        [_hf_cli(), "auth", "login", "--force"],
        env={**os.environ, "PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8"},
        check=False,
    )
    if result.returncode != 0:
        raise RuntimeError("Hugging Face 로그인에 실패했습니다.")
    token = get_token()
    if not token:
        raise RuntimeError("로그인 후 저장된 Hugging Face 토큰을 찾지 못했습니다.")
    return token


def _link_or_copy(source: Path, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists() or target.is_symlink():
        target.unlink()
    try:
        os.link(source, target)
    except OSError:
        shutil.copy2(source, target)


def validate_original(root: Path, size: str) -> tuple[bool, str]:
    model_dir = root / "models" / "original" / size
    weights = model_dir / "model.safetensors"
    config = model_dir / "config.json"
    if not weights.is_file() or not config.is_file():
        return False, "model.safetensors 또는 config.json이 없습니다."
    try:
        data = json.loads(config.read_text(encoding="utf-8"))
        for key, expected in EXPECTED_CONFIGS[size].items():
            if int(data[key]) != expected:
                return False, f"config.json의 {key}={data[key]} 값이 예상값 {expected}와 다릅니다."
        with safe_open(weights, framework="pt", device="cpu") as handle:
            keys = set(handle.keys())
        if not any(key.endswith("in_proj_weight") for key in keys):
            return False, "Attention 가중치를 찾지 못했습니다."
        if not any(key.endswith("linear1.weight") for key in keys):
            return False, "FFN 가중치를 찾지 못했습니다."
    except Exception as exc:
        return False, str(exc)
    return True, "정상"


def ensure_original(root: Path, size: str, *, ask: bool = True) -> tuple[Path, Path]:
    model_dir = root / "models" / "original" / size
    valid, reason = validate_original(root, size)
    if valid:
        print("원본 모델 확인:", model_dir)
        return model_dir / "model.safetensors", model_dir / "config.json"

    if model_dir.exists() and any(model_dir.iterdir()):
        print(f"원본 모델 구성 이상: {reason}")
        if ask and not ask_yes_no("원본 모델을 삭제하고 다시 받을까요?", True):
            raise RuntimeError("원본 모델 재설치를 취소했습니다.")
        shutil.rmtree(model_dir, ignore_errors=True)

    token = ensure_hf_token()
    repo = MODEL_REPOS[size]
    print(f"\n원본 모델 다운로드: {repo}")
    try:
        cached_weights = Path(
            hf_hub_download(repo_id=repo, filename="model.safetensors", token=token)
        )
        cached_config = Path(
            hf_hub_download(repo_id=repo, filename="config.json", token=token)
        )
    except Exception as exc:
        raise RuntimeError(
            f"{repo} 다운로드 실패: {exc}\n"
            "해당 모델 페이지에서 접근 승인을 받았는지, 로그인 계정이 같은지 확인하세요."
        ) from exc

    model_dir.mkdir(parents=True, exist_ok=True)
    _link_or_copy(cached_weights, model_dir / "model.safetensors")
    _link_or_copy(cached_config, model_dir / "config.json")

    valid, reason = validate_original(root, size)
    if not valid:
        raise RuntimeError(f"다운로드한 모델 검증 실패: {reason}")
    return model_dir / "model.safetensors", model_dir / "config.json"


def sha256_file(path: Path, chunk_size: int = 16 * 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def source_identity(weights: Path, config: Path) -> dict:
    """Return a stable source fingerprint, caching the expensive weight hash."""
    cache_path = weights.parent / "source_identity.json"
    stat = weights.stat()
    config_stat = config.stat()
    key = {
        "weights_bytes": stat.st_size,
        "weights_mtime_ns": stat.st_mtime_ns,
        "config_bytes": config_stat.st_size,
        "config_mtime_ns": config_stat.st_mtime_ns,
    }
    if cache_path.is_file():
        try:
            cached = json.loads(cache_path.read_text(encoding="utf-8"))
            if all(cached.get(k) == v for k, v in key.items()):
                return cached
        except Exception:
            pass

    print("원본 모델 식별 해시 계산 중입니다. 최초 파생 생성 때 한 번만 수행합니다.")
    identity = {
        **key,
        "weights_sha256": sha256_file(weights),
        "config_sha256": sha256_file(config),
    }
    cache_path.write_text(
        json.dumps(identity, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return identity
