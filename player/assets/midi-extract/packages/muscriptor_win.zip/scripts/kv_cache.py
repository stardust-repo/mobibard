from __future__ import annotations

import torch

_CONFIG = {"mode": "native", "group_size": 64, "storage_dtype": None}
_PATCHED = False
_ORIGINAL_INIT = None
_ORIGINAL_COMPLETE = None


def _quantize_q8(value: torch.Tensor, group_size: int):
    if value.shape[-1] % group_size != 0:
        raise RuntimeError(
            f"KV head dimension {value.shape[-1]} is not divisible by group_size={group_size}"
        )
    grouped = value.float().reshape(*value.shape[:-1], value.shape[-1] // group_size, group_size)
    max_abs = grouped.abs().amax(dim=-1, keepdim=True).clamp_min(1e-8)
    scale = (max_abs / 127.0).to(torch.float16)
    qvalue = torch.round(grouped / scale.float()).clamp(-127, 127).to(torch.int8)
    return qvalue, scale


def _dequantize_q8(qvalue: torch.Tensor, scale: torch.Tensor, dtype: torch.dtype):
    value = qvalue.to(dtype=dtype) * scale.to(dtype=dtype)
    return value.reshape(*qvalue.shape[:-2], qvalue.shape[-2] * qvalue.shape[-1])


def reset_kv_patch() -> None:
    global _PATCHED
    if not _PATCHED:
        _CONFIG.update(mode="native", storage_dtype=None)
        return
    from muscriptor.modules.transformer import StreamingMultiheadAttention

    StreamingMultiheadAttention.init_state = _ORIGINAL_INIT
    StreamingMultiheadAttention._complete_kv = _ORIGINAL_COMPLETE
    _CONFIG.update(mode="native", storage_dtype=None)
    _PATCHED = False


def configure_kv_cache(requested: str, token_dtype: torch.dtype) -> tuple[str, str]:
    """Patch only cache allocation/storage, preserving official v0.2.2 attention forward."""
    global _PATCHED, _ORIGINAL_INIT, _ORIGINAL_COMPLETE

    requested = requested.lower()
    if requested == "auto":
        requested = "fp16" if token_dtype == torch.float16 else "fp32"

    native = "fp16" if token_dtype == torch.float16 else "fp32"
    if requested == native:
        reset_kv_patch()
        return native, "official native cache"

    from muscriptor.modules.transformer import StreamingMultiheadAttention

    if not _PATCHED:
        _ORIGINAL_INIT = StreamingMultiheadAttention.init_state
        _ORIGINAL_COMPLETE = StreamingMultiheadAttention._complete_kv

    if requested == "q8":
        _CONFIG.update(mode="q8", group_size=64, storage_dtype=None)
    elif requested == "fp16":
        _CONFIG.update(mode="float", storage_dtype=torch.float16)
    elif requested == "fp32":
        _CONFIG.update(mode="float", storage_dtype=torch.float32)
    else:
        raise ValueError(f"지원하지 않는 KV 모드: {requested}")

    def init_state(self, batch_size: int, sequence_length: int):
        weight = self.in_proj_weight
        mode = _CONFIG["mode"]
        if mode == "q8":
            groups = self.dim_per_head // int(_CONFIG["group_size"])
            return {
                "cache_q": torch.zeros(
                    (2, batch_size, sequence_length, self.num_heads, groups, int(_CONFIG["group_size"])),
                    dtype=torch.int8,
                    device=weight.device,
                ),
                "cache_scale": torch.ones(
                    (2, batch_size, sequence_length, self.num_heads, groups, 1),
                    dtype=torch.float16,
                    device=weight.device,
                ),
                "offset": 0,
            }
        return {
            "cache": torch.empty(
                (2, batch_size, sequence_length, self.num_heads, self.dim_per_head),
                dtype=_CONFIG["storage_dtype"],
                device=weight.device,
            ),
            "offset": 0,
        }

    def complete_kv(self, k, v, state):
        if state is None:
            return k, v
        end = int(state["offset"])
        count = k.shape[1]
        if _CONFIG["mode"] == "q8":
            kq, ks = _quantize_q8(k, int(_CONFIG["group_size"]))
            vq, vs = _quantize_q8(v, int(_CONFIG["group_size"]))
            state["cache_q"][0, :, end : end + count] = kq
            state["cache_q"][1, :, end : end + count] = vq
            state["cache_scale"][0, :, end : end + count] = ks
            state["cache_scale"][1, :, end : end + count] = vs
            active_q = state["cache_q"][:, :, : end + count]
            active_s = state["cache_scale"][:, :, : end + count]
            return (
                _dequantize_q8(active_q[0], active_s[0], k.dtype),
                _dequantize_q8(active_q[1], active_s[1], v.dtype),
            )

        cache = state["cache"]
        cache[0, :, end : end + count] = k.to(cache.dtype)
        cache[1, :, end : end + count] = v.to(cache.dtype)
        active_k = cache[0, :, : end + count]
        active_v = cache[1, :, : end + count]
        if active_k.dtype != k.dtype:
            active_k = active_k.to(k.dtype)
            active_v = active_v.to(v.dtype)
        return active_k, active_v

    StreamingMultiheadAttention.init_state = init_state
    StreamingMultiheadAttention._complete_kv = complete_kv
    _PATCHED = True
    description = (
        "INT8+FP16 scale storage; dequantized before official SDPA"
        if requested == "q8"
        else f"{requested.upper()} storage; cast before official SDPA when needed"
    )
    return requested, description
