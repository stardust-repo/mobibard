from __future__ import annotations

import sys
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path
from typing import Any

try:
    import tomllib
except ModuleNotFoundError:  # Python 3.10 only
    import tomli as tomllib

VALID_MODELS = {"small", "medium", "large"}
VALID_PRECISIONS = {"auto", "fp32", "fp16", "q8"}
VALID_KV = {"auto", "fp32", "fp16", "q8"}

OVERLAP_DISABLED = Decimal("0.0")
OVERLAP_MIN = Decimal("0.0")
OVERLAP_MAX = Decimal("4.9")
OVERLAP_STEP = Decimal("0.1")
OVERLAP_DEFAULT = Decimal("1.0")


def _as_bool(value: Any, name: str) -> bool:
    if isinstance(value, bool):
        return value
    raise ValueError(f"{name}은 true 또는 false여야 합니다.")


def _setting_warning(message: str) -> None:
    print(f"[설정 경고] {message}", file=sys.stderr, flush=True)


def _normalise_overlap(value: Any) -> float:
    """Return a 0.1-step value clamped to 0.0..4.9 seconds.

    Zero selects the original MuScriptor boundary path.  Every positive
    0.1-second step enables overlap processing, up to a 4.9-second overlap
    (0.1-second stride for the fixed 5-second analysis window).
    """
    try:
        raw = Decimal(str(value).strip())
    except (InvalidOperation, ValueError):
        _setting_warning(
            f"decode.overlap_sec={value!r}은 숫자가 아닙니다. 기본값 {OVERLAP_DEFAULT}초를 사용합니다."
        )
        return float(OVERLAP_DEFAULT)

    if not raw.is_finite():
        _setting_warning(
            f"decode.overlap_sec={value!r}은 유한한 숫자가 아닙니다. 기본값 {OVERLAP_DEFAULT}초를 사용합니다."
        )
        return float(OVERLAP_DEFAULT)

    normalised = raw.quantize(OVERLAP_STEP, rounding=ROUND_HALF_UP)
    normalised = max(OVERLAP_MIN, min(OVERLAP_MAX, normalised))

    if normalised != raw:
        _setting_warning(
            "decode.overlap_sec는 0~4.9초 범위의 0.1초 단위여야 합니다. "
            f"입력값 {raw}초를 {normalised}초로 보정했습니다."
        )
    return float(normalised)


def load_settings(root: Path) -> dict:
    path = root / "settings.toml"
    if not path.is_file():
        raise FileNotFoundError(f"설정 파일을 찾지 못했습니다: {path}")
    with path.open("rb") as handle:
        data = tomllib.load(handle)

    server = data.setdefault("server", {})
    model = data.setdefault("model", {})
    decode = data.setdefault("decode", {})
    runtime = data.setdefault("runtime", {})

    server["host"] = str(server.get("host", "127.0.0.1")).strip() or "127.0.0.1"
    server["port"] = int(server.get("port", 8222))
    if not 1 <= server["port"] <= 65535:
        raise ValueError("server.port는 1~65535 범위여야 합니다.")
    server["open_browser"] = _as_bool(server.get("open_browser", True), "server.open_browser")

    name = str(model.get("name", "medium")).lower().strip()
    if name not in VALID_MODELS:
        raise ValueError("model.name은 small, medium, large 중 하나여야 합니다.")
    model["name"] = name

    model["backend"] = str(model.get("backend", "auto")).lower().strip()

    precision = str(model.get("precision", "fp16")).lower().strip()
    if precision not in VALID_PRECISIONS:
        raise ValueError("model.precision은 auto, fp32, fp16, q8 중 하나여야 합니다.")
    model["precision"] = precision

    kv = str(model.get("kv_cache", "fp16")).lower().strip()
    if kv not in VALID_KV:
        raise ValueError("model.kv_cache는 auto, fp32, fp16, q8 중 하나여야 합니다.")
    model["kv_cache"] = kv

    # Prelude forcing is now selected automatically from overlap_sec + batch_size.
    decode.pop("prelude_forcing", None)
    decode["overlap_sec"] = _normalise_overlap(decode.get("overlap_sec", 1.0))

    batch = int(decode.get("batch_size", 6))
    if batch < 1:
        raise ValueError("decode.batch_size는 1 이상이어야 합니다.")
    decode["batch_size"] = batch

    instruments = decode.get("instruments", [])
    if not isinstance(instruments, list) or not all(isinstance(item, str) for item in instruments):
        raise ValueError("decode.instruments는 문자열 배열이어야 합니다.")
    decode["instruments"] = [item.strip() for item in instruments if item.strip()]

    decode["sampling"] = _as_bool(decode.get("sampling", False), "decode.sampling")
    temperature = float(decode.get("temperature", 1.0))
    if temperature <= 0:
        raise ValueError("decode.temperature는 0보다 커야 합니다.")
    decode["temperature"] = temperature

    guidance = float(decode.get("guidance_weight", 1.0))
    if guidance <= 0:
        raise ValueError("decode.guidance_weight는 0보다 커야 합니다.")
    decode["guidance_weight"] = guidance

    beam = int(decode.get("beam_size", 1))
    if beam < 1:
        raise ValueError("decode.beam_size는 1 이상이어야 합니다.")
    if decode["sampling"] and beam > 1:
        raise ValueError("sampling=true와 beam_size>1은 함께 사용하지 마세요.")
    if kv == "q8" and beam > 1:
        raise ValueError("Q8 KV 캐시는 beam_size=1만 지원합니다.")
    decode["beam_size"] = beam
    decode["strict_eos"] = _as_bool(decode.get("strict_eos", False), "decode.strict_eos")

    runtime["ask_fallback"] = _as_bool(runtime.get("ask_fallback", True), "runtime.ask_fallback")
    runtime["rebuild_invalid_derived"] = _as_bool(
        runtime.get("rebuild_invalid_derived", True), "runtime.rebuild_invalid_derived"
    )

    return data
