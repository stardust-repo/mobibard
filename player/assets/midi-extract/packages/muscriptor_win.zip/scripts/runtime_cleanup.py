from __future__ import annotations

import gc
import threading


def close_iterator(iterator) -> None:
    """Close a generator/iterator when it exposes close(), suppressing cleanup errors."""
    if iterator is None:
        return
    close = getattr(iterator, "close", None)
    if not callable(close):
        return
    try:
        close()
    except BaseException as exc:
        print(f"[memory-cleanup] iterator close warning: {exc}", flush=True)


def _backend_name(model) -> str:
    return str(getattr(model, "_effective_backend", "")).lower()


def _cuda_stats(torch) -> tuple[int, int]:
    if not torch.cuda.is_available():
        return 0, 0
    return int(torch.cuda.memory_allocated()), int(torch.cuda.memory_reserved())


def _format_mib(value: int) -> str:
    return f"{value / (1024 * 1024):.1f} MiB"


def _module_cuda_bytes(core) -> int:
    """Count registered model parameters and buffers that still live on CUDA."""
    if core is None:
        return 0
    total = 0
    try:
        for tensor in list(core.parameters()) + list(core.buffers()):
            if getattr(getattr(tensor, "device", None), "type", None) == "cuda":
                total += int(tensor.numel()) * int(tensor.element_size())
    except Exception:
        return -1
    return total


def _set_device_attribute(target, name: str, value) -> None:
    try:
        if hasattr(target, name):
            setattr(target, name, value)
    except Exception:
        pass


def _cuda_core_module(model):
    try:
        import torch

        core = getattr(model, "_model", None)
        if isinstance(core, torch.nn.Module):
            return core
        if isinstance(model, torch.nn.Module):
            return model
    except Exception:
        return None
    return None


def restore_cuda_model(model, *, reason: str = "변환 준비") -> bool:
    """Move an offloaded CUDA model back to GPU before the next run.

    The custom Windows backend keeps its audio conditioners on CPU.  A normal
    ``Module.to(cuda)`` would move those too, so restore that hybrid placement
    after moving the token model.
    """
    if "cuda" not in _backend_name(model):
        return False
    if not bool(getattr(model, "_convenience_cuda_offloaded", False)):
        return False

    import torch

    lock = getattr(model, "_convenience_memory_lock", None)
    if lock is None:
        lock = threading.RLock()
        setattr(model, "_convenience_memory_lock", lock)

    with lock:
        if not bool(getattr(model, "_convenience_cuda_offloaded", False)):
            return False
        core = _cuda_core_module(model)
        if core is None:
            return False

        cuda = torch.device("cuda")
        cpu = torch.device("cpu")
        print(f"[memory-cleanup] CUDA model restoring ({reason})...", flush=True)
        core.to(cuda)

        # Restore the custom hybrid condition provider: feature extraction stays
        # on CPU and only its encoded result is copied to the token-model device.
        provider = getattr(core, "condition_provider", None)
        provider_base = getattr(provider, "base", None)
        if isinstance(provider_base, torch.nn.Module) and hasattr(provider, "target"):
            provider_base.to(cpu)
            _set_device_attribute(provider, "target", cuda)
            _set_device_attribute(provider, "device", cpu)

        _set_device_attribute(core, "device", cuda)
        _set_device_attribute(model, "_device", cuda)
        torch.cuda.synchronize()
        setattr(model, "_convenience_cuda_offloaded", False)
        allocated, reserved = _cuda_stats(torch)
        print(
            "[memory-cleanup] CUDA model restored "
            f"({reason}) - allocated={_format_mib(allocated)}, "
            f"reserved={_format_mib(reserved)}",
            flush=True,
        )
        return True


def offload_cuda_model(model, *, reason: str) -> bool:
    """Move resident model weights to CPU and return CUDA memory to the driver.

    ``torch.cuda.empty_cache()`` cannot release live model parameters.  This
    routine therefore offloads the actual model module after a run has fully
    stopped.  The next transcription restores it automatically.
    """
    if "cuda" not in _backend_name(model):
        return False

    import torch

    if not torch.cuda.is_available():
        return False

    lock = getattr(model, "_convenience_memory_lock", None)
    if lock is None:
        lock = threading.RLock()
        setattr(model, "_convenience_memory_lock", lock)

    with lock:
        before_allocated, before_reserved = _cuda_stats(torch)
        core = _cuda_core_module(model)
        before_model_cuda = _module_cuda_bytes(core)
        if core is not None and not bool(
            getattr(model, "_convenience_cuda_offloaded", False)
        ):
            torch.cuda.synchronize()
            core.to(torch.device("cpu"))
            _set_device_attribute(core, "device", torch.device("cpu"))
            _set_device_attribute(model, "_device", torch.device("cpu"))
            provider = getattr(core, "condition_provider", None)
            _set_device_attribute(provider, "target", torch.device("cpu"))
            _set_device_attribute(provider, "device", torch.device("cpu"))
            setattr(model, "_convenience_cuda_offloaded", True)

        # Drop Python references first, wait for queued CUDA work, then return
        # both allocator and CUDA IPC caches.  A second collection catches
        # tensors finalized by generator/frame destruction during the first pass.
        gc.collect()
        torch.cuda.synchronize()
        torch.cuda.empty_cache()
        ipc_collect = getattr(torch.cuda, "ipc_collect", None)
        if callable(ipc_collect):
            ipc_collect()
        gc.collect()
        torch.cuda.empty_cache()

        after_allocated, after_reserved = _cuda_stats(torch)
        after_model_cuda = _module_cuda_bytes(core)
        print(
            "[memory-cleanup] CUDA model offloaded to CPU "
            f"({reason}) - allocated {_format_mib(before_allocated)} -> "
            f"{_format_mib(after_allocated)}, reserved "
            f"{_format_mib(before_reserved)} -> {_format_mib(after_reserved)}, "
            f"model_cuda {_format_mib(max(0, before_model_cuda))} -> "
            f"{_format_mib(max(0, after_model_cuda))}",
            flush=True,
        )
        if after_model_cuda > 0:
            print(
                "[memory-cleanup] warning: registered model tensors remain on CUDA "
                f"({_format_mib(after_model_cuda)})",
                flush=True,
            )
        if after_allocated > 64 * 1024 * 1024 and after_model_cuda == 0:
            print(
                "[memory-cleanup] warning: CUDA allocations remain after model "
                "offload; a live generator/tensor reference may still exist",
                flush=True,
            )
        if after_allocated == 0 and after_reserved == 0:
            print(
                "[memory-cleanup] PyTorch CUDA allocator fully released; "
                "a small driver-context baseline may remain visible",
                flush=True,
            )
        return True


def cleanup_backend_cache(model, *, reason: str, offload_model: bool = False) -> None:
    """Release run memory; optionally offload live CUDA weights to CPU."""
    backend = _backend_name(model)

    if backend.startswith("mlx"):
        gc.collect()
        try:
            import mlx.core as mx

            mx.clear_cache()
            print(f"[memory-cleanup] MLX cache cleared ({reason})", flush=True)
        except BaseException as exc:
            print(f"[memory-cleanup] MLX cache warning: {exc}", flush=True)
        return

    if "cuda" in backend:
        try:
            if offload_model:
                offload_cuda_model(model, reason=reason)
                return

            import torch

            if torch.cuda.is_available():
                before_allocated, before_reserved = _cuda_stats(torch)
                gc.collect()
                torch.cuda.synchronize()
                torch.cuda.empty_cache()
                ipc_collect = getattr(torch.cuda, "ipc_collect", None)
                if callable(ipc_collect):
                    ipc_collect()
                after_allocated, after_reserved = _cuda_stats(torch)
                print(
                    f"[memory-cleanup] CUDA cache cleared ({reason}) - "
                    f"allocated {_format_mib(before_allocated)} -> "
                    f"{_format_mib(after_allocated)}, reserved "
                    f"{_format_mib(before_reserved)} -> {_format_mib(after_reserved)}",
                    flush=True,
                )
        except BaseException as exc:
            print(f"[memory-cleanup] CUDA cache warning: {exc}", flush=True)
        return

    if "mps" in backend:
        gc.collect()
        try:
            import torch

            empty_cache = getattr(getattr(torch, "mps", None), "empty_cache", None)
            if callable(empty_cache):
                empty_cache()
                print(f"[memory-cleanup] MPS cache cleared ({reason})", flush=True)
        except BaseException as exc:
            print(f"[memory-cleanup] MPS cache warning: {exc}", flush=True)
