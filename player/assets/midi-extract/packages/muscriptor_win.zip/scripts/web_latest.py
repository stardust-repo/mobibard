from __future__ import annotations

import hashlib
import json
import os
import shutil
import sys
from importlib.resources import files
from pathlib import Path

from constants import WEB_PATCH_SCHEMA, WEB_RUNTIME_COMMIT


def _default_cache_root() -> Path:
    home = Path.home()
    if os.name == "nt":
        base = Path(os.environ.get("LOCALAPPDATA", home / "AppData" / "Local"))
    elif sys.platform == "darwin":
        base = home / "Library" / "Caches"
    else:
        base = Path(os.environ.get("XDG_CACHE_HOME", home / ".cache"))
    return base / "MuScriptorConvenience" / "web"


CACHE_ROOT = _default_cache_root()
PATCH_MARKER = "muscriptor-convenience-client-cancel-bridge"
PATCH_SIGNATURE = (
    f"{PATCH_MARKER}:{WEB_RUNTIME_COMMIT}:schema={WEB_PATCH_SCHEMA}"
)

# Keep this as a plain template rather than an f-string.  The JavaScript can
# then use normal braces, and changing any bridge logic automatically changes
# PATCH_SHA256 below.  The digest is part of the cache directory and marker, so
# a previously-generated web_dist can never hide a newer client patch.
_CLIENT_BRIDGE_TEMPLATE = r'''(() => {
  const patchSignature = "__PATCH_SIGNATURE__";
  if (window.__muscriptorConveniencePatch === patchSignature) return;
  window.__muscriptorConveniencePatch = patchSignature;

  let clientId = null;
  try {
    clientId = sessionStorage.getItem("muscriptor-convenience-client-id");
  } catch (_error) {
    // sessionStorage can be unavailable under hardened browser settings.
  }
  if (!clientId) {
    clientId =
      typeof crypto !== "undefined" && "randomUUID" in crypto
        ? crypto.randomUUID()
        : `c-${Math.floor(performance.now())}-${Math.random().toString(36).slice(2)}`;
    try {
      sessionStorage.setItem("muscriptor-convenience-client-id", clientId);
    } catch (_error) {
      // The in-memory id still scopes this page load correctly.
    }
  }

  const originalFetch = window.fetch.bind(window);
  let nextRunId = 0;
  let activeRun = null;

  function requestUrl(input) {
    const raw =
      typeof Request !== "undefined" && input instanceof Request
        ? input.url
        : String(input);
    return new URL(raw, window.location.href);
  }

  function requestSignal(input, init) {
    if (init && init.signal) return init.signal;
    if (typeof Request !== "undefined" && input instanceof Request) {
      return input.signal;
    }
    return null;
  }

  function fetchWithClientId(input, init) {
    const headers = new Headers(
      typeof Request !== "undefined" && input instanceof Request
        ? input.headers
        : undefined,
    );
    if (init && init.headers) {
      new Headers(init.headers).forEach((value, key) => headers.set(key, value));
    }
    headers.set("X-Client-Id", clientId);
    headers.set("X-MuScriptor-Web-Patch", patchSignature);

    if (typeof Request !== "undefined" && input instanceof Request) {
      const request = new Request(input, { ...(init || {}), headers });
      return originalFetch(request);
    }
    return originalFetch(input, { ...(init || {}), headers });
  }

  function cleanupRun(run, reason) {
    if (run && run.cleanupSent) return run.cleanupPromise || Promise.resolve(null);
    if (run) run.cleanupSent = true;

    const headers = new Headers();
    headers.set("X-Client-Id", clientId);
    headers.set("X-Cancel-Reason", reason);
    headers.set("X-MuScriptor-Web-Patch", patchSignature);

    console.info(`[MuScriptor] requesting server cleanup (${reason})`);
    const request = originalFetch("/transcribe/cancel", {
      method: "POST",
      headers,
      keepalive: true,
      cache: "no-store",
    })
      .then(async (response) => {
        const result = await response.json();
        console.info("[MuScriptor] cleanup result", result);
        if (run && activeRun === run && result && result.stopped) activeRun = null;
        return result;
      })
      .catch((error) => {
        console.warn("[MuScriptor] cleanup request failed", error);
        return null;
      });

    if (run) run.cleanupPromise = request;
    return request;
  }

  window.fetch = function(input, init) {
    try {
      const url = requestUrl(input);
      const sameOrigin = url.origin === window.location.origin;
      const isTranscribe =
        sameOrigin &&
        (url.pathname === "/transcribe" || url.pathname === "/transcribe/midi");

      if (isTranscribe) {
        let run = null;
        const signal = requestSignal(input, init);
        if (url.pathname === "/transcribe") {
          run = {
            id: ++nextRunId,
            signal,
            cleanupSent: false,
            cleanupPromise: null,
          };
          activeRun = run;

          const onAbort = () => cleanupRun(run, "abort-signal");
          if (signal) {
            if (signal.aborted) queueMicrotask(onAbort);
            else signal.addEventListener("abort", onAbort, { once: true });
          }
        }

        const request = fetchWithClientId(input, init);
        if (!run) return request;
        return Promise.resolve(request).catch((error) => {
          if ((run.signal && run.signal.aborted) || error?.name === "AbortError") {
            cleanupRun(run, "fetch-abort");
          }
          throw error;
        });
      }
    } catch (_error) {
      // Preserve the official UI request when URL/header inspection is unavailable.
    }
    return originalFetch(input, init);
  };

  function elementFromEventTarget(target) {
    if (target instanceof Element) return target;
    if (target && target.parentElement instanceof Element) return target.parentElement;
    return null;
  }

  function controlLabel(control) {
    return [
      control.textContent,
      control.getAttribute("aria-label"),
      control.getAttribute("title"),
      "value" in control ? control.value : null,
    ]
      .filter(Boolean)
      .join(" ")
      .replace(/\s+/g, " ")
      .trim()
      .toLowerCase();
  }

  function isAnotherFileControl(control) {
    return controlLabel(control).includes("transcribe another file");
  }

  function cleanupAfterAcceptedUiReset(control, reason) {
    // React's handler asks for confirmation first.  Run after it has committed
    // the welcome screen, and do nothing when the user cancelled the dialog.
    setTimeout(() => {
      const resetWasAccepted =
        !control.isConnected || !isAnotherFileControl(control);
      if (resetWasAccepted) cleanupRun(activeRun, reason);
    }, 0);
  }

  document.addEventListener("click", (event) => {
    const origin = elementFromEventTarget(event.target);
    const control = origin?.closest('button, [role="button"], a, input');
    if (!control || !isAnotherFileControl(control)) return;
    cleanupAfterAcceptedUiReset(control, "ui-reset-click");
  });

  document.addEventListener("keydown", (event) => {
    if (event.key !== "Enter" && event.key !== " ") return;
    const origin = elementFromEventTarget(event.target);
    const control = origin?.closest('button, [role="button"], a, input');
    if (!control || !isAnotherFileControl(control)) return;
    cleanupAfterAcceptedUiReset(control, "ui-reset-keyboard");
  });

  window.addEventListener("pagehide", () => {
    if (activeRun) cleanupRun(activeRun, "pagehide");
  });

  window.__muscriptorConvenience = {
    patchSignature,
    clientId,
    cancelCurrent: () => cleanupRun(activeRun, "manual"),
  };
  console.info(`[MuScriptor] cancellation bridge active: ${patchSignature}`);
})();
'''

_CLIENT_BRIDGE_JAVASCRIPT = _CLIENT_BRIDGE_TEMPLATE.replace(
    "__PATCH_SIGNATURE__", PATCH_SIGNATURE
)
PATCH_SHA256 = hashlib.sha256(
    _CLIENT_BRIDGE_JAVASCRIPT.encode("utf-8")
).hexdigest()
CLIENT_SCRIPT_NAME = f"muscriptor-convenience-{PATCH_SHA256[:12]}.js"
CLIENT_SCRIPT_TAG = (
    f'<script src="/{CLIENT_SCRIPT_NAME}" '
    f'data-muscriptor-convenience-patch="{PATCH_SIGNATURE}"></script>'
)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def official_web_dir() -> Path | None:
    candidate = Path(str(files("muscriptor").joinpath("web_dist")))
    return candidate if candidate.is_dir() else None


def _patch_index_text(text: str) -> str:
    if PATCH_SIGNATURE in text or CLIENT_SCRIPT_NAME in text:
        return text
    # Use a same-origin external script rather than inline JavaScript.  This
    # survives a restrictive Content-Security-Policy and executes before the
    # deferred/module application bundle starts.
    if "<head>" in text:
        return text.replace("<head>", "<head>\n" + CLIENT_SCRIPT_TAG, 1)
    if "</head>" in text:
        return text.replace("</head>", CLIENT_SCRIPT_TAG + "\n</head>", 1)
    if "</body>" in text:
        return text.replace("</body>", CLIENT_SCRIPT_TAG + "\n</body>", 1)
    return text + "\n" + CLIENT_SCRIPT_TAG


def _remove_stale_web_dirs(destination: Path) -> None:
    """Remove old convenience web copies after selecting a new patch digest."""
    for candidate in CACHE_ROOT.glob(f"web_dist_{WEB_RUNTIME_COMMIT[:7]}*"):
        if candidate == destination or not candidate.is_dir():
            continue
        try:
            shutil.rmtree(candidate)
        except OSError:
            # A running older process may still have a file open on Windows.
            pass


def prepare_web_dir() -> Path | None:
    """Copy the official web build and install the cancellation/client bridge.

    The cache key includes both a schema and the full external-script digest.
    This prevents an older cached index.html from silently surviving a package
    update merely because the upstream web commit did not change.
    """
    source = official_web_dir()
    if source is None:
        return None

    source_index = source / "index.html"
    if not source_index.is_file():
        return None

    CACHE_ROOT.mkdir(parents=True, exist_ok=True)
    destination = CACHE_ROOT / (
        f"web_dist_{WEB_RUNTIME_COMMIT[:7]}_p{WEB_PATCH_SCHEMA}_{PATCH_SHA256[:10]}"
    )
    marker_path = destination / ".muscriptor_convenience_web.json"
    expected = {
        "web_runtime_commit": WEB_RUNTIME_COMMIT,
        "patch_schema": WEB_PATCH_SCHEMA,
        "patch_signature": PATCH_SIGNATURE,
        "patch_sha256": PATCH_SHA256,
        "client_script_name": CLIENT_SCRIPT_NAME,
        "source_index_sha256": _sha256(source_index),
    }

    try:
        current = json.loads(marker_path.read_text(encoding="utf-8"))
        patched_index = destination / "index.html"
        client_script = destination / CLIENT_SCRIPT_NAME
        if (
            current == expected
            and patched_index.is_file()
            and client_script.is_file()
            and CLIENT_SCRIPT_NAME in patched_index.read_text(encoding="utf-8")
            and _sha256(client_script) == PATCH_SHA256
        ):
            _remove_stale_web_dirs(destination)
            return destination
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        pass

    temporary = destination.with_name(destination.name + "_building")
    if temporary.exists():
        shutil.rmtree(temporary)
    shutil.copytree(source, temporary)
    index_path = temporary / "index.html"
    index_text = index_path.read_text(encoding="utf-8")
    index_path.write_text(_patch_index_text(index_text), encoding="utf-8")
    (temporary / CLIENT_SCRIPT_NAME).write_text(
        _CLIENT_BRIDGE_JAVASCRIPT, encoding="utf-8"
    )
    (temporary / ".muscriptor_convenience_web.json").write_text(
        json.dumps(expected, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    if destination.exists():
        shutil.rmtree(destination)
    temporary.rename(destination)
    _remove_stale_web_dirs(destination)
    return destination
