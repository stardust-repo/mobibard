from __future__ import annotations

import hashlib
import json
import os
import shutil
import sys
from importlib.resources import files
from pathlib import Path

from constants import WEB_PATCH_SCHEMA, WEB_RUNTIME_COMMIT

def _default_cache_root() -> Path:
    home = Path.home()
    if os.name == "nt":
        base = Path(os.environ.get("LOCALAPPDATA", home / "AppData" / "Local"))
    elif sys.platform == "darwin":
        base = home / "Library" / "Caches"
    else:
        base = Path(os.environ.get("XDG_CACHE_HOME", home / ".cache"))
    return base / "MuScriptorConvenience" / "web"


CACHE_ROOT = _default_cache_root()
PATCH_MARKER = "muscriptor-convenience-client-id-patch"

_CLIENT_ID_SCRIPT = rf'''<!-- {PATCH_MARKER}:{WEB_RUNTIME_COMMIT} -->
<script>
(() => {{
  if (window.__muscriptorConvenienceClientIdPatch) return;
  window.__muscriptorConvenienceClientIdPatch = true;

  const clientId =
    typeof crypto !== "undefined" && "randomUUID" in crypto
      ? crypto.randomUUID()
      : `c-${{Math.floor(performance.now())}}-${{Math.random().toString(36).slice(2)}}`;
  const originalFetch = window.fetch;

  window.fetch = function(input, init) {{
    try {{
      const rawUrl = input instanceof Request ? input.url : String(input);
      const url = new URL(rawUrl, window.location.href);
      const isTranscribe =
        url.origin === window.location.origin &&
        (url.pathname === "/transcribe" || url.pathname === "/transcribe/midi");

      if (isTranscribe) {{
        const headers = new Headers(input instanceof Request ? input.headers : undefined);
        if (init && init.headers) {{
          new Headers(init.headers).forEach((value, key) => headers.set(key, value));
        }}
        headers.set("X-Client-Id", clientId);

        if (input instanceof Request) {{
          const request = new Request(input, {{ ...(init || {{}}), headers }});
          return originalFetch.call(this, request);
        }}
        return originalFetch.call(this, input, {{ ...(init || {{}}), headers }});
      }}
    }} catch (_error) {{
      // Preserve the official UI request when URL inspection is unavailable.
    }}
    return originalFetch.call(this, input, init);
  }};
}})();
</script>
'''


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def official_web_dir() -> Path | None:
    candidate = Path(str(files("muscriptor").joinpath("web_dist")))
    return candidate if candidate.is_dir() else None


def _patch_index_text(text: str) -> str:
    if PATCH_MARKER in text:
        return text
    if "</head>" in text:
        return text.replace("</head>", _CLIENT_ID_SCRIPT + "\n</head>", 1)
    if "</body>" in text:
        return text.replace("</body>", _CLIENT_ID_SCRIPT + "\n</body>", 1)
    return text + "\n" + _CLIENT_ID_SCRIPT


def prepare_web_dir() -> Path | None:
    """Copy the official 0.2.2 web build and apply the latest-main client id fix.

    MuScriptor's post-release c3b82e7 server change expects a stable
    X-Client-Id per browser tab.  The PyPI 0.2.2 wheel contains the preceding
    built frontend, so this injects the equivalent header behavior without
    requiring Node/pnpm on the user's machine.
    """
    source = official_web_dir()
    if source is None:
        return None

    source_index = source / "index.html"
    if not source_index.is_file():
        return None

    CACHE_ROOT.mkdir(parents=True, exist_ok=True)
    destination = CACHE_ROOT / f"web_dist_{WEB_RUNTIME_COMMIT[:7]}"
    marker_path = destination / ".muscriptor_convenience_web.json"
    expected = {
        "web_runtime_commit": WEB_RUNTIME_COMMIT,
        "patch_schema": WEB_PATCH_SCHEMA,
        "source_index_sha256": _sha256(source_index),
    }

    try:
        current = json.loads(marker_path.read_text(encoding="utf-8"))
        patched_index = destination / "index.html"
        if (
            current == expected
            and patched_index.is_file()
            and PATCH_MARKER in patched_index.read_text(encoding="utf-8")
        ):
            return destination
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        pass

    temporary = destination.with_name(destination.name + "_building")
    if temporary.exists():
        shutil.rmtree(temporary)
    shutil.copytree(source, temporary)
    index_path = temporary / "index.html"
    index_text = index_path.read_text(encoding="utf-8")
    index_path.write_text(_patch_index_text(index_text), encoding="utf-8")
    (temporary / ".muscriptor_convenience_web.json").write_text(
        json.dumps(expected, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    if destination.exists():
        shutil.rmtree(destination)
    temporary.rename(destination)
    return destination
