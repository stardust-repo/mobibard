from __future__ import annotations

import importlib.metadata
import inspect
from pathlib import Path

from constants import UPSTREAM_VERSION


def verify_upstream() -> None:
    try:
        installed = importlib.metadata.version("muscriptor")
    except importlib.metadata.PackageNotFoundError as exc:
        raise RuntimeError("MuScriptor가 설치되어 있지 않습니다. 먼저 설치 스크립트를 실행하세요.") from exc
    if installed != UPSTREAM_VERSION:
        raise RuntimeError(
            f"이 패키지는 muscriptor=={UPSTREAM_VERSION} 전용입니다. "
            f"현재 설치 버전은 {installed}입니다. 설치 스크립트를 다시 실행하세요."
        )

    from muscriptor import TranscriptionModel
    from muscriptor.events import OpenNoteTracker
    from muscriptor.tokenizer.mt3 import MT3Tokenizer

    params = inspect.signature(TranscriptionModel.transcribe).parameters
    if "prelude_forcing" not in params:
        raise RuntimeError("설치된 MuScriptor에 prelude_forcing API가 없습니다.")
    if not hasattr(TranscriptionModel, "transcribe_to_midi"):
        raise RuntimeError("설치된 MuScriptor에 transcribe_to_midi API가 없습니다.")
    if not hasattr(TranscriptionModel, "detect_beat_grid_for"):
        raise RuntimeError("설치된 MuScriptor에 v0.3.0 비트 감지 API가 없습니다.")
    midi_params = inspect.signature(TranscriptionModel.events_to_midi_bytes).parameters
    if "beat_grid" not in midi_params:
        raise RuntimeError("설치된 MuScriptor의 MIDI 직렬화 API에 beat_grid가 없습니다.")
    transcribe_midi_params = inspect.signature(TranscriptionModel.transcribe_to_midi).parameters
    if "detect_tempo" not in transcribe_midi_params:
        raise RuntimeError("설치된 MuScriptor의 transcribe_to_midi API에 detect_tempo가 없습니다.")
    tokenizer = MT3Tokenizer(instrument_vocabulary="MT3_FULL_PLUS", max_shift_steps=1001)
    if not hasattr(tokenizer, "forbidden_token_ids") or not hasattr(tokenizer, "tie_section_token_ids"):
        raise RuntimeError("설치된 토크나이저 API가 v0.3.0과 일치하지 않습니다.")
    if OpenNoteTracker is None:  # pragma: no cover
        raise RuntimeError("OpenNoteTracker를 불러오지 못했습니다.")

    # MuScriptor v0.2.2 documents synchronize() as a CPU no-op, but with
    # PyTorch >= 2.6 its implementation calls torch.accelerator.synchronize()
    # even when no accelerator exists. Keep CPU fallback usable without
    # changing any GPU path.
    import muscriptor.accelerator as accelerator

    if not accelerator.is_available():
        accelerator.synchronize = lambda: None


def find_web_dir() -> Path | None:
    from web_latest import prepare_web_dir

    return prepare_web_dir()
