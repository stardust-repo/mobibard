from __future__ import annotations

import importlib.metadata
import os
import shutil
import subprocess
import sys
import traceback
from datetime import datetime
from pathlib import Path

from constants import UPSTREAM_VERSION

ROOT = Path(__file__).resolve().parents[1]
LOG_DIR = ROOT / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)
LOG_PATH = LOG_DIR / f"install_{datetime.now():%Y%m%d_%H%M%S}.log"


def run(command: list[str], *, allow_failure: bool = False) -> bool:
    print("\n>", " ".join(command))
    with LOG_PATH.open("a", encoding="utf-8") as log:
        log.write("\n> " + " ".join(command) + "\n")
        process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            env={**os.environ, "PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8"},
        )
        assert process.stdout is not None
        for line in process.stdout:
            print(line, end="")
            log.write(line)
        code = process.wait()
    if code != 0 and not allow_failure:
        raise RuntimeError(f"명령 실패({code}): {' '.join(command)}")
    return code == 0


def version_of(name: str) -> str:
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return "미설치"


def main() -> int:
    if sys.version_info < (3, 10):
        raise RuntimeError("Python 3.10 이상이 필요합니다.")

    print("Python:", sys.version.replace("\n", " "))
    print("실행 파일:", sys.executable)
    print("설치 로그:", LOG_PATH)
    pip = [sys.executable, "-m", "pip"]
    run(pip + ["install", "--upgrade", "pip", "setuptools", "wheel"])

    cuda_ok = False
    if shutil.which("nvidia-smi"):
        cuda_ok = run(
            pip
            + [
                "install",
                "--upgrade",
                "torch",
                "--index-url",
                "https://download.pytorch.org/whl/cu128",
            ],
            allow_failure=True,
        )
        if not cuda_ok:
            print("[경고] CUDA PyTorch 설치에 실패했습니다. CPU PyTorch로 계속 설치합니다.")
    else:
        print("NVIDIA 드라이버(nvidia-smi)를 찾지 못해 CUDA wheel 설치를 건너뜁니다.")

    run(
        pip
        + [
            "install",
            "--upgrade",
            f"muscriptor=={UPSTREAM_VERSION}",
            "beat-this>=1.1",
            "huggingface_hub>=0.34",
            "safetensors>=0.4",
            "tomli>=2.0; python_version<'3.11'",
        ]
    )

    from runtime_guard import find_web_dir, verify_upstream

    verify_upstream()
    import torch

    print("\n[설치 확인]")
    print("muscriptor:", version_of("muscriptor"))
    print("PyTorch:", torch.__version__)
    print("CUDA build:", torch.version.cuda)
    print("CUDA available:", torch.cuda.is_available())
    if torch.cuda.is_available():
        print("GPU:", torch.cuda.get_device_name(0))
    print("최신 호환 웹 UI:", find_web_dir() or "누락")
    if find_web_dir() is None:
        raise RuntimeError(
            "설치된 MuScriptor 패키지에 web_dist가 없습니다. "
            "PyPI의 공식 0.3.0 wheel을 설치했는지 확인하세요."
        )
    print("\n환경 설치가 완료되었습니다.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception:
        traceback.print_exc()
        print(f"\n[설치 실패] 전체 로그: {LOG_PATH}")
        raise SystemExit(1)
