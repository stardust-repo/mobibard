from __future__ import annotations

import sys


def ask_yes_no(message: str, default: bool = True) -> bool:
    if not sys.stdin or not sys.stdin.isatty():
        print(f"{message} -> {'예' if default else '아니오'} (비대화형 기본값)")
        return default
    suffix = "[Y/n]" if default else "[y/N]"
    while True:
        answer = input(f"{message} {suffix} ").strip().lower()
        if not answer:
            return default
        if answer in {"y", "yes", "예", "네"}:
            return True
        if answer in {"n", "no", "아니오", "아니요"}:
            return False
        print("y 또는 n을 입력하세요.")


def print_oom_help(model_size: str, batch_size: int) -> None:
    print("\n[메모리 부족 안내]")
    print(f"- 현재 모델: {model_size}, 배치: {batch_size}")
    print("- 품질 모드라면 batch_size=1을 유지하고 small 모델 또는 Q8 모델을 시도하세요.")
    print("- Q8 KV는 메모리를 줄일 수 있지만 일반 FP16 KV보다 느릴 수 있습니다.")
    print("- 다른 GPU/Metal 프로그램을 종료한 뒤 다시 실행하세요.\n")
