from __future__ import annotations

import json
import re
from pathlib import Path

from constants import (
    COMPATIBLE_DERIVED_UPSTREAMS,
    DERIVED_SCHEMA,
    PACKAGE_REVISION,
    UPSTREAM_COMMIT,
    UPSTREAM_TAG,
    UPSTREAM_VERSION,
)


def remap_key(key: str) -> str:
    if key.startswith("emb.0."):
        return "emb." + key[len("emb.0.") :]
    if key.startswith("linears.0."):
        return "linear." + key[len("linears.0.") :]
    if key.startswith(("emb.1.", "linears.1.")):
        raise ValueError("두 개 이상의 codebook 체크포인트는 지원하지 않습니다.")
    return key


def is_condition_key(key: str) -> bool:
    return key.startswith("condition_provider.")


def is_ffn_weight(key: str) -> bool:
    return bool(
        re.fullmatch(r"transformer\.layers\.\d+\.linear[12]\.weight", key)
    )


def token_linear_module_path(key: str) -> str:
    if not is_ffn_weight(key):
        raise ValueError(f"FFN Q8 가중치가 아닙니다: {key}")
    return key.removesuffix(".weight")


def manifest_header(*, backend: str, size: str, precision: str, source: dict) -> dict:
    return {
        "schema": DERIVED_SCHEMA,
        "package_revision": PACKAGE_REVISION,
        "upstream": {
            "version": UPSTREAM_VERSION,
            "tag": UPSTREAM_TAG,
            "commit": UPSTREAM_COMMIT,
        },
        "backend": backend,
        "model_size": size,
        "precision": precision,
        "source": source,
        "decoder_revision": "prelude-forcing-v1",
        "instrument_constraint_revision": "hard-mask-v1",
    }


def validate_derived(
    path: Path,
    *,
    expected_format: str,
    backend: str,
    size: str,
    precision: str,
    source: dict | None = None,
) -> tuple[bool, str]:
    manifest_path = path / "manifest.json"
    if not manifest_path.is_file():
        return False, "manifest.json이 없습니다."
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        if manifest.get("format") != expected_format:
            return False, "파생 형식 버전이 다릅니다."
        if int(manifest.get("schema", -1)) != DERIVED_SCHEMA:
            return False, "파생 스키마 버전이 다릅니다."
        if manifest.get("package_revision") != PACKAGE_REVISION:
            return False, "패키지 리비전이 다릅니다."
        upstream = manifest.get("upstream", {})
        upstream_identity = (upstream.get("version"), upstream.get("commit"))
        if upstream_identity not in COMPATIBLE_DERIVED_UPSTREAMS:
            return False, "호환되지 않는 공식 MuScriptor 기준으로 생성된 파생 모델입니다."
        if manifest.get("backend") != backend:
            return False, "백엔드가 다릅니다."
        if manifest.get("model_size") != size or manifest.get("precision") != precision:
            return False, "모델 크기 또는 정밀도가 다릅니다."
        if manifest.get("decoder_revision") != "prelude-forcing-v1":
            return False, "디코더 리비전이 다릅니다."
        if manifest.get("instrument_constraint_revision") != "hard-mask-v1":
            return False, "악기 제한 리비전이 다릅니다."
        if source is not None:
            recorded = manifest.get("source", {})
            for key in ("weights_sha256", "config_sha256", "weights_bytes"):
                if recorded.get(key) != source.get(key):
                    return False, f"원본 모델 식별값({key})이 다릅니다."
        entries = manifest.get("entries", [])
        if not entries:
            return False, "가중치 목록이 비어 있습니다."
        for entry in entries:
            rel = entry.get("file")
            if not rel or not (path / rel).is_file():
                return False, f"파생 파일 누락: {rel}"
        if not (path / "config.json").is_file():
            return False, "config.json이 없습니다."
    except Exception as exc:
        return False, str(exc)
    return True, "정상"
