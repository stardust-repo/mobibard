from __future__ import annotations

import gc
import shutil
import sys
import traceback
from datetime import datetime
from pathlib import Path

import torch

from config import load_settings
from derive_cuda import FORMAT, derive_cuda
from derived_common import validate_derived
from kv_cache import reset_kv_patch
from model_store import ensure_original, source_identity
from prompts import ask_yes_no, print_oom_help
from runtime_guard import verify_upstream
from torch_backend import load_cuda_model
from web_runtime import serve

ROOT = Path(__file__).resolve().parents[1]
VALID_BACKENDS = {"auto", "cuda", "official", "cpu"}


def _dispatch(model, settings: dict, mode_label: str) -> None:
    if len(sys.argv) > 1:
        raise ValueError(f"알 수 없는 실행 인자입니다: {sys.argv[1:]}")
    serve(model, settings, mode_label)


def _dtype_for_official(precision: str):
    if precision == "auto":
        return None
    if precision == "fp32":
        return "float32"
    if precision == "fp16":
        return "float16"
    raise ValueError("공식 백엔드는 q8 모델 정밀도를 지원하지 않습니다.")


def load_official(weights: Path, device: str, precision: str):
    reset_kv_patch()
    from muscriptor import TranscriptionModel

    model = TranscriptionModel.load_model(
        weights,
        device=device,
        dtype=_dtype_for_official(precision),
    )
    if precision == "auto":
        if device == "mps":
            effective_precision = "fp16 weights"
        elif device == "cuda":
            effective_precision = "fp32 weights + fp16 autocast"
        else:
            effective_precision = "fp32 weights"
    else:
        effective_precision = f"{precision} weights"
    model._effective_precision = f"official/{effective_precision}"
    model._effective_backend = f"official_{device}"
    model._effective_kv = "official/native"
    return model


def prepare_derived(settings: dict, weights: Path, config: Path, precision: str) -> Path:
    size = settings["model"]["name"]
    target = ROOT / "models" / "derived" / "cuda" / precision / size
    source = source_identity(weights, config)
    valid, reason = validate_derived(
        target,
        expected_format=FORMAT,
        backend="cuda",
        size=size,
        precision=precision,
        source=source,
    )
    if not valid and target.exists() and any(target.iterdir()):
        print("기존 CUDA 파생 모델 무효:", reason)
        auto = bool(settings["runtime"]["rebuild_invalid_derived"])
        if auto or ask_yes_no("기존 파생 모델을 삭제하고 다시 만들까요?", True):
            shutil.rmtree(target, ignore_errors=True)
        else:
            raise RuntimeError("파생 모델 재생성을 취소했습니다.")
    valid, _ = validate_derived(
        target,
        expected_format=FORMAT,
        backend="cuda",
        size=size,
        precision=precision,
        source=source,
    )
    if not valid:
        derive_cuda(
            size=size,
            precision=precision,
            source_weights=weights,
            source_config=config,
            source=source,
            output_dir=target,
        )
    return target


def run_custom_cuda(settings: dict, weights: Path, config: Path) -> None:
    precision = settings["model"]["precision"]
    if precision == "auto":
        precision = "fp16"
    derived = prepare_derived(settings, weights, config, precision)
    model = load_cuda_model(derived, settings["model"]["kv_cache"])
    _dispatch(
        model,
        settings,
        f"Windows CUDA custom / {precision.upper()} / "
        f"{getattr(model, '_effective_kv', 'native').upper()} KV",
    )


def run_official(settings: dict, weights: Path, device: str) -> None:
    requested_precision = settings["model"]["precision"]
    precision = requested_precision
    if device == "cpu" and precision in {"fp16", "q8"}:
        print(
            f"공식 CPU 백엔드는 요청 정밀도 {precision.upper()} 대신 "
            "안정적인 공식 기본 FP32 경로를 사용합니다."
        )
        precision = "auto"
    elif precision == "q8":
        raise ValueError("공식 GPU 백엔드는 q8 모델 정밀도를 지원하지 않습니다.")
    model = load_official(weights, device, precision)
    _dispatch(
        model,
        settings,
        f"official v0.2.2 / {device.upper()} / {precision.upper()}",
    )


def main() -> int:
    verify_upstream()
    settings = load_settings(ROOT)
    backend = settings["model"]["backend"]
    if backend not in VALID_BACKENDS:
        raise ValueError("Windows model.backend는 auto, cuda, official, cpu 중 하나여야 합니다.")
    ask = bool(settings["runtime"]["ask_fallback"])
    size = settings["model"]["name"]
    weights, config = ensure_original(ROOT, size, ask=ask)

    if backend == "cpu":
        run_official(settings, weights, "cpu")
        return 0
    if backend == "official":
        device = "cuda" if torch.cuda.is_available() else "cpu"
        run_official(settings, weights, device)
        return 0
    if backend == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("model.backend=cuda이지만 CUDA를 사용할 수 없습니다.")

    if torch.cuda.is_available():
        try:
            run_custom_cuda(settings, weights, config)
            return 0
        except Exception as exc:
            traceback.print_exc()
            print(f"\nCUDA 파생 실행 실패: {exc}")
            text = str(exc).lower()
            if "out of memory" in text or "cuda" in text and "memory" in text:
                print_oom_help(size, settings["decode"]["batch_size"])
            reset_kv_patch()
            torch.cuda.empty_cache()
            gc.collect()
            if ask and ask_yes_no("공식 CUDA 백엔드로 다시 실행할까요?", True):
                try:
                    fallback_precision = settings["model"]["precision"]
                    if fallback_precision == "q8":
                        fallback_precision = "auto"
                    effective = {**settings, "model": {**settings["model"], "precision": fallback_precision}}
                    run_official(effective, weights, "cuda")
                    return 0
                except Exception as official_exc:
                    print("공식 CUDA 실행도 실패했습니다:", official_exc)

    if backend == "cuda":
        return 2
    if not ask or ask_yes_no("공식 CPU 백엔드로 실행할까요?", True):
        fallback_precision = settings["model"]["precision"]
        if fallback_precision in {"q8", "fp16"}:
            fallback_precision = "auto"
        effective = {**settings, "model": {**settings["model"], "precision": fallback_precision}}
        run_official(effective, weights, "cpu")
        return 0
    return 2


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except SystemExit:
        raise
    except Exception as exc:
        log_dir = ROOT / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_path = log_dir / f"run_error_{datetime.now():%Y%m%d_%H%M%S}.log"
        details = traceback.format_exc()
        log_path.write_text(details, encoding="utf-8")
        print(details)
        print(f"[실행 실패] {exc}")
        print(f"전체 오류 로그: {log_path}")
        raise SystemExit(1)
