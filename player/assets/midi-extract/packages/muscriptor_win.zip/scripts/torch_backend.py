from __future__ import annotations

import json
from pathlib import Path

import torch
from safetensors.torch import load_file
from torch import nn

from kv_cache import configure_kv_cache, reset_kv_patch
from q8_linear import QuantizedFFNLinear

SAMPLE_RATE = 16000


def _child(module, part: str):
    if isinstance(module, (nn.ModuleList, nn.Sequential)):
        return module[int(part)]
    if isinstance(module, nn.ModuleDict):
        return module[part]
    return getattr(module, part)


def _parent_and_name(module, path: str):
    parts = path.split(".")
    current = module
    for part in parts[:-1]:
        current = _child(current, part)
    return current, parts[-1]


def _set_module(module, path: str, value: nn.Module) -> None:
    parent, name = _parent_and_name(module, path)
    if isinstance(parent, nn.ModuleList):
        parent[int(name)] = value
    elif isinstance(parent, nn.ModuleDict):
        parent[name] = value
    else:
        setattr(parent, name, value)


def _set_tensor(module, path: str, value: torch.Tensor) -> None:
    parent, name = _parent_and_name(module, path)
    if name in getattr(parent, "_buffers", {}):
        parent._buffers[name] = value
        return
    if name in getattr(parent, "_parameters", {}):
        setattr(parent, name, nn.Parameter(value, requires_grad=False))
        return
    raise KeyError(f"모델에서 파라미터/버퍼 경로를 찾지 못했습니다: {path}")


class DeviceConditioningProvider(nn.Module):
    """Run official conditioners on CPU, then move encoded conditions to the token device."""

    def __init__(self, base: nn.Module, target: torch.device):
        super().__init__()
        self.base = base
        self.target = target
        self.device = getattr(base, "device", torch.device("cpu"))

    def tokenize(self, inputs):
        return self.base.tokenize(inputs)

    def forward(self, tokenized):
        encoded = self.base(tokenized)
        return {
            key: (condition.to(self.target), mask.to(self.target))
            for key, (condition, mask) in encoded.items()
        }


class HybridTranscriptionModel:
    """Factory namespace for a v0.2.2 TranscriptionModel with CPU conditioners."""

    @staticmethod
    def wrap(model, tokenizer, device: torch.device):
        from muscriptor.transcription_model import TranscriptionModel
        from muscriptor.modules.conditioners import ConditioningAttributes, WavCondition
        from muscriptor.utils.audio import load_audio, resample

        class _Hybrid(TranscriptionModel):
            def _load_wav(self, audio, sample_rate):
                if isinstance(audio, (str, Path)):
                    wav = load_audio(audio, target_sr=SAMPLE_RATE)
                else:
                    wav = audio.float()
                    if wav.dim() == 1:
                        wav = wav.unsqueeze(0)
                    if wav.dim() == 3:
                        wav = wav.squeeze(0)
                    if wav.shape[0] > 1:
                        wav = wav.mean(0, keepdim=True)
                    if sample_rate is not None and sample_rate != SAMPLE_RATE:
                        wav = resample(wav, sample_rate, SAMPLE_RATE)
                return wav.cpu()

            def _build_conditions(self, wav, instrument_group=None):
                length = wav.shape[-1]
                wav_cond = WavCondition(
                    wav=wav.unsqueeze(0),
                    length=torch.tensor([length], dtype=torch.long),
                    sample_rate=[SAMPLE_RATE],
                    path=[None],
                    seek_time=[0.0],
                )
                return [
                    ConditioningAttributes(
                        wav={"self_wav": wav_cond},
                        text={"instrument_group": instrument_group, "dataset_name": None},
                    )
                ]

        return _Hybrid(model=model, tokenizer=tokenizer, device=device)


def _build_model(config: dict, token_dtype: torch.dtype):
    from muscriptor.models.lm import LMModel, TorchAutocast
    from muscriptor.modules.conditioners import (
        ClassConditioner,
        ConditioningProvider,
        MelSpectrogramConditioner,
    )

    cpu = torch.device("cpu")
    dim = int(config["dim"])
    conditioner = ConditioningProvider(
        conditioners={
            "self_wav": MelSpectrogramConditioner(
                output_dim=dim,
                device=cpu,
                sample_rate=SAMPLE_RATE,
                n_fft=2048,
                frame_rate=100,
                n_mel_bins=512,
                log_scale=True,
                eps=1e-6,
                normalize_audio=False,
            ),
            "instrument_group": ClassConditioner(1000, dim, device=cpu),
            "dataset_name": ClassConditioner(4, dim, device=cpu),
        },
        device=cpu,
    )
    return LMModel(
        condition_provider=conditioner,
        card=int(config["card"]),
        dim=dim,
        num_heads=int(config["num_heads"]),
        hidden_scale=4,
        cfg_coef=1.0,
        autocast=TorchAutocast(enabled=False),
        num_layers=int(config["num_layers"]),
        max_period=10000,
        device=torch.device("meta"),
        dtype=token_dtype,
    )


def _load_torch_model(model_dir: Path, requested_kv: str, device: torch.device):
    manifest = json.loads((model_dir / "manifest.json").read_text(encoding="utf-8"))
    config = json.loads((model_dir / "config.json").read_text(encoding="utf-8"))
    precision = str(manifest["precision"])
    token_dtype = torch.float32 if manifest["token_dtype"] == "float32" else torch.float16

    reset_kv_patch()
    model = _build_model(config, token_dtype)

    print(f"\nCUDA 파생 모델 로드: {precision.upper()}")
    entries = manifest["entries"]
    for index, entry in enumerate(entries, 1):
        path = model_dir / entry["file"]
        if entry["kind"] == "q8_ffn":
            tensors = load_file(path, device=str(device))
            module = QuantizedFFNLinear(tensors["qweight"], tensors["scale"])
            _set_module(model, entry["module_path"], module)
        else:
            target = torch.device("cpu") if entry["name"].startswith("condition_provider.") else device
            tensor = load_file(path, device=str(target))["value"]
            _set_tensor(model, entry["name"], tensor)
        if index % 20 == 0 or index == len(entries):
            print(f"  {index}/{len(entries)} tensors")

    meta_left = [name for name, param in model.named_parameters() if param.is_meta]
    if meta_left:
        raise RuntimeError("로드되지 않은 meta 파라미터: " + ", ".join(meta_left[:10]))

    model.condition_provider = DeviceConditioningProvider(model.condition_provider, device)
    model.eval()
    effective_kv, kv_detail = configure_kv_cache(requested_kv, token_dtype)
    print("KV 캐시:", effective_kv.upper(), "-", kv_detail)

    from muscriptor.tokenizer.mt3 import MT3Tokenizer

    tokenizer = MT3Tokenizer(instrument_vocabulary="MT3_FULL_PLUS", max_shift_steps=1001)
    wrapper = HybridTranscriptionModel.wrap(model, tokenizer, device)
    wrapper._effective_precision = precision
    wrapper._effective_backend = f"{device.type}_custom"
    wrapper._effective_kv = effective_kv
    wrapper._effective_kv_backend = kv_detail
    return wrapper


def load_cuda_model(model_dir: Path, requested_kv: str):
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA를 사용할 수 없습니다.")
    return _load_torch_model(model_dir, requested_kv, torch.device("cuda"))
