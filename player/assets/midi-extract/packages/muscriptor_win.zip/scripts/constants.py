from __future__ import annotations

UPSTREAM_NAME = "MuScriptor"
UPSTREAM_VERSION = "0.3.0"
UPSTREAM_TAG = "v0.3.0"
UPSTREAM_COMMIT = "d73147e"
WEB_RUNTIME_COMMIT = "d73147e75e5b9b0c0a79ebe154587db4fd603e0c"
WEB_SAMPLE_SITE_COMMIT = "9550a7ced9bb8ba8137df1a65bcb64ce1eecbbdf"
WEB_PATCH_SCHEMA = 9
CANCEL_RUNTIME_REVISION = "disconnect-watch-v3"
PACKAGE_NAME = "MuScriptor Convenience"
APP_REVISION = "1.1"
# Derived-weight compatibility revision. v1.1 keeps the existing r1 format.
PACKAGE_REVISION = "0.2.2-r1"
COMPATIBLE_DERIVED_UPSTREAMS = {
    ("0.2.2", "3feb249"),
    ("0.3.0", "d73147e"),
}
DERIVED_SCHEMA = 2

MODEL_REPOS = {
    "small": "MuScriptor/muscriptor-small",
    "medium": "MuScriptor/muscriptor-medium",
    "large": "MuScriptor/muscriptor-large",
}

EXPECTED_CONFIGS = {
    "small": {"dim": 768, "num_heads": 12, "num_layers": 14, "card": 1393},
    "medium": {"dim": 1024, "num_heads": 16, "num_layers": 24, "card": 1395},
    "large": {"dim": 1536, "num_heads": 24, "num_layers": 48, "card": 1395},
}

MODEL_LICENSE = "CC BY-NC 4.0 plus the conditions shown on the official gated model page"
