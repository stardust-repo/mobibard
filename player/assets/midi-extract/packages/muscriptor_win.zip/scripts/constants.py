from __future__ import annotations

UPSTREAM_NAME = "MuScriptor"
UPSTREAM_VERSION = "0.2.2"
UPSTREAM_TAG = "v0.2.2"
UPSTREAM_COMMIT = "3feb249"
WEB_RUNTIME_COMMIT = "c3b82e7690d72e3cff917312a5953398cc98c521"
WEB_SAMPLE_SITE_COMMIT = "9550a7ced9bb8ba8137df1a65bcb64ce1eecbbdf"
WEB_PATCH_SCHEMA = 6
CANCEL_RUNTIME_REVISION = "disconnect-watch-v3"
PACKAGE_NAME = "MuScriptor Convenience"
APP_REVISION = "1.0"
# Derived-weight compatibility revision. v1.0 reuses the existing r1 weights.
PACKAGE_REVISION = "0.2.2-r1"
DERIVED_SCHEMA = 2

MODEL_REPOS = {
    "small": "MuScriptor/muscriptor-small",
    "medium": "MuScriptor/muscriptor-medium",
    "large": "MuScriptor/muscriptor-large",
}

EXPECTED_CONFIGS = {
    "small": {"dim": 768, "num_heads": 12, "num_layers": 14, "card": 1393},
    "medium": {"dim": 1024, "num_heads": 16, "num_layers": 24, "card": 1395},
    "large": {"dim": 1536, "num_heads": 24, "num_layers": 48, "card": 1395},
}

MODEL_LICENSE = "CC BY-NC 4.0 plus the conditions shown on the official gated model page"
