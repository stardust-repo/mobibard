from __future__ import annotations

import threading
import time
import webbrowser
from collections.abc import Iterator
from pathlib import Path

import uvicorn
from official_server_latest import create_app
from constants import CANCEL_RUNTIME_REVISION, WEB_PATCH_SCHEMA

from overlap_transcription import OverlapPolicy, WINDOW_SECONDS, transcribe_with_overlap
from runtime_cleanup import (
    cleanup_backend_cache,
    close_iterator,
    restore_cuda_model,
)
from runtime_guard import find_web_dir


class ConfiguredModel:
    """Apply local settings to every request without editing official server code."""

    def __init__(self, base, settings: dict):
        self._base = base
        self._decode = settings["decode"]
        self._memory_lock = threading.RLock()
        # runtime_cleanup also stores the lock on the base model so every cleanup
        # path (server, wrapper, manual endpoint) serializes model moves.
        setattr(self._base, "_convenience_memory_lock", self._memory_lock)

    def __getattr__(self, name):
        return getattr(self._base, name)

    @property
    def overlap_sec(self) -> float:
        return float(self._decode["overlap_sec"])

    @property
    def batch_size(self) -> int:
        return int(self._decode["batch_size"])

    @property
    def overlap_enabled(self) -> bool:
        return self.overlap_sec > 0.0

    @property
    def prelude_forcing(self) -> bool:
        # Official prelude forcing is sequential by design.  It is selected
        # automatically only when overlap is disabled and batch_size is one.
        return not self.overlap_enabled and self.batch_size == 1

    @property
    def mode_label(self) -> str:
        if self.overlap_enabled:
            return f"{self.overlap_sec:.1f}초 오버랩 병합"
        if self.prelude_forcing:
            return "공식 프롤로그 경계 보정"
        return "공식 배치 경계 처리"

    def _arguments(self, instruments) -> dict:
        configured = self._decode.get("instruments") or None
        selected = instruments if instruments is not None else configured
        return {
            "instruments": selected,
            "batch_size": self.batch_size,
            "use_sampling": bool(self._decode["sampling"]),
            "temperature": float(self._decode["temperature"]),
            "cfg_coef": float(self._decode["guidance_weight"]),
            "beam_size": int(self._decode["beam_size"]),
            "no_eos_is_ok": not bool(self._decode["strict_eos"]),
            "prelude_forcing": self.prelude_forcing,
        }

    def _cancellable_direct_transcribe(
        self, audio, arguments: dict, cancel_event: threading.Event | None
    ):
        """Inject token-step cancellation into the official non-overlap path.

        The official transcribe generator yields note events much less often than
        its token generator. Wrapping ``_model.generate`` lets the cancel button
        stop at the next generated token rather than waiting for an entire audio
        window to finish.
        """

        def stream():
            core = getattr(self._base, "_model", None)
            original_generate = getattr(core, "generate", None)
            selected_stream = None

            if cancel_event is None or not callable(original_generate):
                selected_stream = self._base.transcribe(audio, **arguments)
                try:
                    yield from selected_stream
                finally:
                    close_iterator(selected_stream)
                return

            def cancellable_generate(*args, **kwargs):
                generation = original_generate(*args, **kwargs)
                try:
                    for step in generation:
                        if cancel_event.is_set():
                            return
                        yield step
                finally:
                    close_iterator(generation)

            setattr(core, "generate", cancellable_generate)
            try:
                if cancel_event.is_set():
                    return
                selected_stream = self._base.transcribe(audio, **arguments)
                for event in selected_stream:
                    if cancel_event.is_set():
                        return
                    yield event
            finally:
                close_iterator(selected_stream)
                setattr(core, "generate", original_generate)

        return stream()

    def _transcribe_selected(
        self,
        audio,
        arguments: dict,
        cancel_event: threading.Event | None,
    ):
        if not self.overlap_enabled:
            return self._cancellable_direct_transcribe(
                audio, arguments, cancel_event
            )

        overlap_arguments = dict(arguments)
        overlap_arguments.pop("prelude_forcing", None)
        overlap_arguments["overlap_sec"] = self.overlap_sec
        overlap_arguments["cancel_event"] = cancel_event
        return transcribe_with_overlap(self._base, audio, **overlap_arguments)

    def prepare_for_transcription(self, *, reason: str = "변환 준비") -> None:
        with self._memory_lock:
            restore_cuda_model(self._base, reason=reason)

    def transcribe(
        self,
        audio,
        instruments=None,
        cancel_event: threading.Event | None = None,
        **_server_defaults,
    ) -> Iterator:
        arguments = self._arguments(instruments)

        def stream():
            started = time.perf_counter()
            status = "완료"
            selected_stream = None
            try:
                self.prepare_for_transcription()
                if cancel_event is not None and cancel_event.is_set():
                    status = "중단"
                    return
                selected_stream = self._transcribe_selected(
                    audio, arguments, cancel_event
                )
                for event in selected_stream:
                    if cancel_event is not None and cancel_event.is_set():
                        status = "중단"
                        return
                    yield event
                if cancel_event is not None and cancel_event.is_set():
                    status = "중단"
            except GeneratorExit:
                status = "중단"
                raise
            except Exception:
                status = "실패"
                raise
            finally:
                # Explicitly propagate close() through the selected overlap/token
                # generators first.  Then run the *same* full model offload for a
                # normal completion and a cancellation.  Keeping this inside the
                # transcription generator removes any dependency on the browser or
                # outer SSE response reaching another yield before CUDA memory is
                # returned.
                close_iterator(selected_stream)
                selected_stream = None
                cleanup_backend_cache(self._base, reason=status, offload_model=True)
                elapsed = time.perf_counter() - started
                minutes, seconds = divmod(elapsed, 60.0)
                hours, minutes = divmod(int(minutes), 60)
                formatted = (
                    f"{hours:02d}:{minutes:02d}:{seconds:06.3f}"
                    if hours
                    else f"{minutes:02d}:{seconds:06.3f}"
                )
                print(
                    f"\n[MuScriptor Convenience/{self.mode_label}] MIDI 변환 {status}"
                    f" - 소요시간: {elapsed:.3f}초 ({formatted})",
                    flush=True,
                )

        return stream()

    def cleanup_memory(
        self,
        *,
        reason: str = "수동 정리",
        offload_model: bool = False,
    ) -> None:
        """Release backend cache and optionally move CUDA weights to CPU."""
        with self._memory_lock:
            cleanup_backend_cache(
                self._base,
                reason=reason,
                offload_model=offload_model,
            )

    def detect_beat_grid_for(self, audio, mode="best-effort"):
        """Delegate v0.3.0 beat/tempo detection to the official model wrapper."""
        return self._base.detect_beat_grid_for(audio, mode)

    def events_to_midi_bytes(self, events, beat_grid=None):
        return self._base.events_to_midi_bytes(events, beat_grid=beat_grid)

    def transcribe_to_midi(
        self,
        audio,
        instruments=None,
        detect_tempo="best-effort",
        **_server_defaults,
    ):
        # Keep transcription on the patched overlap/cancellation lifecycle while
        # using the official v0.3.0 beat grid for tempo-aware MIDI serialization.
        beat_grid = self.detect_beat_grid_for(audio, detect_tempo)
        return self.events_to_midi_bytes(
            self.transcribe(audio, instruments=instruments),
            beat_grid=beat_grid,
        )


class _CancellationAwareUvicornServer(uvicorn.Server):
    """Signal the model loop before Uvicorn waits for open SSE connections."""

    def __init__(self, config: uvicorn.Config, cancel_active):
        super().__init__(config)
        self._cancel_active = cancel_active

    def handle_exit(self, sig: int, frame) -> None:
        # Python signal handlers may interrupt buffered stdout or code that owns
        # project locks.  Do no logging and no blocking work here: only set the
        # thread-safe cancellation event, then let Uvicorn perform its normal
        # graceful-shutdown bookkeeping.
        try:
            self._cancel_active()
        except BaseException:
            pass
        super().handle_exit(sig, frame)


def serve(model, settings: dict, mode_label: str) -> None:
    server = settings["server"]
    decode = settings["decode"]
    model_settings = settings["model"]
    configured_model = ConfiguredModel(model, settings)
    host = str(server["host"])
    port = int(server["port"])
    web_dir = find_web_dir()
    app = create_app(configured_model, web_dir=web_dir)

    print("\n============================================================")
    print("MuScriptor Convenience v1.1  :", mode_label)
    print("실행 패키지 루트             :", str(Path(__file__).resolve().parents[1]))
    print("모델                         :", model_settings["name"])
    print("요청 정밀도                  :", model_settings["precision"])
    print("실제 정밀도                  :", getattr(model, "_effective_precision", "official"))
    print("요청 KV 캐시                 :", model_settings["kv_cache"])
    print("실제 KV 캐시                 :", getattr(model, "_effective_kv", "official/native"))
    print("경계 처리                    :", configured_model.mode_label)
    if configured_model.overlap_enabled:
        policy = OverlapPolicy.from_seconds(configured_model.overlap_sec)
        print(
            "오버랩 창                    :",
            f"{WINDOW_SECONDS:.1f}초 / 겹침 {policy.overlap_seconds:.1f}초 / "
            f"간격 {policy.stride_seconds:.1f}초",
        )
        print(
            "오버랩 신뢰 구간             :",
            f"{policy.edge_zone_seconds:.2f} / {policy.center_zone_seconds:.2f} / "
            f"{policy.edge_zone_seconds:.2f}초",
        )
        print("프롤로그 강제                : 사용 안 함(독립 창 병합)")
    else:
        print("오버랩                       : 사용 안 함")
        print("프롤로그 강제                :", configured_model.prelude_forcing)
    print("배치                         :", decode["batch_size"])
    print("악기 제한                    :", decode["instruments"] or "자동")
    print("로컬 주소                    :", f"http://127.0.0.1:{port}/")
    print("바인딩                       :", f"{host}:{port}")
    print("웹 UI                        :", str(web_dir) if web_dir else "없음(API만 사용 가능)")
    print("웹 런타임 기준               :", "MuScriptor v0.3.0 d73147e")
    print("웹 취소 브리지               :", f"schema {WEB_PATCH_SCHEMA} (외부 스크립트)")
    print("중단/종료 수명주기           :", CANCEL_RUNTIME_REVISION)
    print("종료                         : Control + C")
    print("============================================================\n")

    if bool(server["open_browser"]):

        def open_later() -> None:
            time.sleep(3.0)
            webbrowser.open(f"http://127.0.0.1:{port}/?mc_patch={WEB_PATCH_SCHEMA}")

        threading.Thread(target=open_later, daemon=True).start()

    cancel_active = getattr(app.state, "request_transcription_cancel", lambda **_kwargs: False)
    config = uvicorn.Config(
        app,
        host=host,
        port=port,
        timeout_graceful_shutdown=30,
    )
    server_instance = _CancellationAwareUvicornServer(config, cancel_active)
    try:
        server_instance.run()
    finally:
        # This executes after Uvicorn has closed its event loop, so it never
        # schedules work onto an executor that may already be shutting down.
        # It is an idempotent final pass; active request generators normally do
        # the same offload before the server reaches this point.
        try:
            configured_model.cleanup_memory(reason="서버 종료", offload_model=True)
        except BaseException as exc:
            print(f"[memory-cleanup] final server cleanup warning: {exc}", flush=True)
