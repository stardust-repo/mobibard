from __future__ import annotations

import threading
import time
import webbrowser
from collections.abc import Iterator

import uvicorn
from official_server_latest import create_app

from overlap_transcription import OverlapPolicy, WINDOW_SECONDS, transcribe_with_overlap
from runtime_guard import find_web_dir


class ConfiguredModel:
    """Apply local settings to every request without editing official server code."""

    def __init__(self, base, settings: dict):
        self._base = base
        self._decode = settings["decode"]

    def __getattr__(self, name):
        return getattr(self._base, name)

    @property
    def overlap_sec(self) -> float:
        return float(self._decode["overlap_sec"])

    @property
    def batch_size(self) -> int:
        return int(self._decode["batch_size"])

    @property
    def overlap_enabled(self) -> bool:
        return self.overlap_sec > 0.0

    @property
    def prelude_forcing(self) -> bool:
        # Official prelude forcing is sequential by design.  It is selected
        # automatically only when overlap is disabled and batch_size is one.
        return not self.overlap_enabled and self.batch_size == 1

    @property
    def mode_label(self) -> str:
        if self.overlap_enabled:
            return f"{self.overlap_sec:.1f}초 오버랩 병합"
        if self.prelude_forcing:
            return "공식 프롤로그 경계 보정"
        return "공식 배치 경계 처리"

    def _arguments(self, instruments) -> dict:
        configured = self._decode.get("instruments") or None
        selected = instruments if instruments is not None else configured
        return {
            "instruments": selected,
            "batch_size": self.batch_size,
            "use_sampling": bool(self._decode["sampling"]),
            "temperature": float(self._decode["temperature"]),
            "cfg_coef": float(self._decode["guidance_weight"]),
            "beam_size": int(self._decode["beam_size"]),
            "no_eos_is_ok": not bool(self._decode["strict_eos"]),
            "prelude_forcing": self.prelude_forcing,
        }

    def _transcribe_selected(self, audio, arguments: dict):
        if not self.overlap_enabled:
            return self._base.transcribe(audio, **arguments)

        overlap_arguments = dict(arguments)
        overlap_arguments.pop("prelude_forcing", None)
        overlap_arguments["overlap_sec"] = self.overlap_sec
        return transcribe_with_overlap(self._base, audio, **overlap_arguments)

    def transcribe(self, audio, instruments=None, **_server_defaults) -> Iterator:
        arguments = self._arguments(instruments)

        def stream():
            started = time.perf_counter()
            status = "완료"
            try:
                yield from self._transcribe_selected(audio, arguments)
            except GeneratorExit:
                status = "중단"
                raise
            except Exception:
                status = "실패"
                raise
            finally:
                elapsed = time.perf_counter() - started
                minutes, seconds = divmod(elapsed, 60.0)
                hours, minutes = divmod(int(minutes), 60)
                formatted = (
                    f"{hours:02d}:{minutes:02d}:{seconds:06.3f}"
                    if hours
                    else f"{minutes:02d}:{seconds:06.3f}"
                )
                print(
                    f"\n[MuScriptor Convenience/{self.mode_label}] MIDI 변환 {status}"
                    f" - 소요시간: {elapsed:.3f}초 ({formatted})",
                    flush=True,
                )

        return stream()

    def events_to_midi_bytes(self, events):
        return self._base.events_to_midi_bytes(events)

    def transcribe_to_midi(self, audio, instruments=None, **_server_defaults):
        return self.events_to_midi_bytes(self.transcribe(audio, instruments=instruments))


def serve(model, settings: dict, mode_label: str) -> None:
    server = settings["server"]
    decode = settings["decode"]
    model_settings = settings["model"]
    configured_model = ConfiguredModel(model, settings)
    host = str(server["host"])
    port = int(server["port"])
    web_dir = find_web_dir()
    app = create_app(configured_model, web_dir=web_dir)

    print("\n============================================================")
    print("MuScriptor Convenience v1.0  :", mode_label)
    print("모델                         :", model_settings["name"])
    print("요청 정밀도                  :", model_settings["precision"])
    print("실제 정밀도                  :", getattr(model, "_effective_precision", "official"))
    print("요청 KV 캐시                 :", model_settings["kv_cache"])
    print("실제 KV 캐시                 :", getattr(model, "_effective_kv", "official/native"))
    print("경계 처리                    :", configured_model.mode_label)
    if configured_model.overlap_enabled:
        policy = OverlapPolicy.from_seconds(configured_model.overlap_sec)
        print(
            "오버랩 창                    :",
            f"{WINDOW_SECONDS:.1f}초 / 겹침 {policy.overlap_seconds:.1f}초 / "
            f"간격 {policy.stride_seconds:.1f}초",
        )
        print(
            "오버랩 신뢰 구간             :",
            f"{policy.edge_zone_seconds:.2f} / {policy.center_zone_seconds:.2f} / "
            f"{policy.edge_zone_seconds:.2f}초",
        )
        print("프롤로그 강제                : 사용 안 함(독립 창 병합)")
    else:
        print("오버랩                       : 사용 안 함")
        print("프롤로그 강제                :", configured_model.prelude_forcing)
    print("배치                         :", decode["batch_size"])
    print("악기 제한                    :", decode["instruments"] or "자동")
    print("로컬 주소                    :", f"http://127.0.0.1:{port}/")
    print("바인딩                       :", f"{host}:{port}")
    print("웹 UI                        :", str(web_dir) if web_dir else "없음(API만 사용 가능)")
    print("웹 런타임 기준               :", "muscriptor main c3b82e7")
    print("종료                         : Control + C")
    print("============================================================\n")

    if bool(server["open_browser"]):

        def open_later() -> None:
            time.sleep(3.0)
            webbrowser.open(f"http://127.0.0.1:{port}/")

        threading.Thread(target=open_later, daemon=True).start()

    uvicorn.run(app, host=host, port=port)
