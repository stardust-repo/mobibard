from __future__ import annotations

import gc
import json
import shutil
from pathlib import Path

import torch
from safetensors import safe_open
from safetensors.torch import save_file

from derived_common import (
    is_condition_key,
    is_ffn_weight,
    manifest_header,
    remap_key,
    token_linear_module_path,
    validate_derived,
)

FORMAT = "muscriptor-convenience-cuda-v022-r1"


def _quantize_per_row(tensor: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    value = tensor.float().contiguous()
    scale = value.abs().amax(dim=1).clamp_min(1e-8) / 127.0
    qweight = torch.round(value / scale.unsqueeze(1)).clamp(-127, 127).to(torch.int8)
    return qweight.contiguous(), scale.to(torch.float16).contiguous()


def derive_cuda(
    *,
    size: str,
    precision: str,
    source_weights: Path,
    source_config: Path,
    source: dict,
    output_dir: Path,
) -> Path:
    valid, _ = validate_derived(
        output_dir,
        expected_format=FORMAT,
        backend="cuda",
        size=size,
        precision=precision,
        source=source,
    )
    if valid:
        return output_dir
    if precision not in {"fp32", "fp16", "q8"}:
        raise ValueError("CUDA 파생 정밀도는 fp32, fp16, q8 중 하나여야 합니다.")

    building = output_dir.with_name(output_dir.name + ".building")
    shutil.rmtree(building, ignore_errors=True)
    (building / "weights").mkdir(parents=True, exist_ok=True)
    shutil.copy2(source_config, building / "config.json")

    token_dtype = "float32" if precision == "fp32" else "float16"
    print(f"\n[{size}] CUDA {precision.upper()} 파생 모델 생성")
    print("- 공식 v0.2.2 디코딩/어텐션 흐름 유지")
    print("- conditioner: CPU FP32")
    print(f"- token round: {token_dtype}")
    if precision == "q8":
        print("- Q8 범위: transformer FFN linear1/linear2만")
        print("- 형식: per-output-row symmetric INT8 + FP16 scale")

    entries: list[dict] = []
    with safe_open(source_weights, framework="pt", device="cpu") as handle:
        keys = list(handle.keys())
        for index, source_key in enumerate(keys, 1):
            key = remap_key(source_key)
            tensor = handle.get_tensor(source_key)
            filename = f"{index:05d}.safetensors"
            path = building / "weights" / filename
            entry = {
                "name": key,
                "file": f"weights/{filename}",
                "shape": list(tensor.shape),
            }

            if precision == "q8" and is_ffn_weight(key):
                qweight, scale = _quantize_per_row(tensor)
                save_file({"qweight": qweight, "scale": scale}, path)
                entry.update(
                    kind="q8_ffn",
                    module_path=token_linear_module_path(key),
                    algorithm="per-output-row symmetric int8 + fp16 scale",
                )
                del qweight, scale
            else:
                if is_condition_key(key) or precision == "fp32":
                    stored = tensor.float().contiguous()
                    kind = "fp32"
                else:
                    stored = tensor.to(torch.float16).contiguous()
                    kind = "fp16"
                save_file({"value": stored}, path)
                entry.update(kind=kind, module_path=None)
                del stored

            entries.append(entry)
            del tensor
            if index % 20 == 0 or index == len(keys):
                print(f"  {index}/{len(keys)} tensors")
                gc.collect()

    manifest = {
        **manifest_header(backend="cuda", size=size, precision=precision, source=source),
        "format": FORMAT,
        "effective_precision": precision,
        "token_dtype": token_dtype,
        "condition_compute": "cpu_fp32",
        "q8_scope": "transformer FFN linear1 + linear2 only" if precision == "q8" else "none",
        "q8_runtime": "blockwise dequantization + torch.nn.functional.linear" if precision == "q8" else None,
        "entries": entries,
    }
    (building / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    shutil.rmtree(output_dir, ignore_errors=True)
    output_dir.parent.mkdir(parents=True, exist_ok=True)
    building.replace(output_dir)
    return output_dir
