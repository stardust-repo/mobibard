from __future__ import annotations

import torch
from torch import nn
from torch.nn import functional as F


class QuantizedFFNLinear(nn.Module):
    """FFN-only Q8 storage with blockwise dequantization.

    The weight is stored as signed INT8 plus one FP16 scale per output row.
    PyTorch SDPA and the rest of the transformer remain untouched. This is a
    memory-oriented compatibility path, not a promise of faster matrix math.
    """

    def __init__(
        self,
        qweight: torch.Tensor,
        scale: torch.Tensor,
        *,
        block_rows: int = 512,
    ) -> None:
        super().__init__()
        if qweight.ndim != 2 or qweight.dtype != torch.int8:
            raise ValueError("qweight는 2차원 torch.int8이어야 합니다.")
        if scale.ndim != 1 or scale.shape[0] != qweight.shape[0]:
            raise ValueError("scale은 출력 행 수와 같은 1차원 텐서여야 합니다.")
        self.register_buffer("qweight", qweight.contiguous(), persistent=True)
        self.register_buffer("scale", scale.to(torch.float16).contiguous(), persistent=True)
        self.in_features = int(qweight.shape[1])
        self.out_features = int(qweight.shape[0])
        self.block_rows = max(1, int(block_rows))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        outputs: list[torch.Tensor] = []
        dtype = x.dtype
        for start in range(0, self.out_features, self.block_rows):
            end = min(start + self.block_rows, self.out_features)
            weight = self.qweight[start:end].to(dtype=dtype)
            weight = weight * self.scale[start:end].to(dtype=dtype).unsqueeze(1)
            outputs.append(F.linear(x, weight))
        return torch.cat(outputs, dim=-1)
