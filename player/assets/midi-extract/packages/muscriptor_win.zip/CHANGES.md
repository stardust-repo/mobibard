# v1.1 — MuScriptor v0.3.0 갱신 (Windows)

- **2026-08-07 다운로드 버튼 수정:** 최종 SSE 이벤트를 공식 웹 UI 규격인 `transcription_complete`로 전송합니다.
- `dataclasses.asdict(BeatGrid)`가 내부 NumPy `beats` 배열까지 포함해 JSON 직렬화에 실패하던 문제를 제거하고, UI가 쓰는 `bpm`, `beats_per_bar`, `first_downbeat`, `onset_delay`만 전송합니다.
- 비트 감지와 onset 지연 측정을 공식 v0.3.0 완료 순서에 맞춰 최종 MIDI와 UI가 동일한 보정을 사용합니다.
- 웹 패치 schema를 8로 올려 기존 로컬 웹 캐시가 재사용되지 않도록 했습니다.
- 공식 MuScriptor `v0.3.0` (`d73147e`)을 설치·검증하도록 갱신했습니다.
- 공식 비트·템포 감지를 최종 MIDI 직렬화와 SSE `beat_grid` 응답에 연결했습니다.
- 공식 v0.3.0 웹 번들을 사용하도록 웹 패치 캐시 schema를 7로 올렸습니다.
- 기존 취소·완료 시 GPU/MLX 메모리 반환과 생성기 종료 패치를 유지했습니다.
- 기존 `0.2.2-r1` 파생 모델은 원본 해시가 동일하면 재사용할 수 있습니다.
- `beat-this>=1.1` 설치와 v0.3.0 API 검증을 추가했습니다.

# 변경 내역

## v1.0

### 패키지 배포 형식

- 배포 파일명을 `muscriptor_win.zip`, `muscriptor_mac.zip`으로 고정했습니다.
- ZIP 안에 별도의 상위 폴더를 두지 않고 `README.md`, 실행 스크립트, `scripts/`가 최상위에 바로 들어가도록 변경했습니다.
- README의 배포판 표기를 `v1.0`으로 변경하고 MuScriptor 코어, 웹 런타임, 비교 사이트, 주요 실행 의존성의 기준 버전을 첫 부분에 명시했습니다.
- 빈 폴더, `.gitkeep`, 캐시, 모델 가중치 및 macOS `.command` 파일은 포함하지 않습니다.

### 오버랩 노트의 점진적 웹 전송

- 이전에는 오버랩 창 전체를 분석·병합한 뒤에만 노트 이벤트를 웹으로 전송했습니다.
- 이제 각 생성 배치가 끝날 때 완료된 창의 결과를 병합하고, 다음 미처리 창의 시작보다 병합 보호 구간 `0.1`초 이상 앞에서 끝난 노트를 확정해 즉시 전송합니다.
- 다음 창에서 지속시간·중복·악기 판정을 바꿀 수 있는 마지막 꼬리만 보류하고, 다음 배치 또는 최종 배치에서 확정합니다.
- 전송된 노트에는 전역 고유 event index를 부여하며 재병합 시 fingerprint와 발생 순번으로 이미 보낸 노트를 제외합니다.
- 기존 후속 창 우선, 화음 보완, 가장자리 오검출 제거, 교차 악기 패턴 대응 규칙은 그대로 적용합니다.

## 0.2.2-r6

### 오버랩 설정 범위 확장

- `decode.overlap_sec` 기본값을 `0.5`에서 `1.0`으로 변경했습니다.
- 허용 범위를 `0~4.9`초로 확장했습니다.
- `0`은 공식 경계 처리 자동 선택, `0.1~4.9`는 오버랩 병합을 뜻합니다.
- 모든 값은 계속 `0.1`초 단위로 반올림되며 범위를 벗어나면 `0` 또는 `4.9`로 clamp합니다.
- 숫자가 아니거나 유한하지 않은 값은 기본값 `1.0`을 사용하고 콘솔에 경고를 표시합니다.

### 후속 창 우선 병합

- 앞 창의 결과를 무조건 버리거나 뒤 창 결과를 무조건 복사하지 않습니다.
- 한쪽 창에만 있는 고유 음은 기존 누락 복구·가장자리 오검출 규칙에 따라 유지합니다.
- 두 창의 결과가 같은 음, 같은 지속음 또는 같은 악기 패턴으로 확인된 경우에만 후속 창에 우선권을 줍니다.
- 같은 note-on의 중복이면 후속 창의 onset·악기 판정을 사용하고, 양쪽에서 확인한 가장 긴 offset은 보존합니다.
- 앞 창의 열린 음과 후속 창의 leading tie가 연결되면 실제 앞쪽 onset은 유지하고 후속 창의 악기 판정과 종료 길이를 우선합니다.
- 악기만 다르게 예측된 동일 패턴은 내부적으로 같은 파트로 대응시키되, 출력 악기를 앞 창 값으로 강제 정규화하지 않습니다.
- 병합 로그에 후속 창 우선 적용 횟수와 후속 악기 선택 횟수를 추가했습니다.

### 패키지

- 기본값은 계속 `model=medium`, `batch_size=6`입니다.
- 파생 가중치 형식은 변경하지 않아 `0.2.2-r1` 호환 FP16/Q8/MLX/CUDA 모델을 재사용할 수 있습니다.
- ZIP에는 빈 폴더를 넣지 않으며 macOS 패키지는 `.command` 파일 없이 `.sh`만 제공합니다.

## 0.2.2-r5

### 정식 오버랩 기능

- 실험용 `[experimental] overlap_test` 설정과 비교 실행기를 제거했습니다.
- `decode.prelude_forcing` 사용자 옵션을 제거하고 `decode.overlap_sec`를 정식 설정으로 추가했습니다.
- `overlap_sec`와 `batch_size`에 따라 공식 prelude forcing, 공식 배치 경계 처리, 오버랩 병합을 자동 선택합니다.
- 가변 3구간 신뢰도, 짧은 가장자리 오검출 필터, 화음 보완, 지속음 연장, 악기 패턴 대응과 유니즌 안전장치를 적용했습니다.
- 큰 오버랩에서 실제 입력이 겹치는 여러 창 사이의 상호 확인과 중복 제거를 지원합니다.
- Windows/macOS ZIP에서 빈 폴더와 `.gitkeep`을 제거하고 macOS의 `.command` 파일을 제거했습니다.

### 유지한 기능

- 공식 MuScriptor 0.2.2 추론·MIDI 출력
- Windows CUDA FP16/Q8 파생 백엔드
- Apple Silicon MLX FP16/Q8 백엔드와 Intel Mac 공식 폴백
- FFN 선택 Q8, 선택형 KV 캐시
- 공식 본체 `main` c3b82e7 기반 탭별 웹 요청 취소·대기 동작
- 실행 소요시간과 실제 백엔드·정밀도 표시

## 중단 시 GPU 메모리 정리

- 웹 변환 중단 또는 연결 종료 시 내부 변환 생성기를 즉시 `close()`합니다.
- MLX는 배치 생성기의 `finally`에서 KV/조건 참조를 해제한 뒤 `mx.clear_cache()`를 실행합니다.
- CUDA는 중단된 실행의 텐서 참조 정리 후 `torch.cuda.empty_cache()`를 실행합니다.
- 모델 가중치는 다음 변환을 위해 GPU에 유지되며, 중단 중 생성된 임시 메모리만 반환합니다.

### GPU 메모리 정리 보강

- 변환이 정상 완료된 경우에도 사용하지 않는 MLX/CUDA/MPS 캐시를 정리합니다.
- 공식 웹 UI의 `Transcribe another file` 버튼이 현재 탭의 실행을 명시적으로 중단하고 정리 API를 호출합니다.
- 이미 완료된 뒤 버튼을 누른 경우에도 정리 API가 즉시 다시 실행됩니다.
- 모델 가중치는 다음 변환을 위해 GPU에 유지됩니다.


## Windows CUDA 강제 반환 보강

- `Transcribe another file` 취소를 토큰 생성 루프까지 전달해 배치 완료를 기다리지 않고 종료합니다.
- 취소 API는 작업 생성기가 실제로 종료될 때까지 기다린 뒤 메모리 정리를 수행합니다.
- 변환 완료·오류·중단 후 CUDA 모델 가중치를 CPU로 오프로드합니다.
- 다음 변환 시작 시 모델을 CUDA로 자동 복원합니다.
- `torch.cuda.synchronize()`, `empty_cache()`, `ipc_collect()`를 순서대로 실행하고 정리 전후 allocated/reserved 메모리를 출력합니다.

### 6배치 오버랩 중단 경로 수정

- Starlette의 동기 SSE 반복기가 브라우저 연결 종료 시 마지막 `yield` 지점에 남을 수 있던 경로를 제거했습니다.
- 응답 수명주기를 관리하는 반복기를 추가해 `Transcribe another file`, 새 요청, 브라우저 연결 종료 모두 실제 SSE 반복기에 `close()`를 전달합니다.
- `done`과 변환 잠금은 오버랩 생성기, 토큰 생성기, KV 캐시 프레임의 `finally`가 모두 끝난 뒤에만 해제합니다.
- 취소 API의 백그라운드 잠금 해제가 실제 작업 종료로 잘못 인식되던 동작을 제거했습니다.
- 기본값인 `batch_size=6`, `overlap_sec=1.0`에서도 중단 시 6개 창의 조건 텐서와 KV 캐시 참조가 먼저 제거된 뒤 CUDA 모델을 CPU로 내립니다.
- 다른 브라우저 탭이나 취소할 수 없는 `/transcribe/midi` 작업이 실행 중일 때는 잘못된 모델 오프로드를 수행하지 않습니다.

### Windows 웹 중단 브리지 수정

- 공식 UI의 `resetToWelcome()`이 호출하는 `AbortController.abort()` 신호를 직접 감시해 `/transcribe/cancel`로 전달합니다.
- 버튼 문구를 찾아 클릭을 추측하던 경로는 보조 수단으로만 유지하고, 실제 fetch 중단 신호를 주 경로로 사용합니다.
- 웹 UI 캐시 키에 패치 schema와 주입 스크립트 SHA-256을 포함해 이전 `index.html`이 재사용되지 않도록 했습니다.
- 시작 주소에 `mc_patch` 쿼리를 붙이고 HTML 응답을 `no-store`로 제공해 브라우저 캐시도 갱신합니다.
- 취소 요청 수신과 클라이언트 일치 여부를 서버 콘솔에 즉시 출력합니다.
- 구형 캐시가 `/transcribe`에 클라이언트 ID를 넣지 못한 경우에도, 단 하나의 익명 실행 중 작업은 새 브리지의 취소 요청으로 정리할 수 있습니다.

### Windows 중단·Ctrl+C 수명주기 재구성

- 브라우저의 `/transcribe/cancel` 요청이 오지 않아도 서버가 ASGI `http.disconnect`를 직접 감시해 현재 생성기의 취소 플래그를 설정합니다.
- Starlette/ASGI 버전에 따라 연결 종료 감시를 생략하던 기본 `StreamingResponse` 경로를 사용하지 않고, 스트림과 연결 종료를 항상 동시에 감시합니다.
- 스트리밍 응답을 한 번 더 감싸던 FastAPI `BaseHTTPMiddleware`를 제거하고 순수 ASGI 캐시 헤더 미들웨어로 교체했습니다.
- 웹 취소 브리지를 인라인 코드가 아닌 같은 출처의 외부 JavaScript로 제공해 CSP나 실행 순서 때문에 브리지가 누락될 가능성을 제거했습니다.
- `Ctrl+C` 중에는 종료 중인 기본 executor에 정리 작업을 예약하지 않고, 활성 생성기를 같은 수명주기에서 동기적으로 종료합니다.
- CUDA 정리 중 예외나 추가 종료 신호가 발생해도 변환 잠금과 `done` 상태가 반드시 해제되도록 `finally` 구조를 보강했습니다.
- 시작 화면에 `disconnect-watch-v2`, 웹 브리지 schema 5, 실제 실행 패키지 경로를 출력합니다.
- 첫 오버랩 배치에서 설정 배치와 실제 배치를 함께 출력합니다.


## Windows 중단 메모리 반환 v3

- 변환 완료와 중간 취소가 `ConfiguredModel.transcribe()` 내부의 동일한 CUDA CPU 오프로드 경로를 사용합니다.
- ASGI 연결 종료 감시와 외부 취소 브리지 schema 6을 함께 사용합니다.
- Control+C 신호가 들어오면 Uvicorn이 연결 종료를 기다리기 전에 활성 토큰 루프에 취소를 전달합니다.
- 중단·종료 정리는 종료 중인 기본 executor에 새 작업을 예약하지 않습니다.
- 런타임 식별값: `disconnect-watch-v3`.

### Windows v1.1 download compatibility follow-up (2026-08-07)

- The server now emits both the legacy `midi` event and official v0.3.0 `transcription_complete` event so an older cached web UI and the v0.3.0 UI both enable MIDI download.
- Optional beat-grid detection failure now falls back to MIDI generation without tempo metadata instead of ending the stream without a download payload.
- Tempo-aware MIDI serialization retries once without a beat grid when only the optional tempo path fails.
- Web patch schema is now 9 to force a distinct local client cache marker.
