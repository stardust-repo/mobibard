@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8

where python >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Python was not found. Install Python 3.10 or newer.
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  python -m venv .venv
  if errorlevel 1 goto :error
)

".venv\Scripts\python.exe" "scripts\install_env.py" --platform windows
if errorlevel 1 goto :error

echo.
echo Installation completed.
pause
exit /b 0

:error
echo.
echo [ERROR] Installation failed. Check the logs folder.
pause
exit /b 1
