@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
set HF_HUB_DISABLE_SYMLINKS_WARNING=1

if not exist ".venv\Scripts\python.exe" (
  echo [ERROR] Run 1_install.bat first.
  pause
  exit /b 1
)

".venv\Scripts\python.exe" "scripts\launcher.py"
set CODE=%ERRORLEVEL%
echo.
pause
exit /b %CODE%
