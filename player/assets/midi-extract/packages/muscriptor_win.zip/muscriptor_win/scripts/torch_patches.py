from __future__ import annotations


import importlib

import torch
import torch.nn.functional as F
from einops import rearrange

import muscriptor.modules.streaming as streaming_module
import muscriptor.modules.transformer as transformer_module
from muscriptor.modules.streaming import StatefulModule

_CONFIG = {
    "kv_mode": "fp32",
    "kv_backend": "native_float",
    "kv_group_size": 64,
    "token_dtype": torch.float32,
}
_PATCHED = False
_ATTN_BIAS_CACHE: dict[tuple, torch.Tensor] = {}
_ORIGINALS: dict[str, object] = {}
_KV_PROBE_CACHE: dict[tuple, tuple[bool, str]] = {}

def _quantize_q8(x: torch.Tensor, group_size: int):
    if x.shape[-1] % group_size:
        raise ValueError("KV 마지막 차원이 group_size로 나누어지지 않습니다.")
    shape = x.shape
    grouped = x.reshape(*shape[:-1], shape[-1] // group_size, group_size)
    scale = grouped.abs().amax(dim=-1, keepdim=True).clamp_min(1e-8) / 127.0
    q = torch.round(grouped / scale).clamp(-127, 127).to(torch.int8)
    return q.reshape(shape), scale.to(torch.float16)

def _dequantize_q8(q: torch.Tensor, scale: torch.Tensor, dtype: torch.dtype):
    shape = q.shape
    groups = scale.shape[-2]
    group_size = shape[-1] // groups
    qg = q.reshape(*shape[:-1], groups, group_size)
    return (qg.to(dtype) * scale.to(dtype)).reshape(shape)


def _probe_float_kv(device: torch.device, dtype: torch.dtype) -> tuple[bool, str]:
    key = ("float", device.type, device.index, str(dtype))
    if key in _KV_PROBE_CACHE:
        return _KV_PROBE_CACHE[key]
    try:
        q = torch.randn(1, 2, 1, 64, device=device, dtype=dtype)
        k = torch.randn(1, 2, 16, 64, device=device, dtype=dtype)
        v = torch.randn(1, 2, 16, 64, device=device, dtype=dtype)
        with torch.inference_mode():
            y = F.scaled_dot_product_attention(q, k, v, dropout_p=0.0)
        if device.type == "cuda":
            torch.cuda.synchronize(device)
        if y.shape != q.shape or not torch.isfinite(y).all():
            raise RuntimeError("SDPA output validation failed")
        result = (True, "PASS")
    except Exception as exc:
        result = (False, str(exc))
    _KV_PROBE_CACHE[key] = result
    return result


def _probe_generic_q8_kv(
    device: torch.device,
    dtype: torch.dtype,
    group_size: int,
) -> tuple[bool, str]:
    key = ("generic_q8", device.type, device.index, str(dtype), int(group_size))
    if key in _KV_PROBE_CACHE:
        return _KV_PROBE_CACHE[key]
    try:
        k = torch.randn(1, 16, 2, 64, device=device, dtype=dtype)
        v = torch.randn(1, 16, 2, 64, device=device, dtype=dtype)
        q = torch.randn(1, 2, 1, 64, device=device, dtype=dtype)
        kq, ks = _quantize_q8(k, int(group_size))
        vq, vs = _quantize_q8(v, int(group_size))
        kd = _dequantize_q8(kq, ks, dtype).transpose(1, 2)
        vd = _dequantize_q8(vq, vs, dtype).transpose(1, 2)
        with torch.inference_mode():
            y = F.scaled_dot_product_attention(q, kd, vd, dropout_p=0.0)
        if device.type == "cuda":
            torch.cuda.synchronize(device)
        if y.shape != q.shape or not torch.isfinite(y).all():
            raise RuntimeError("generic Q8 KV output validation failed")
        result = (True, "PASS")
    except Exception as exc:
        result = (False, str(exc))
    _KV_PROBE_CACHE[key] = result
    return result


def _probe_optional_native_q8_kv(
    device: torch.device,
    dtype: torch.dtype,
    group_size: int,
) -> tuple[bool, str]:
    if device.type != "cuda":
        return False, "native Q8 KV extension is CUDA-only"
    try:
        module = importlib.import_module("muscriptor_q8_kv_cuda")
    except Exception as exc:
        return False, f"extension not installed: {exc}"
    try:
        test = getattr(module, "self_test")
        accepted = bool(test(dtype=dtype, group_size=int(group_size)))
        return accepted, "PASS" if accepted else "extension self-test returned false"
    except Exception as exc:
        return False, str(exc)


def resolve_torch_kv_mode(
    requested: str,
    *,
    device: torch.device,
    token_dtype: torch.dtype,
    group_size: int = 64,
) -> tuple[str, str, str]:
    """Resolve KV precision.

    Q8 is one mode in this package: INT8 K/V plus FP16 scale.
    """
    requested = str(requested).lower()

    if requested == "q8":
        ok, reason = _probe_generic_q8_kv(
            device,
            token_dtype,
            group_size,
        )
        if ok:
            print("[KV] Q8 캐시 검사를 통과했습니다.")
            print("[KV] K/V는 INT8+scale 형식으로 저장됩니다.")
            return "q8", "q8", "Q8"

        print(f"[KV] Q8 캐시를 사용할 수 없습니다: {reason}")

        candidates: list[tuple[str, torch.dtype]] = []
        if device.type == "cuda":
            candidates.append(("fp16", torch.float16))
        else:
            candidates.extend(
                [
                    ("bf16", torch.bfloat16),
                    ("fp16", torch.float16),
                ]
            )

        for mode, dtype in candidates:
            valid, detail = _probe_float_kv(device, dtype)
            if valid:
                print(
                    f"[KV] Q8 기능 실패로 {mode.upper()} 캐시를 사용합니다."
                )
                return mode, mode, detail

        valid, detail = _probe_float_kv(
            device,
            torch.float32,
        )
        if not valid:
            raise RuntimeError(
                f"FP32 KV cache validation failed: {detail}"
            )
        print("[KV] Q8과 16비트 캐시를 사용할 수 없어 FP32를 사용합니다.")
        return "fp32", "fp32", detail

    if requested == "fp16":
        valid, detail = _probe_float_kv(
            device,
            torch.float16,
        )
        if valid:
            return "fp16", "fp16", detail

        if device.type == "cpu":
            bf_valid, bf_detail = _probe_float_kv(
                device,
                torch.bfloat16,
            )
            if bf_valid:
                return "bf16", "bf16", bf_detail

        fp_valid, fp_detail = _probe_float_kv(
            device,
            torch.float32,
        )
        if not fp_valid:
            raise RuntimeError(
                f"FP32 KV cache validation failed: {fp_detail}"
            )
        return "fp32", "fp32", fp_detail

    valid, detail = _probe_float_kv(
        device,
        torch.float32,
    )
    if not valid:
        raise RuntimeError(
            f"FP32 KV cache validation failed: {detail}"
        )
    return "fp32", "fp32", detail


def _attn_init_state(self, batch_size: int, sequence_length: int):
    mode = _CONFIG["kv_mode"]
    weight = getattr(self, "in_proj_weight", None)
    if weight is None and hasattr(self, "in_proj_module"):
        weight = next(self.in_proj_module.parameters(), None)
        if weight is None:
            weight = next(self.in_proj_module.buffers(), None)
    device = weight.device if weight is not None else torch.device("cpu")
    if mode == "q8":
        groups = self.dim_per_head // int(_CONFIG["kv_group_size"])
        return {
            "cache_q": torch.zeros(
                (2, batch_size, sequence_length, self.num_heads, self.dim_per_head),
                dtype=torch.int8,
                device=device,
            ),
            "cache_scale": torch.ones(
                (2, batch_size, sequence_length, self.num_heads, groups, 1),
                dtype=torch.float16,
                device=device,
            ),
            "offset": 0,
        }
    dtype = {"fp16": torch.float16, "bf16": torch.bfloat16, "fp32": torch.float32}.get(mode, torch.float32)
    return {
        "cache": torch.empty(
            (2, batch_size, sequence_length, self.num_heads, self.dim_per_head),
            dtype=dtype,
            device=device,
        ),
        "offset": 0,
    }

def _attn_increment(self, state, increment: int = 1):
    state["offset"] = int(state["offset"]) + int(increment)

def _complete_kv(self, k, v, state):
    if state is None:
        return k, v

    end = int(state["offset"])
    count = k.shape[1]
    mode = _CONFIG["kv_mode"]

    if mode == "q8":
        group_size = int(_CONFIG["kv_group_size"])
        kq, ks = _quantize_q8(k, group_size)
        vq, vs = _quantize_q8(v, group_size)
        state["cache_q"][0, :, end:end + count] = kq
        state["cache_q"][1, :, end:end + count] = vq
        state["cache_scale"][0, :, end:end + count] = ks
        state["cache_scale"][1, :, end:end + count] = vs
        active_q = state["cache_q"][:, :, :end + count]
        active_s = state["cache_scale"][:, :, :end + count]
        # Native PyTorch SDPA cannot consume INT8 KV directly. This is the
        # documented experimental storage path; dequantization is the KV exception.
        return (
            _dequantize_q8(active_q[0], active_s[0], k.dtype),
            _dequantize_q8(active_q[1], active_s[1], v.dtype),
        )

    cache = state["cache"]
    cache[0, :, end:end + count] = k.to(cache.dtype)
    cache[1, :, end:end + count] = v.to(cache.dtype)
    return cache[0, :, :end + count], cache[1, :, :end + count]

def _attn_forward(self, query: torch.Tensor, model_state=None):
    state = self.get_state(model_state)
    if hasattr(self, "in_proj_module"):
        projected = self.in_proj_module(query)
    else:
        projected = F.linear(query, self.in_proj_weight)
    packed = rearrange(
        projected, "b t (p h d) -> b t p h d", p=3, h=self.num_heads
    )
    q, k, v = packed.unbind(dim=2)
    k, v = self._complete_kv(k, v, state)

    source_dtype = q.dtype
    if q.dtype != k.dtype:
        q = q.to(k.dtype)

    q_t, k_t, v_t = q.transpose(1, 2), k.transpose(1, 2), v.transpose(1, 2)
    tq, tk = q_t.shape[2], k_t.shape[2]

    # Reuse the exact bottom-right additive bias used by MuScriptor 0.2.1.
    # This avoids per-layer allocation while preserving SDPA inputs and math.
    bias_key = (query.device.type, query.device.index, q.dtype, int(tq), int(tk))
    attn_bias = _ATTN_BIAS_CACHE.get(bias_key)
    if attn_bias is None:
        if tq == 1:
            attn_bias = torch.zeros(tq, tk, dtype=q.dtype, device=query.device)
        else:
            mask = torch.ones(tq, tk, dtype=torch.bool, device=query.device).tril(
                tk - tq
            )
            attn_bias = torch.zeros(tq, tk, dtype=q.dtype, device=query.device)
            attn_bias.masked_fill_(~mask, float("-inf"))
        _ATTN_BIAS_CACHE[bias_key] = attn_bias

    x = F.scaled_dot_product_attention(
        q_t, k_t, v_t, attn_mask=attn_bias, dropout_p=0.0
    )
    x = x.transpose(1, 2)
    if x.dtype != source_dtype:
        x = x.to(source_dtype)
    x = rearrange(x, "b t h d -> b t (h d)")
    return self.out_proj(x)

def _transformer_init_state(self, batch_size: int, sequence_length: int):
    del batch_size
    shared = getattr(self, "_shared_position_table", None)
    if shared is not None:
        if sequence_length > shared.shape[1]:
            raise RuntimeError(
                f"position table overflow: {sequence_length} > {shared.shape[1]}"
            )
        table = shared[:, :sequence_length]
    else:
        weight = self.layers[0].norm2.weight
        channels = int(weight.shape[0])
        positions = torch.arange(
            sequence_length,
            device=weight.device,
        ).view(1, -1, 1)
        table = transformer_module.create_sin_embedding(
            positions,
            channels,
            max_period=self.max_period,
            dtype=weight.dtype,
        )
    return {"offset": 0, "position_table": table}


def _transformer_increment(self, state, increment: int = 1):
    state["offset"] = int(state["offset"]) + int(increment)


def _transformer_forward(self, x, prepend_length=0, model_state=None):
    del prepend_length
    batch, length, channels = x.shape
    state = self.get_state(model_state)
    if state is not None and "position_table" in state:
        offset = int(state["offset"])
        pos = state["position_table"][:, offset:offset + length]
        if batch != 1:
            pos = pos.expand(batch, -1, -1)
    else:
        positions = torch.arange(length, device=x.device).view(1, -1, 1)
        pos = transformer_module.create_sin_embedding(
            positions,
            channels,
            max_period=self.max_period,
            dtype=x.dtype,
        )
    # Normal generation positions are non-negative, so the official mask is 1.
    x = x + pos
    for layer in self.layers:
        x = layer(x, model_state=model_state)
    return x

def _cached_increment_steps(model, model_state, increment: int = 1):
    modules = getattr(model, "_muscriptor_stateful_cache", None)
    if modules is None:
        modules = tuple(
            module for _, module in model.named_modules()
            if isinstance(module, StatefulModule)
            and module._module_absolute_name is not None
        )
        model._muscriptor_stateful_cache = modules
    for module in modules:
        module.increment_step(model_state[module._module_absolute_name], increment)

def apply_torch_patches(
    kv_mode: str,
    kv_group_size: int,
    token_dtype: torch.dtype,
    kv_backend: str = "native_float",
):
    global _PATCHED
    _CONFIG.update(
        kv_mode=kv_mode,
        kv_backend=kv_backend,
        kv_group_size=int(kv_group_size),
        token_dtype=token_dtype,
    )
    if _PATCHED:
        return

    attn = transformer_module.StreamingMultiheadAttention
    if not _ORIGINALS:
        _ORIGINALS.update(
            attn_init_state=attn.init_state,
            attn_increment_step=attn.increment_step,
            attn_complete_kv=attn._complete_kv,
            attn_forward=attn.forward,
            transformer_init_state=transformer_module.StreamingTransformer.init_state,
            transformer_increment_step=transformer_module.StreamingTransformer.increment_step,
            transformer_forward=transformer_module.StreamingTransformer.forward,
            streaming_increment_steps=streaming_module.increment_steps,
        )
        import muscriptor.models.lm as lm_module
        _ORIGINALS["lm_increment_steps"] = lm_module.increment_steps

    attn.init_state = _attn_init_state
    attn.increment_step = _attn_increment
    attn._complete_kv = _complete_kv
    attn.forward = _attn_forward
    transformer_module.StreamingTransformer.init_state = _transformer_init_state
    transformer_module.StreamingTransformer.increment_step = _transformer_increment
    transformer_module.StreamingTransformer.forward = _transformer_forward
    streaming_module.increment_steps = _cached_increment_steps

    import muscriptor.models.lm as lm_module
    lm_module.increment_steps = _cached_increment_steps
    _PATCHED = True


def reset_torch_patches() -> None:
    """Restore the official MuScriptor 0.2.1 runtime for fallback runs."""
    global _PATCHED
    if not _PATCHED or not _ORIGINALS:
        return
    attn = transformer_module.StreamingMultiheadAttention
    attn.init_state = _ORIGINALS["attn_init_state"]
    attn.increment_step = _ORIGINALS["attn_increment_step"]
    attn._complete_kv = _ORIGINALS["attn_complete_kv"]
    attn.forward = _ORIGINALS["attn_forward"]
    transformer_module.StreamingTransformer.init_state = _ORIGINALS["transformer_init_state"]
    transformer_module.StreamingTransformer.increment_step = _ORIGINALS["transformer_increment_step"]
    transformer_module.StreamingTransformer.forward = _ORIGINALS["transformer_forward"]
    streaming_module.increment_steps = _ORIGINALS["streaming_increment_steps"]
    import muscriptor.models.lm as lm_module
    lm_module.increment_steps = _ORIGINALS["lm_increment_steps"]
    _ATTN_BIAS_CACHE.clear()
    _PATCHED = False
