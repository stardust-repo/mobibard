from __future__ import annotations

from copy import deepcopy
import gc
import traceback
from pathlib import Path

import torch

from config import load_settings
from cpu_backend import prepare_and_load_cpu
from derive_cuda import FORMAT, derive_cuda
from model_common import ensure_original, validate_derived
from prompts import ask_yes_no, print_oom_help
from torch_backend import load_derived_cuda, load_fp32_cuda, load_original
from web_runtime import serve

ROOT = Path(__file__).resolve().parents[1]


def prepare_derived(settings, weights, config):
    size = settings["model"]["name"]
    precision = settings["model"]["quantization"]
    if precision == "fp32":
        return None
    target = ROOT / "models" / "derived" / "cuda" / precision / size
    valid, reason = validate_derived(target, FORMAT, size, precision)
    if not valid and target.exists() and any(target.iterdir()):
        print(f"파생 모델 구성 이상: {reason}")
        if ask_yes_no("파생 모델을 삭제하고 다시 만들까요?", True):
            import shutil
            shutil.rmtree(target)
        else:
            raise RuntimeError("파생 모델 재생성을 취소했습니다.")
    if not target.exists() or not validate_derived(target, FORMAT, size, precision)[0]:
        derive_cuda(
            size,
            precision,
            weights,
            config,
            target,
            batch_size=int(settings["options"]["batch_size"]),
        )
    return target


def _original_settings(settings):
    effective = deepcopy(settings)
    effective["model"]["quantization"] = "official"
    effective["model"]["kv_cache"] = "official"
    return effective


def run_cpu(weights, config, settings):
    model = prepare_and_load_cpu(
        root=ROOT,
        size=settings["model"]["name"],
        requested_precision=settings["model"]["quantization"],
        requested_kv=settings["model"]["kv_cache"],
        source_weights=weights,
        source_config=config,
        batch_size=int(settings["options"]["batch_size"]),
    )
    label = (
        f"CPU / "
        f"{getattr(model, '_effective_precision', 'fp32').upper()} / "
        f"{getattr(model, '_effective_kv', 'fp32').upper()} KV"
    )
    serve(model, settings, label)


def run_original_cpu(weights, settings):
    model = load_original(weights, "cpu")
    serve(model, _original_settings(settings), "CPU / official original FP32")


def run_original_gpu(weights, settings):
    model = load_original(weights, "cuda")
    serve(model, _original_settings(settings), "NVIDIA CUDA / official original")


def run_selected(weights, derived, settings):
    precision = settings["model"]["quantization"]
    kv = settings["model"]["kv_cache"]
    beam = int(settings["options"]["beam_size"])
    if kv == "q8" and beam != 1:
        print("Q8 KV는 beam_size=1만 지원하므로 상위 정밀도로 자동 승격합니다.")
        kv = "fp16"
    if precision == "fp32":
        model = load_fp32_cuda(weights, kv)
    else:
        model = load_derived_cuda(derived, kv)
    label = (
        f"NVIDIA CUDA / "
        f"{getattr(model, '_effective_precision', precision).upper()} / "
        f"{getattr(model, '_effective_kv', kv).upper()} KV"
    )
    serve(model, settings, label)


def main() -> int:
    settings = load_settings(ROOT)
    size = settings["model"]["name"]
    use_original = bool(settings["model"]["use_original"])
    use_gpu = bool(settings["options"]["use_gpu"])
    ask = bool(settings["options"].get("ask_fallback", True))

    weights, config = ensure_original(ROOT, size)

    if use_original:
        if not use_gpu:
            run_original_cpu(weights, settings)
            return 0
        if not torch.cuda.is_available():
            print("GPU 사용이 요청되었지만 CUDA를 사용할 수 없습니다.")
            if ask and ask_yes_no("원본 CPU로 실행할까요?", True):
                run_original_cpu(weights, settings)
                return 0
            return 2
        try:
            run_original_gpu(weights, settings)
            return 0
        except Exception as exc:
            print(f"\n원본 CUDA 실행 실패: {exc}")
            if "out of memory" in str(exc).lower():
                print_oom_help(size, settings["options"]["batch_size"])
            if ask and ask_yes_no("원본 CPU로 실행할까요?", True):
                run_original_cpu(weights, settings)
                return 0
            raise

    if not use_gpu:
        run_cpu(weights, config, settings)
        return 0

    if not torch.cuda.is_available():
        print("CUDA를 사용할 수 없습니다.")
        if ask and ask_yes_no(
            "CPU에서 요청 정밀도를 시도하고, 미지원이면 상위 정밀도로 실행할까요?",
            True,
        ):
            run_cpu(weights, config, settings)
            return 0
        return 2

    derived = None
    try:
        derived = prepare_derived(settings, weights, config)
        run_selected(weights, derived, settings)
        return 0
    except Exception as exc:
        traceback.print_exc()
        print(f"\n선택한 GPU 모델 실행 실패: {exc}")
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        is_oom = "out of memory" in str(exc).lower()
        if is_oom:
            print_oom_help(size, settings["options"]["batch_size"])

        if derived is not None and not is_oom and ask and ask_yes_no(
            "파생 모델을 삭제하고 다시 생성해 한 번 더 시도할까요?",
            False,
        ):
            try:
                import shutil
                shutil.rmtree(derived, ignore_errors=True)
                derived = prepare_derived(settings, weights, config)
                run_selected(weights, derived, settings)
                return 0
            except Exception as retry_exc:
                print(f"파생 모델 재생성 후에도 실패했습니다: {retry_exc}")
                gc.collect()
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()

        if ask and ask_yes_no("공식 원본 CUDA 모델로 다시 실행할까요?", True):
            try:
                run_original_gpu(weights, settings)
                return 0
            except Exception as original_exc:
                print(f"공식 원본 CUDA도 실패했습니다: {original_exc}")
                if "out of memory" in str(original_exc).lower():
                    print_oom_help(size, settings["options"]["batch_size"])

        if ask and ask_yes_no(
            "CPU에서 Q8→16비트→FP32 순서로 가능한 경로를 시도할까요?",
            True,
        ):
            run_cpu(weights, config, settings)
            return 0
        return 2


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except SystemExit:
        raise
    except Exception as exc:
        from datetime import datetime

        log_dir = ROOT / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_path = log_dir / f"run_error_{datetime.now():%Y%m%d_%H%M%S}.log"
        details = traceback.format_exc()
        log_path.write_text(details, encoding="utf-8")
        print(details)
        print(f"[실행 실패] {exc}")
        print(f"전체 오류 로그: {log_path}")
        raise SystemExit(1)
