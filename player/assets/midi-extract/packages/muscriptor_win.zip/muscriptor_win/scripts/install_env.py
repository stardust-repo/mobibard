from __future__ import annotations

import argparse
import importlib.metadata
import os
import platform
import subprocess
import sys
import traceback
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LOG_DIR = ROOT / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)
LOG_PATH = LOG_DIR / f"install_{datetime.now():%Y%m%d_%H%M%S}.log"

def run(command: list[str]) -> None:
    print("\n>", " ".join(command))
    with LOG_PATH.open("a", encoding="utf-8") as log:
        log.write("\n> " + " ".join(command) + "\n")
        process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            env={**os.environ, "PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8"},
        )
        assert process.stdout is not None
        for line in process.stdout:
            print(line, end="")
            log.write(line)
        code = process.wait()
    if code != 0:
        raise RuntimeError(f"명령 실패({code}): {' '.join(command)}")

def version_of(name: str) -> str:
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return "미설치"

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--platform", choices=["windows", "mac"], required=True)
    args = parser.parse_args()

    print("Python:", sys.version.replace("\n", " "))
    print("실행 파일:", sys.executable)
    print("설치 로그:", LOG_PATH)

    if sys.version_info < (3, 10):
        raise RuntimeError("Python 3.10 이상이 필요합니다.")

    pip = [sys.executable, "-m", "pip"]
    run(pip + ["install", "--upgrade", "pip", "setuptools", "wheel"])
    run(pip + ["install", "--upgrade",
               "muscriptor==0.2.1",
               "huggingface_hub>=1.0",
               "safetensors>=0.4",
               "tomli>=2.0",
               "fastapi>=0.136.3",
               "uvicorn[standard]>=0.48.0",
               "python-multipart>=0.0.29",
               "soundfile>=0.14.0"])

    if args.platform == "windows":
        try:
            run(pip + ["install", "--upgrade", "--force-reinstall",
                       "torch", "--index-url", "https://download.pytorch.org/whl/cu128"])
        except Exception as exc:
            print(f"[경고] CUDA PyTorch 설치 실패: {exc}")
            print("CPU용 PyTorch 설치를 시도합니다.")
            run(pip + ["install", "--upgrade", "torch"])


    else:
        if platform.machine() == "arm64":
            try:
                run(pip + ["install", "--upgrade", "mlx==0.32.0", "mlx-lm==0.31.3"])
            except Exception as exc:
                print(f"[경고] MLX 설치 실패: {exc}")
                print("원본 PyTorch MPS/CPU 실행은 계속 사용할 수 있습니다.")
        else:
            print("Intel Mac: MLX를 설치하지 않고 CPU 원본 실행만 사용합니다.")

    import torch
    print("\n[설치 확인]")
    print("muscriptor:", version_of("muscriptor"))
    print("huggingface_hub:", version_of("huggingface_hub"))
    print("PyTorch:", torch.__version__)
    try:
        print("CPU capability:", torch.backends.cpu.get_cpu_capability())
    except Exception:
        print("CPU capability: unknown")
    print("Quantized engines:", torch.backends.quantized.supported_engines)
    if args.platform == "windows":
        print("CUDA build:", torch.version.cuda)
        print("CUDA available:", torch.cuda.is_available())
        if torch.cuda.is_available():
            print("GPU:", torch.cuda.get_device_name(0))
    else:
        print("Architecture:", platform.machine())
        if platform.machine() == "arm64":
            import mlx.core as mx
            print("MLX:", version_of("mlx"))
            print("MLX-LM:", version_of("mlx-lm"))
            print("Metal available:", mx.metal.is_available())
            if mx.metal.is_available():
                print("Metal device:", mx.metal.device_info())

    print("\n환경 설치가 완료되었습니다.")
    return 0

if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception:
        traceback.print_exc()
        print(f"\n[설치 실패] 전체 로그: {LOG_PATH}")
        print("인터넷 연결, Python 버전, 디스크 공간을 확인한 뒤 다시 실행하세요.")
        raise SystemExit(1)
