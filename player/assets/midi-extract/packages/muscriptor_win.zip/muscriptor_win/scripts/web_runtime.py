from __future__ import annotations

import threading
import time
import webbrowser
from importlib.resources import files
from pathlib import Path

import uvicorn
from muscriptor.server import create_app

class ConfiguredModel:
    def __init__(self, base, settings: dict):
        self._base = base
        self._options = settings["options"]

    def __getattr__(self, name):
        return getattr(self._base, name)

    def transcribe(self, audio, instruments=None, **_server_defaults):
        selected = instruments or self._options.get("instruments") or None
        return self._base.transcribe(
            audio,
            instruments=selected,
            batch_size=int(self._options.get("batch_size", 6)),
            use_sampling=bool(self._options.get("sampling", False)),
            temperature=float(self._options.get("temperature", 1.0)),
            cfg_coef=float(self._options.get("guidance_weight", 1.0)),
            beam_size=int(self._options.get("beam_size", 1)),
            no_eos_is_ok=not bool(self._options.get("strict_eos", False)),
        )

def find_web_dir() -> Path | None:
    candidate = Path(str(files("muscriptor").joinpath("web_dist")))
    return candidate if candidate.is_dir() else None

def serve(model, settings: dict, mode_label: str) -> None:
    server = settings["server"]
    host = str(server.get("host", "0.0.0.0"))
    port = int(server.get("port", 8222))
    app = create_app(ConfiguredModel(model, settings), web_dir=find_web_dir())

    print("\n==========================================")
    print("MuScriptor 모드 :", mode_label)
    print("모델            :", settings["model"]["name"])
    print("요청 모델 정밀도:", settings["model"]["quantization"])
    print("실제 모델 정밀도:", getattr(model, "_effective_precision", settings["model"]["quantization"]))
    print("요청 KV 캐시    :", settings["model"]["kv_cache"])
    print("실제 KV 캐시    :", getattr(model, "_effective_kv", settings["model"]["kv_cache"]))
    print("배치            :", settings["options"]["batch_size"])
    print("로컬 주소       :", f"http://127.0.0.1:{port}/")
    print("바인딩          :", f"{host}:{port}")
    print("종료            : Control + C")
    print("==========================================\n")

    if bool(server.get("open_browser", True)):
        def open_later():
            time.sleep(4)
            webbrowser.open(f"http://127.0.0.1:{port}/")
        threading.Thread(target=open_later, daemon=True).start()

    uvicorn.run(app, host=host, port=port)
