from __future__ import annotations

import gc
import json
import shutil
from pathlib import Path

import torch
from safetensors import safe_open
from safetensors.torch import save_file

from model_common import (
    is_condition_key,
    is_ffn_weight,
    is_token_round_weight,
    remap_key,
    token_linear_module_path,
    validate_derived,
)
from q8_cuda_backends import BACKEND_NAME, save_backend_module
from position_table import build_position_table

FORMAT = "muscriptor-cuda-token-round-v5"


def derive_cuda(size: str, precision: str, source_weights: Path, source_config: Path,
                output_dir: Path, batch_size: int = 6) -> Path:
    del batch_size
    valid, _ = validate_derived(output_dir, FORMAT, size, precision)
    if valid:
        return output_dir
    if precision not in {"fp16", "q8"}:
        raise ValueError("CUDA 파생은 fp16 또는 q8만 생성합니다.")

    building = output_dir.with_name(output_dir.name + ".building")
    if building.exists(): shutil.rmtree(building)
    (building / "weights").mkdir(parents=True)
    shutil.copy2(source_config, building / "config.json")

    config_data = json.loads(
        source_config.read_text(encoding="utf-8")
    )
    position_table = build_position_table(
        int(config_data["dim"]),
        dtype=torch.float16,
    )
    save_file(
        {"position_table": position_table},
        building / "position_table.safetensors",
    )
    del position_table

    entries=[]
    print(f"\n[{size}] CUDA {precision} 토큰 라운드 파생 생성")
    print("- 오디오 전처리/conditioner: FP32 원본")
    print("- Attention/QKV/embedding/norm/output head: FP16")
    if precision == "q8":
        print("- 정수 Q8: FFN linear1 + linear2만")
        print("- Q8 적용: FFN linear1 + linear2")

    with safe_open(source_weights, framework="pt", device="cpu") as handle:
        keys=list(handle.keys())
        for index, source_key in enumerate(keys,1):
            key=remap_key(source_key); tensor=handle.get_tensor(source_key); base=f"{index:05d}"
            if is_condition_key(key):
                filename=base+".safetensors"; stored=tensor.contiguous()
                save_file({"value":stored}, building/"weights"/filename)
                kind="fp32"; module_path=None; del stored
            elif precision=="q8" and is_ffn_weight(key):
                filename=base+".pt"
                save_backend_module(tensor.to(torch.float16), building/"weights"/filename)
                kind="q8_module"; module_path=token_linear_module_path(key)
            else:
                filename=base+".safetensors"
                dtype=torch.float16 if is_token_round_weight(key) else tensor.dtype
                stored=tensor.to(dtype=dtype).contiguous()
                save_file({"value":stored}, building/"weights"/filename)
                kind="fp16" if stored.dtype==torch.float16 else "fp32"; module_path=None; del stored
            entries.append({"name":key,"file":f"weights/{filename}","kind":kind,
                            "module_path":module_path,"shape":list(tensor.shape)})
            del tensor
            if index%20==0 or index==len(keys):
                print(f"  {index}/{len(keys)} tensors"); gc.collect()
                if torch.cuda.is_available(): torch.cuda.empty_cache()

    manifest={"format":FORMAT,"model_size":size,"precision":precision,
              "effective_precision":precision,
              "backend":"q8" if precision=="q8" else "fp16",
              "token_dtype":"float16","position_table_file":"position_table.safetensors","condition_compute":"cpu_fp32",
              "q8_scope":"transformer FFN linear1 + linear2 only" if precision=="q8" else "none",
              "q8_algorithm":"per-output-row symmetric int8 + fp16 scale" if precision=="q8" else None,
              "entries":entries}
    (building/"manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    if output_dir.exists(): shutil.rmtree(output_dir)
    output_dir.parent.mkdir(parents=True,exist_ok=True); building.replace(output_dir)
    return output_dir
