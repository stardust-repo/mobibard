from __future__ import annotations

import json
import os
import platform
import shutil
import tempfile
import time
from pathlib import Path

import torch
import torch.nn as nn
from safetensors import safe_open
from safetensors.torch import load_file, save_file

from muscriptor.models.lm import TorchAutocast
from muscriptor.tokenizer.mt3 import MT3Tokenizer
from muscriptor.transcription_model import TranscriptionModel, _ModelConfig

from q8_cuda_backends import GenericDequantInt8Linear

from model_common import (
    is_condition_key,
    remap_key,
)
from torch_backend import CastConditionProvider, _set_tensor, build_sparse_model
from torch_patches import (
    apply_torch_patches,
    reset_torch_patches,
    resolve_torch_kv_mode,
)
from prompts import ask_yes_no

CPU16_FORMAT = "muscriptor-cpu-token16-v1"
CPUQ8_FORMAT = "muscriptor-cpu-q8-v4"


def configure_cpu_runtime() -> None:
    cores = max(1, os.cpu_count() or 1)
    threads = max(1, min(cores, 16))
    try:
        torch.set_num_threads(threads)
    except Exception:
        pass
    try:
        torch.set_num_interop_threads(max(1, min(4, threads // 2 or 1)))
    except RuntimeError:
        pass
    if hasattr(torch.backends, "mkldnn"):
        torch.backends.mkldnn.enabled = True

    arch = platform.machine().lower()
    engines = set(torch.backends.quantized.supported_engines)
    if arch in {"x86_64", "amd64"}:
        for name in ("x86", "fbgemm", "onednn"):
            if name in engines:
                torch.backends.quantized.engine = name
                break
    else:
        for name in ("qnnpack", "x86"):
            if name in engines:
                torch.backends.quantized.engine = name
                break


def _bench(module: nn.Module, x: torch.Tensor, *, steps: int = 30) -> float:
    module.eval()
    with torch.inference_mode():
        for _ in range(5):
            module(x)
        started = time.perf_counter()
        for _ in range(steps):
            module(x)
    return (time.perf_counter() - started) * 1000.0 / steps


def _make_linear(dim: int, out_dim: int, dtype: torch.dtype) -> nn.Linear:
    module = nn.Linear(dim, out_dim, bias=False, dtype=dtype).eval()
    module.weight.data.normal_(0.0, 0.02)
    return module


def select_cpu16_dtype(
    dim: int,
    batch_size: int,
) -> tuple[torch.dtype | None, dict]:
    """Choose the fastest functional 16-bit CPU dtype.

    A working 16-bit request is not discarded only because FP32 is faster.
    FP32 is selected only when both BF16 and FP16 fail actual forward tests.
    """
    configure_cpu_runtime()
    x32 = torch.randn(
        max(1, batch_size),
        1,
        dim,
        dtype=torch.float32,
    )
    base = _make_linear(dim, 4 * dim, torch.float32)
    baseline_ms = _bench(base, x32)
    results = {"fp32_ms": baseline_ms}

    functional: list[tuple[float, torch.dtype]] = []
    for dtype in (torch.bfloat16, torch.float16):
        name = str(dtype).removeprefix("torch.")
        try:
            module = _make_linear(dim, 4 * dim, dtype)
            x = x32.to(dtype=dtype)
            elapsed = _bench(module, x)
            results[name + "_ms"] = elapsed
            results[name + "_reason"] = (
                f"기능 정상, FP32 대비 "
                f"{elapsed / max(baseline_ms, 1e-9):.2f}배"
            )
            functional.append((elapsed, dtype))
        except Exception as exc:
            results[name + "_error"] = str(exc)

    if not functional:
        return None, results
    functional.sort(key=lambda item: item[0])
    return functional[0][1], results


def _quantize_generic_cpu(module: nn.Linear) -> nn.Module:
    return GenericDequantInt8Linear.from_weight(module.weight.detach())


def _serialization_test(module: nn.Module, x: torch.Tensor) -> None:
    with torch.inference_mode():
        expected = module(x)
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "module.pt"
        torch.save(module, path)
        restored = torch.load(path, map_location="cpu", weights_only=False)
        with torch.inference_mode():
            actual = restored(x)
        if actual.shape != expected.shape or not torch.isfinite(actual).all():
            raise RuntimeError("CPU Q8 module 저장/재로드 테스트 실패")


def select_cpu_q8_backend(dim: int, batch_size: int) -> tuple[str | None, dict]:
    configure_cpu_runtime()
    x = torch.randn(max(1, batch_size), 1, dim, dtype=torch.float16)
    results: dict[str, object] = {}
    try:
        module = _quantize_generic_cpu(_make_linear(dim, 4 * dim, torch.float16))
        _serialization_test(module, x)
        results["q8_ms"] = _bench(module, x)
        results["q8_reason"] = "기능·저장·재로드 검사 통과"
        return "q8", results
    except Exception as exc:
        results["q8_error"] = str(exc)
        return None, results


def _read_config(path: Path) -> _ModelConfig:
    data = json.loads(path.read_text(encoding="utf-8"))
    return _ModelConfig(
        dim=int(data["dim"]),
        num_heads=int(data["num_heads"]),
        num_layers=int(data["num_layers"]),
        card=int(data["card"]),
    )


def derive_cpu16(
    *,
    size: str,
    source_weights: Path,
    source_config: Path,
    output_dir: Path,
    dtype: torch.dtype,
    benchmark: dict,
) -> Path:
    dtype_name = str(dtype).removeprefix("torch.")
    manifest_path = output_dir / "manifest.json"
    if manifest_path.is_file():
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            if manifest.get("format") == CPU16_FORMAT and manifest.get("dtype") == dtype_name:
                return output_dir
        except Exception:
            pass

    building = output_dir.with_name(output_dir.name + ".building")
    if building.exists():
        shutil.rmtree(building)
    (building / "weights").mkdir(parents=True)
    shutil.copy2(source_config, building / "config.json")

    entries = []
    with safe_open(source_weights, framework="pt", device="cpu") as handle:
        keys = list(handle.keys())
        for index, source_key in enumerate(keys, 1):
            key = remap_key(source_key)
            tensor = handle.get_tensor(source_key)
            stored = tensor if is_condition_key(key) else tensor.to(dtype=dtype)
            filename = f"{index:05d}.safetensors"
            save_file({"value": stored.contiguous()}, building / "weights" / filename)
            entries.append({"name": key, "file": f"weights/{filename}", "kind": "fp32" if is_condition_key(key) else dtype_name})
            if index % 20 == 0 or index == len(keys):
                print(f"  CPU16 {index}/{len(keys)} tensors")

    manifest = {
        "format": CPU16_FORMAT,
        "model_size": size,
        "precision": "fp16",
        "dtype": dtype_name,
        "benchmark": benchmark,
        "entries": entries,
    }
    (building / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    if output_dir.exists():
        shutil.rmtree(output_dir)
    output_dir.parent.mkdir(parents=True, exist_ok=True)
    building.replace(output_dir)
    return output_dir


def _quantize_token_linears(model: nn.Module, backend: str) -> None:
    if backend != "q8":
        raise ValueError("CPU Q8 설정이 올바르지 않습니다.")
    for layer in model.transformer.layers:
        layer.linear1 = _quantize_generic_cpu(layer.linear1)
        layer.linear2 = _quantize_generic_cpu(layer.linear2)


def _cast_token_round_fp16(model: nn.Module) -> None:
    for name, parameter in model.named_parameters():
        if not name.startswith("condition_provider."):
            parameter.data = parameter.data.to(dtype=torch.float16)
    for name, buffer in list(model.named_buffers()):
        if name.startswith("condition_provider."):
            continue
        parent_name, attr = name.rsplit(".", 1) if "." in name else ("", name)
        parent = model.get_submodule(parent_name) if parent_name else model
        parent._buffers[attr] = buffer.to(dtype=torch.float16)
    model.condition_provider = CastConditionProvider(model.condition_provider, torch.float16)
    model.autocast = TorchAutocast(enabled=False)

def derive_cpu_q8(
    *,
    size: str,
    source_weights: Path,
    source_config: Path,
    output_dir: Path,
    backend: str,
    benchmark: dict,
) -> Path:
    manifest_path = output_dir / "manifest.json"
    if manifest_path.is_file() and (output_dir / "model.pt").is_file():
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            if manifest.get("format") == CPUQ8_FORMAT and manifest.get("backend") == backend:
                return output_dir
        except Exception:
            pass

    from muscriptor import TranscriptionModel

    print("CPU Q8 파생 모델을 생성합니다.")
    wrapper = TranscriptionModel.load_model(source_weights, device="cpu")
    model = wrapper._model.eval()
    _cast_token_round_fp16(model)
    _quantize_token_linears(model, backend)

    building = output_dir.with_name(output_dir.name + ".building")
    if building.exists():
        shutil.rmtree(building)
    building.mkdir(parents=True)
    torch.save(model, building / "model.pt")
    shutil.copy2(source_config, building / "config.json")
    manifest = {
        "format": CPUQ8_FORMAT,
        "model_size": size,
        "precision": "q8",
        "backend": "q8",
        "token_dtype": "float16",
        "q8_scope": "transformer FFN linear1 + linear2 only",
        "benchmark": benchmark,
    }
    (building / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    if output_dir.exists():
        shutil.rmtree(output_dir)
    output_dir.parent.mkdir(parents=True, exist_ok=True)
    building.replace(output_dir)
    return output_dir



def load_cpu16(model_dir: Path, kv_mode: str) -> TranscriptionModel:
    configure_cpu_runtime()
    manifest = json.loads((model_dir / "manifest.json").read_text(encoding="utf-8"))
    dtype = getattr(torch, manifest["dtype"])
    cfg = _read_config(model_dir / "config.json")
    effective_kv, kv_backend, _kv_reason = resolve_torch_kv_mode(
        kv_mode, device=torch.device("cpu"), token_dtype=dtype, group_size=64
    )
    reset_torch_patches()
    apply_torch_patches(effective_kv, 64, dtype, kv_backend=kv_backend)
    model = build_sparse_model(cfg)
    for index, entry in enumerate(manifest["entries"], 1):
        tensor = load_file(model_dir / entry["file"], device="cpu")["value"]
        _set_tensor(model, entry["name"], tensor)
        if index % 20 == 0 or index == len(manifest["entries"]):
            print(f"  CPU16 load {index}/{len(manifest['entries'])}")

    remaining = [name for name, tensor in list(model.named_parameters()) + list(model.named_buffers()) if tensor is not None and getattr(tensor, "is_meta", False)]
    if remaining:
        raise RuntimeError("CPU16 미로드 텐서: " + ", ".join(remaining[:10]))
    model.condition_provider = CastConditionProvider(model.condition_provider, dtype)
    model.autocast = TorchAutocast(enabled=False)
    model.eval()
    tokenizer = MT3Tokenizer(instrument_vocabulary="MT3_FULL_PLUS", max_shift_steps=1001)
    wrapper = TranscriptionModel(model=model, tokenizer=tokenizer, device=torch.device("cpu"))
    wrapper._effective_precision = manifest["dtype"]
    wrapper._effective_backend = "native_cpu16"
    wrapper._effective_kv = effective_kv
    wrapper._effective_kv_backend = kv_backend
    return wrapper


def load_cpu_q8(model_dir: Path, kv_mode: str) -> TranscriptionModel:
    configure_cpu_runtime()
    manifest = json.loads((model_dir / "manifest.json").read_text(encoding="utf-8"))
    token_dtype = torch.float16
    effective_kv, kv_backend, _kv_reason = resolve_torch_kv_mode(
        kv_mode, device=torch.device("cpu"), token_dtype=token_dtype, group_size=64
    )
    reset_torch_patches()
    apply_torch_patches(effective_kv, 64, token_dtype, kv_backend=kv_backend)
    model = torch.load(model_dir / "model.pt", map_location="cpu", weights_only=False).eval()
    tokenizer = MT3Tokenizer(instrument_vocabulary="MT3_FULL_PLUS", max_shift_steps=1001)
    wrapper = TranscriptionModel(model=model, tokenizer=tokenizer, device=torch.device("cpu"))
    wrapper._effective_precision = "q8"
    wrapper._effective_backend = "q8"
    wrapper._effective_kv = effective_kv
    wrapper._effective_kv_backend = kv_backend
    return wrapper


def _confirm_rebuild_if_present(target: Path, label: str) -> None:
    if not target.exists() or not any(target.iterdir()):
        return
    if ask_yes_no(f"{label} 구성이 올바르지 않습니다. 삭제하고 다시 만들까요?", True):
        shutil.rmtree(target, ignore_errors=True)
    else:
        raise RuntimeError(f"{label} 재생성을 취소했습니다.")


def prepare_and_load_cpu(
    *,
    root: Path,
    size: str,
    requested_precision: str,
    requested_kv: str,
    source_weights: Path,
    source_config: Path,
    batch_size: int,
) -> TranscriptionModel:
    configure_cpu_runtime()
    cfg = _read_config(source_config)

    if requested_precision == "q8":
        backend, benchmark = select_cpu_q8_backend(cfg.dim, batch_size)
        if backend is not None:
            target = root / "models" / "derived" / "cpu" / "q8" / size
            try:
                derive_cpu_q8(
                    size=size,
                    source_weights=source_weights,
                    source_config=source_config,
                    output_dir=target,
                    backend=backend,
                    benchmark=benchmark,
                )
                return load_cpu_q8(target, requested_kv)
            except Exception as exc:
                print(f"CPU Q8 파생/로드 실패: {exc}")
                if target.exists() and any(target.iterdir()):
                    _confirm_rebuild_if_present(target, "CPU Q8 파생 모델")
                    try:
                        derive_cpu_q8(
                            size=size,
                            source_weights=source_weights,
                            source_config=source_config,
                            output_dir=target,
                            backend=backend,
                            benchmark=benchmark,
                        )
                        return load_cpu_q8(target, requested_kv)
                    except Exception as retry_exc:
                        print(f"CPU Q8 재생성 후에도 실패: {retry_exc}")
                print("16비트 경로를 계속 시도합니다.")
        else:
            print("CPU Q8 기능 검사를 통과하지 못했습니다.")

    if requested_precision in {"q8", "fp16"}:
        dtype, benchmark = select_cpu16_dtype(cfg.dim, batch_size)
        if dtype is not None:
            dtype_name = str(dtype).removeprefix("torch.")
            target = root / "models" / "derived" / "cpu" / "fp16" / dtype_name / size
            try:
                derive_cpu16(
                    size=size,
                    source_weights=source_weights,
                    source_config=source_config,
                    output_dir=target,
                    dtype=dtype,
                    benchmark=benchmark,
                )
                return load_cpu16(target, requested_kv)
            except Exception as exc:
                print(f"CPU 16비트 파생/로드 실패({dtype_name}): {exc}")
                if target.exists() and any(target.iterdir()):
                    _confirm_rebuild_if_present(target, "CPU 16비트 파생 모델")
                    try:
                        derive_cpu16(
                            size=size,
                            source_weights=source_weights,
                            source_config=source_config,
                            output_dir=target,
                            dtype=dtype,
                            benchmark=benchmark,
                        )
                        return load_cpu16(target, requested_kv)
                    except Exception as retry_exc:
                        print(f"CPU 16비트 재생성 후에도 실패: {retry_exc}")
        print("CPU BF16/FP16 경로가 모두 기능 검사를 통과하지 못해 원본 FP32를 사용합니다.")

    from muscriptor import TranscriptionModel as OfficialModel

    effective_kv, kv_backend, _kv_reason = resolve_torch_kv_mode(
        requested_kv, device=torch.device("cpu"), token_dtype=torch.float32, group_size=64
    )
    reset_torch_patches()
    apply_torch_patches(effective_kv, 64, torch.float32, kv_backend=kv_backend)
    wrapper = OfficialModel.load_model(source_weights, device="cpu")
    wrapper._effective_precision = "fp32"
    wrapper._effective_backend = "official_cpu"
    wrapper._effective_kv = effective_kv
    wrapper._effective_kv_backend = kv_backend
    return wrapper
