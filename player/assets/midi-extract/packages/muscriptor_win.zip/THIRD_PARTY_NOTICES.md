# 제3자 라이선스 안내

## MuScriptor 소스 코드

- 프로젝트: https://github.com/muscriptor/muscriptor
- 이 패키지의 기준 버전: `v0.2.2`
- 기준 릴리스 커밋: `3feb249`
- 반영한 최신 웹 서버 커밋: `c3b82e7` (동일 MIT 라이선스)
- 저작권자: Kyutai x Mirelo
- 라이선스: MIT

이 패키지는 비공식 편의성 포크입니다. Kyutai, Mirelo 또는 공식 MuScriptor
프로젝트와 제휴·후원·승인 관계가 없습니다.

## MuScriptor 모델 가중치

- Hugging Face의 MuScriptor 조직에서 별도로 제공
- 라이선스: CC BY-NC 4.0 및 각 gated 모델 페이지의 추가 이용조건
- 이 ZIP에는 모델 파일을 포함하지 않음

자세한 내용은 `MODEL_TERMS_NOTICE.md`를 확인하세요.

## 주요 런타임 의존성

설치 스크립트는 각 공식 패키지 인덱스에서 의존성을 내려받습니다. 각 의존성은
자체 라이선스를 그대로 유지합니다.

- PyTorch — BSD 계열
- Hugging Face Hub — Apache-2.0
- safetensors — Apache-2.0
- FastAPI — MIT
- Uvicorn — BSD-3-Clause
- NumPy — BSD-3-Clause
- SoundFile — BSD-3-Clause
- Mido — MIT
- Einops — MIT

공식 웹 UI, SoundFont 및 실행 중 내려받는 자산도 각각의 원본 라이선스와
고지사항을 따릅니다.

## 웹 저장소 구분

- `muscriptor/muscriptor.github.io` (`9550a7c`)는 정적 음원 비교 사이트이며 이 ZIP에
  복사하지 않습니다.
- 실행형 웹 UI는 `muscriptor/muscriptor`의 공식 0.2.2 `web_dist`를 사용합니다.
- `scripts/official_server_latest.py`는 같은 MIT 저장소의 `c3b82e7` 서버 파일을
  출처 주석과 함께 포함합니다.
- `scripts/web_latest.py`는 해당 커밋의 탭별 `X-Client-Id` 동작을 기존 공식 번들에
  적용하는 이 포크의 호환 코드입니다.
