# 모델 라이선스 및 사용 안내

이 ZIP에는 MuScriptor 모델 가중치가 포함되어 있지 않습니다.

공식 모델 저장소는 다음과 같습니다.

- https://huggingface.co/MuScriptor/muscriptor-small
- https://huggingface.co/MuScriptor/muscriptor-medium
- https://huggingface.co/MuScriptor/muscriptor-large

모델 가중치는 **CC BY-NC 4.0**과 각 gated Hugging Face 모델 페이지에
표시된 추가 이용조건에 따라 제공됩니다. 사용자는 자신의 Hugging Face 계정으로
해당 조건을 직접 확인하고 동의한 뒤 모델을 내려받아야 합니다.

로컬에서 생성한 FP16, Q8, CUDA, MLX 파생 가중치도 공식 모델에서 파생된
자료입니다. 숫자 형식이나 저장 형식을 바꾸었다는 이유로 MIT 라이선스로
전환되지 않습니다. 비상업 제한을 포함한 원본 모델의 라이선스와 이용조건이
계속 적용되는 것으로 취급해야 합니다.

입력 음원, 작곡, 연주, 녹음물 및 생성 결과에 필요한 권리를 사용자가 직접
확보해야 합니다. 이 패키지는 입력물이나 결과물에 대한 별도 권리를 부여하지
않습니다.

이 문서는 공개된 라이선스를 정리한 안내이며 정식 법률 자문이 아닙니다.
