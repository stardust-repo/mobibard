@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
set HF_HUB_DISABLE_SYMLINKS_WARNING=1

if not exist ".venv\Scripts\python.exe" (
  echo [오류] 먼저 1_install.bat을 실행하세요.
  goto :end
)

".venv\Scripts\python.exe" "scripts\launcher.py"
:end
echo.
pause
endlocal
