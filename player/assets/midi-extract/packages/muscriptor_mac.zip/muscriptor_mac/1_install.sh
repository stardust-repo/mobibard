#!/bin/bash
set -u
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"
chmod u+rx ./*.sh 2>/dev/null || true
export PYTHONUTF8=1
export PYTHONIOENCODING=utf-8

finish() {
  code=$?
  echo
  read -r -p "Return 키를 누르면 창이 닫힙니다"
  exit $code
}
trap finish EXIT

PYTHON_BIN="${PYTHON_BIN:-python3}"
if ! command -v "$PYTHON_BIN" >/dev/null 2>&1; then
  echo "[오류] python3를 찾지 못했습니다."
  exit 1
fi

if [[ ! -x ".venv/bin/python" ]]; then
  "$PYTHON_BIN" -m venv .venv || exit 1
fi

".venv/bin/python" "scripts/install_env.py" --platform mac
