# MuScriptor Quick Distribution — AI 작업 명세

## 핵심 Q8 정책

모델 정수 양자화 범위는 고정되어 있다.

```text
Q8:
- transformer.layers.*.linear1
- transformer.layers.*.linear2

FP16:
- MIDI token embedding
- Attention Q/K/V projection
- Attention output projection
- LayerNorm / GELU / residual
- final MIDI output head
```

오디오 전처리와 condition provider는 FP32 원본이다. condition tensor는
prefill 직전에 token dtype으로 한 번 변환한다. KV 캐시는 모델 Q8과 독립적으로
`model.kv_cache` 설정을 따른다.

## Q8 실행 알고리즘

사용자에게 노출되는 모드는 `q8` 하나이며 적용 범위는 모든 플랫폼에서 동일하다.
Mac MLX 실행만 MLX 네이티브 저장·연산 형식을 사용한다.

```text
Mac MLX
quantization: mx.quantize(mode=affine, group_size=64, bits=8)
storage: packed weight + scales + biases
runtime: mx.quantized_matmul

Windows CUDA / CPU
quantization과 실행 방식: 기존 경로 유지
```

Mac MLX에서는 FFN weight를 activation dtype으로 직접 복원하는 코드를 사용하지 않는다.

## 파생 형식

- CUDA: `muscriptor-cuda-token-round-v4`
- MLX FP32/FP16: `muscriptor-mlx-token-round-v4`
- MLX Q8: `muscriptor-mlx-token-round-v5`
- CPU Q8: `muscriptor-cpu-q8-v3`

형식 버전이 다르면 기존 파생을 유효하지 않은 것으로 판정하고 재생성 여부를
사용자에게 묻는다.

## FP16 경로

conditioner를 제외한 token-round weight를 FP16으로 사전 저장한다. condition
output은 prefill 전에 한 번 FP16으로 변환한다. KV가 FP16이면 Attention 경계의
추가 dtype cast를 피한다. 최종 token 선택을 위한 logits 승격은 원본 안정성을
위한 예외다.

## KV 캐시

- Windows/CPU q8 KV: native extension 확인 후 INT8+scale 저장 및
  Attention 직전 활성 캐시 복원
- Mac q8 KV: MLX-LM QuantizedKVCache
- 모델 Q8 범위 변경은 KV 구현을 변경하지 않는다.

## 폴백

선택 파생 실행 실패 시 원본 GPU, 이후 원본/파생 CPU 실행 여부를 사용자에게
묻는다. OOM이면 batch, model size, KV precision, beam, CFG 조절 방법을 표시한다.

## 사용자 사전 준비

- Python 3.12/3.13 권장
- Hugging Face 계정 필요
- 선택 모델의 gated 페이지에서 라이선스·사용 조건 승인 필요
- 승인받은 계정으로 `hf auth login` 수행


## Q8 단일 모드 정책

사용자 설정과 로그에서 Q8은 한 가지 모드로만 취급한다.

```text
model.quantization = q8
model.kv_cache     = q8
```

내부 구현 이름을 별도 Q8 종류로 노출하지 않는다. Q8 기능 검사를 실패해
실제 정밀도가 FP16, BF16 또는 FP32로 변경된 경우에만 실제 정밀도 항목이
달라진다.
