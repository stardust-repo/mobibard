#!/bin/bash
set -u
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"
chmod u+rx ./*.sh 2>/dev/null || true
export PYTHONUTF8=1
export PYTHONIOENCODING=utf-8
export HF_HUB_DISABLE_SYMLINKS_WARNING=1

finish() {
  code=$?
  echo
  read -r -p "Return 키를 누르면 창이 닫힙니다"
  exit $code
}
trap finish EXIT

if [[ ! -x ".venv/bin/python" ]]; then
  echo "[오류] 먼저 bash ./1_install.sh 를 실행하세요."
  exit 1
fi

".venv/bin/python" "scripts/launcher.py"
