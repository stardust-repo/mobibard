from __future__ import annotations

from pathlib import Path

try:
    import tomllib
except ModuleNotFoundError:
    import tomli as tomllib

VALID_MODELS = {"small", "medium", "large"}
VALID_PRECISIONS = {"fp32", "fp16", "q8"}
VALID_KV = {"fp32", "fp16", "q8"}

def load_settings(root: Path) -> dict:
    with (root / "settings.toml").open("rb") as handle:
        data = tomllib.load(handle)

    server = data.setdefault("server", {})
    model = data.setdefault("model", {})
    options = data.setdefault("options", {})

    name = str(model.get("name", "medium")).lower()
    if name not in VALID_MODELS:
        raise ValueError("model.name은 small, medium, large 중 하나여야 합니다.")
    model["name"] = name

    precision = str(model.get("quantization", "fp16")).lower()
    if precision not in VALID_PRECISIONS:
        raise ValueError("model.quantization은 fp32, fp16, q8 중 하나여야 합니다.")
    model["quantization"] = precision

    kv = str(model.get("kv_cache", "fp16")).lower()
    if kv not in VALID_KV:
        raise ValueError("model.kv_cache는 fp32, fp16, q8 중 하나여야 합니다.")
    model["kv_cache"] = kv

    batch = int(options.get("batch_size", 6))
    if batch < 1:
        raise ValueError("options.batch_size는 1 이상이어야 합니다.")
    options["batch_size"] = batch

    temperature = float(options.get("temperature", 1.0))
    if temperature <= 0:
        raise ValueError("options.temperature는 0보다 커야 합니다.")
    options["temperature"] = temperature

    beam = int(options.get("beam_size", 1))
    if beam < 1:
        raise ValueError("options.beam_size는 1 이상이어야 합니다.")
    options["beam_size"] = beam

    port = int(server.get("port", 8222))
    if not 1 <= port <= 65535:
        raise ValueError("server.port 범위가 잘못되었습니다.")
    server["port"] = port
    return data
