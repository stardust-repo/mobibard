from __future__ import annotations

import gc
import json
import shutil
from pathlib import Path

import mlx.core as mx
import torch
from safetensors import safe_open
from safetensors.torch import save_file

from model_common import is_condition_key, is_ffn_weight, remap_key, validate_derived
from q8_cuda_backends import BACKEND_NAME, GenericDequantInt8Linear
from position_table import build_position_table

FORMAT = "muscriptor-mlx-token-round-v4"


def derive_mlx(size: str, precision: str, source_weights: Path, source_config: Path,
               output_dir: Path) -> Path:
    valid,_=validate_derived(output_dir,FORMAT,size,precision)
    if valid: return output_dir
    if precision not in {"fp32","fp16","q8"}: raise ValueError(precision)
    if not mx.metal.is_available(): raise RuntimeError("MLX Metal을 사용할 수 없습니다.")
    building=output_dir.with_name(output_dir.name+".building")
    if building.exists(): shutil.rmtree(building)
    (building/"weights").mkdir(parents=True); shutil.copy2(source_config,building/"config.json")
    token_dtype="float32" if precision=="fp32" else "float16"
    position_dtype = (
        torch.float32
        if token_dtype == "float32"
        else torch.float16
    )
    config_data = json.loads(
        source_config.read_text(encoding="utf-8")
    )
    position_table = build_position_table(
        int(config_data["dim"]),
        dtype=position_dtype,
    )
    save_file(
        {"position_table": position_table},
        building / "position_table.safetensors",
    )
    del position_table
    entries=[]
    print(f"\n[{size}] MLX {precision} 토큰 라운드 파생 생성")
    print("- 오디오 전처리/conditioner: FP32 원본")
    print(f"- 토큰 라운드 기본 dtype: {token_dtype}")
    if precision=="q8":
        print("- 정수 Q8: FFN linear1 + linear2만")
        print("- Q8 적용: FFN linear1 + linear2")
    with safe_open(source_weights,framework="pt",device="cpu") as handle:
        keys=list(handle.keys())
        for index,source_key in enumerate(keys,1):
            key=remap_key(source_key); tensor=handle.get_tensor(source_key)
            filename=f"{index:05d}.safetensors"; path=building/"weights"/filename
            if precision=="q8" and is_ffn_weight(key):
                module=GenericDequantInt8Linear.from_weight(tensor.to(torch.float16))
                save_file({"qweight":module.qweight.cpu(),"scale":module.weight_scale.cpu()},path)
                kind="q8_module"; del module
            else:
                if is_condition_key(key) or precision=="fp32": stored=tensor.contiguous(); kind="fp32"
                else: stored=tensor.to(torch.float16).contiguous(); kind="fp16"
                save_file({"value":stored},path); del stored
            entries.append({"name":key,"file":f"weights/{filename}","kind":kind,"shape":list(tensor.shape)})
            del tensor
            if index%20==0 or index==len(keys): print(f"  {index}/{len(keys)} tensors"); gc.collect(); mx.clear_cache()
    manifest={"format":FORMAT,"model_size":size,"precision":precision,
              "effective_precision":precision,
              "backend":"q8" if precision=="q8" else precision,
              "token_dtype":token_dtype,"position_table_file":"position_table.safetensors","condition_compute":"cpu_fp32",
              "q8_scope":"transformer FFN linear1 + linear2 only" if precision=="q8" else "none",
              "q8_algorithm":"per-output-row symmetric int8 + fp16 scale" if precision=="q8" else None,
              "entries":entries}
    (building/"manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    if output_dir.exists(): shutil.rmtree(output_dir)
    output_dir.parent.mkdir(parents=True,exist_ok=True); building.replace(output_dir)
    return output_dir
