from __future__ import annotations

import gc
import json
import shutil
from pathlib import Path

import mlx.core as mx
import torch
from safetensors import safe_open
from safetensors.torch import save_file

from model_common import is_condition_key, is_ffn_weight, remap_key, validate_derived
from position_table import build_position_table

FORMAT = "muscriptor-mlx-token-round-v4"
Q8_FORMAT = "muscriptor-mlx-token-round-v5"
Q8_GROUP_SIZE = 64
Q8_BITS = 8
Q8_MODE = "affine"


def expected_format(precision: str) -> str:
    return Q8_FORMAT if precision == "q8" else FORMAT


def derive_mlx(
    size: str,
    precision: str,
    source_weights: Path,
    source_config: Path,
    output_dir: Path,
) -> Path:
    derived_format = expected_format(precision)
    valid, _ = validate_derived(output_dir, derived_format, size, precision)
    if valid:
        return output_dir
    if precision not in {"fp32", "fp16", "q8"}:
        raise ValueError(precision)
    if not mx.metal.is_available():
        raise RuntimeError("MLX Metal을 사용할 수 없습니다.")

    mx.set_default_device(mx.gpu)
    building = output_dir.with_name(output_dir.name + ".building")
    if building.exists():
        shutil.rmtree(building)
    (building / "weights").mkdir(parents=True)
    shutil.copy2(source_config, building / "config.json")

    token_dtype = "float32" if precision == "fp32" else "float16"
    position_dtype = torch.float32 if token_dtype == "float32" else torch.float16
    config_data = json.loads(source_config.read_text(encoding="utf-8"))
    position_table = build_position_table(
        int(config_data["dim"]),
        dtype=position_dtype,
    )
    save_file(
        {"position_table": position_table},
        building / "position_table.safetensors",
    )
    del position_table

    entries = []
    print(f"\n[{size}] MLX {precision} 토큰 라운드 파생 생성")
    print("- 오디오 전처리/conditioner: FP32 원본")
    print(f"- 토큰 라운드 기본 dtype: {token_dtype}")
    if precision == "q8":
        print("- MLX 네이티브 Q8: FFN linear1 + linear2만")
        print(
            f"- mx.quantize: mode={Q8_MODE}, "
            f"group_size={Q8_GROUP_SIZE}, bits={Q8_BITS}"
        )

    with safe_open(source_weights, framework="pt", device="cpu") as handle:
        keys = list(handle.keys())
        for index, source_key in enumerate(keys, 1):
            key = remap_key(source_key)
            tensor = handle.get_tensor(source_key)
            filename = f"{index:05d}.safetensors"
            path = building / "weights" / filename
            entry = {
                "name": key,
                "file": f"weights/{filename}",
                "shape": list(tensor.shape),
            }

            if precision == "q8" and is_ffn_weight(key):
                if tensor.shape[-1] % Q8_GROUP_SIZE != 0:
                    raise RuntimeError(
                        f"{key} 입력 차원 {tensor.shape[-1]}은 "
                        f"MLX Q8 group_size={Q8_GROUP_SIZE}로 나누어지지 않습니다."
                    )
                source = mx.array(
                    tensor.to(torch.float16).contiguous().numpy()
                )
                weight, scales, biases = mx.quantize(
                    source,
                    group_size=Q8_GROUP_SIZE,
                    bits=Q8_BITS,
                    mode=Q8_MODE,
                )
                mx.eval(weight, scales, biases)
                mx.save_safetensors(
                    path,
                    {
                        "weight": weight,
                        "scales": scales,
                        "biases": biases,
                    },
                )
                entry["kind"] = "mlx_q8"
                entry["quantization"] = {
                    "group_size": Q8_GROUP_SIZE,
                    "bits": Q8_BITS,
                    "mode": Q8_MODE,
                }
                del source, weight, scales, biases
            else:
                if is_condition_key(key) or precision == "fp32":
                    stored = tensor.contiguous()
                    entry["kind"] = "fp32"
                else:
                    stored = tensor.to(torch.float16).contiguous()
                    entry["kind"] = "fp16"
                save_file({"value": stored}, path)
                del stored

            entries.append(entry)
            del tensor
            if index % 20 == 0 or index == len(keys):
                print(f"  {index}/{len(keys)} tensors")
                gc.collect()
                mx.clear_cache()

    manifest = {
        "format": derived_format,
        "model_size": size,
        "precision": precision,
        "effective_precision": precision,
        "backend": "q8" if precision == "q8" else precision,
        "token_dtype": token_dtype,
        "position_table_file": "position_table.safetensors",
        "condition_compute": "cpu_fp32",
        "q8_scope": (
            "transformer FFN linear1 + linear2 only"
            if precision == "q8"
            else "none"
        ),
        "q8_algorithm": (
            f"MLX affine packed Q8, group_size={Q8_GROUP_SIZE}, "
            f"bits={Q8_BITS}"
            if precision == "q8"
            else None
        ),
        "q8_runtime": (
            "mx.quantized_matmul" if precision == "q8" else None
        ),
        "entries": entries,
    }
    (building / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    if output_dir.exists():
        shutil.rmtree(output_dir)
    output_dir.parent.mkdir(parents=True, exist_ok=True)
    building.replace(output_dir)
    return output_dir
