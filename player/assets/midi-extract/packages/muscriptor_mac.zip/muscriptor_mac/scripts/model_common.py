from __future__ import annotations

import json
import re
import os
import shutil
import subprocess
import sys
from pathlib import Path

from huggingface_hub import get_token, hf_hub_download, whoami
from safetensors import safe_open

from prompts import ask_yes_no

REPOS = {
    "small": "MuScriptor/muscriptor-small",
    "medium": "MuScriptor/muscriptor-medium",
    "large": "MuScriptor/muscriptor-large",
}
EXPECTED = {
    "small": {"dim": 768, "num_heads": 12, "num_layers": 14, "card": 1393},
    "medium": {"dim": 1024, "num_heads": 16, "num_layers": 24, "card": 1395},
    "large": {"dim": 1536, "num_heads": 24, "num_layers": 48, "card": 1395},
}

def _hf_cli() -> str:
    name = "hf.exe" if os.name == "nt" else "hf"
    candidate = Path(sys.executable).parent / name
    return str(candidate) if candidate.exists() else name

def ensure_hf_token() -> str:
    token = get_token()
    if token:
        try:
            info = whoami(token=token)
            print("Hugging Face 계정:", info.get("name") or info.get("fullname") or "unknown")
            return token
        except Exception:
            token = None

    print("\nHugging Face 로그인이 필요합니다.")
    print("브라우저에서 선택한 MuScriptor 모델의 라이선스에 먼저 동의하세요.")
    result = subprocess.run(
        [_hf_cli(), "auth", "login", "--force"],
        env={**os.environ, "PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8"},
    )
    if result.returncode != 0:
        raise RuntimeError("Hugging Face 로그인에 실패했습니다.")
    token = get_token()
    if not token:
        raise RuntimeError("로그인 후 저장된 Hugging Face 토큰을 찾지 못했습니다.")
    return token

def _link_or_copy(source: Path, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        target.unlink()
    try:
        os.link(source, target)
    except OSError:
        shutil.copy2(source, target)

def validate_original(root: Path, size: str) -> tuple[bool, str]:
    model_dir = root / "models" / "original" / size
    weights = model_dir / "model.safetensors"
    config = model_dir / "config.json"
    if not weights.is_file() or not config.is_file():
        return False, "필수 파일이 없습니다."
    try:
        data = json.loads(config.read_text(encoding="utf-8"))
        for key, expected in EXPECTED[size].items():
            if int(data[key]) != expected:
                return False, f"config.json의 {key} 값이 예상과 다릅니다."
        with safe_open(weights, framework="pt", device="cpu") as handle:
            keys = set(handle.keys())
        if not any(k.endswith("in_proj_weight") for k in keys):
            return False, "Attention 가중치를 찾지 못했습니다."
        if not any(k.endswith("linear1.weight") for k in keys):
            return False, "FFN 가중치를 찾지 못했습니다."
    except Exception as exc:
        return False, str(exc)
    return True, "정상"

def ensure_original(root: Path, size: str) -> tuple[Path, Path]:
    valid, reason = validate_original(root, size)
    model_dir = root / "models" / "original" / size
    if valid:
        print("원본 모델 확인:", model_dir)
        return model_dir / "model.safetensors", model_dir / "config.json"

    if model_dir.exists() and any(model_dir.iterdir()):
        print(f"원본 모델 구성 이상: {reason}")
        if not ask_yes_no("원본 모델을 다시 설치할까요?", True):
            raise RuntimeError("원본 모델 재설치를 취소했습니다.")
        shutil.rmtree(model_dir)

    token = ensure_hf_token()
    repo = REPOS[size]
    print(f"\n원본 모델 다운로드: {repo}")
    try:
        cached_weights = Path(hf_hub_download(
            repo_id=repo, filename="model.safetensors", token=token
        ))
        cached_config = Path(hf_hub_download(
            repo_id=repo, filename="config.json", token=token
        ))
    except Exception as exc:
        raise RuntimeError(
            f"{repo} 다운로드 실패: {exc}\n"
            "해당 모델 페이지에서 라이선스 동의 여부와 로그인 계정을 확인하세요."
        ) from exc

    model_dir.mkdir(parents=True, exist_ok=True)
    _link_or_copy(cached_weights, model_dir / "model.safetensors")
    _link_or_copy(cached_config, model_dir / "config.json")

    valid, reason = validate_original(root, size)
    if not valid:
        raise RuntimeError(f"다운로드한 원본 모델 검증 실패: {reason}")
    return model_dir / "model.safetensors", model_dir / "config.json"

def remap_key(key: str) -> str:
    if key.startswith("emb.0."):
        return "emb." + key[len("emb.0."):]
    if key.startswith("linears.0."):
        return "linear." + key[len("linears.0."):]
    if key.startswith(("emb.1.", "linears.1.")):
        raise ValueError("두 개 이상의 codebook 체크포인트는 지원하지 않습니다.")
    return key

def is_condition_key(key: str) -> bool:
    return key.startswith("condition_provider.")

def is_ffn_weight(key: str) -> bool:
    return bool(re.fullmatch(
        r"transformer\.layers\.\d+\.linear[12]\.weight", key
    ))


def is_token_linear_weight(key: str) -> bool:
    """Backward-compatible alias for the fixed FFN-only Q8 policy."""
    return is_ffn_weight(key)


def token_linear_module_path(key: str) -> str:
    if not is_ffn_weight(key):
        raise ValueError(f"Not an FFN Q8 weight: {key}")
    return key.removesuffix(".weight")


def is_token_round_weight(key: str) -> bool:
    return not is_condition_key(key)


def validate_derived(path: Path, expected_format: str, size: str, precision: str) -> tuple[bool, str]:
    manifest_path = path / "manifest.json"
    if not manifest_path.is_file():
        return False, "manifest.json이 없습니다."
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        if manifest.get("format") != expected_format:
            return False, "파생 형식 버전이 다릅니다."
        if manifest.get("model_size") != size or manifest.get("precision") != precision:
            return False, "모델 또는 정밀도 설정이 다릅니다."
        entries = manifest.get("entries", [])
        if not entries:
            return False, "가중치 목록이 비어 있습니다."
        for entry in entries:
            if not (path / entry["file"]).is_file():
                return False, f"파생 파일 누락: {entry['file']}"
    except Exception as exc:
        return False, str(exc)
    return True, "정상"
