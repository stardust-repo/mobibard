from __future__ import annotations

from pathlib import Path

import torch
import torch.nn as nn
import torch.nn.functional as F


BACKEND_NAME = "q8"


class GenericDequantInt8Linear(nn.Module):
    """Portable per-output-row symmetric Q8 storage for FFN weights only."""

    def __init__(self, qweight: torch.Tensor, weight_scale: torch.Tensor) -> None:
        super().__init__()
        if qweight.ndim != 2 or qweight.dtype != torch.int8:
            raise TypeError("qweight must be a 2-D torch.int8 tensor")
        if weight_scale.ndim != 1 or weight_scale.numel() != qweight.shape[0]:
            raise ValueError("weight_scale must have one value per output row")
        self.register_buffer("qweight", qweight.contiguous())
        self.register_buffer("weight_scale", weight_scale.to(torch.float16).contiguous())
        self.in_features = int(qweight.shape[1])
        self.out_features = int(qweight.shape[0])

    @classmethod
    def from_weight(cls, weight: torch.Tensor) -> "GenericDequantInt8Linear":
        if weight.ndim != 2:
            raise ValueError("Q8 FFN weight must be a matrix")
        source = weight.detach().to(device="cpu", dtype=torch.float16).contiguous()
        scale = source.abs().amax(dim=1).clamp_min(torch.finfo(torch.float16).tiny) / 127.0
        qweight = torch.round(source / scale[:, None]).clamp(-127, 127).to(torch.int8)
        return cls(qweight, scale)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        dtype = x.dtype
        weight = self.qweight.to(dtype=dtype)
        weight = weight * self.weight_scale.to(dtype=dtype)[:, None]
        return F.linear(x, weight)


def save_backend_module(weight: torch.Tensor, path: Path) -> None:
    torch.save(GenericDequantInt8Linear.from_weight(weight), path)


def load_backend_module(path: Path, device: torch.device) -> nn.Module:
    module = torch.load(path, map_location=device, weights_only=False)
    if not isinstance(module, GenericDequantInt8Linear):
        raise TypeError(f"Unexpected Q8 module type: {type(module).__name__}")
    return module.eval()
