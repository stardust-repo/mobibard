from __future__ import annotations

def ask_yes_no(message: str, default: bool = True) -> bool:
    suffix = "[Y/n]" if default else "[y/N]"
    while True:
        answer = input(f"{message} {suffix}: ").strip().lower()
        if not answer:
            return default
        if answer in {"y", "yes", "예", "네"}:
            return True
        if answer in {"n", "no", "아니오", "아니요"}:
            return False
        print("y 또는 n을 입력하세요.")

def print_oom_help(model_name: str, batch_size: int) -> None:
    print("\n[메모리 부족 조절 안내]")
    print(f"- 현재 모델: {model_name}, 배치: {batch_size}")
    print("- settings.toml에서 batch_size를 1~2로 낮춰 보세요.")
    print("- large → medium → small 순서로 모델을 낮춰 보세요.")
    print("- 모델 또는 KV 캐시를 fp16으로 설정하세요.")
    print("- beam_size=1, guidance_weight=1.0을 유지하세요.")
    print("- Q8 KV는 메모리는 작지만 처리시간이 크게 늘 수 있습니다.\n")
