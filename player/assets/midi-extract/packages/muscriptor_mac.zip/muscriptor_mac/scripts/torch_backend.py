from __future__ import annotations

import gc
import json
from pathlib import Path

import torch
import torch.nn as nn
from safetensors.torch import load_file

from muscriptor.models.lm import LMModel, TorchAutocast
from muscriptor.modules.conditioners import (
    ClassConditioner,
    ConditioningProvider,
    MelSpectrogramConditioner,
)
from muscriptor.tokenizer.mt3 import MT3Tokenizer
from muscriptor.transcription_model import (
    TranscriptionModel,
    _ModelConfig,
)

from q8_cuda_backends import load_backend_module
from torch_patches import apply_torch_patches, reset_torch_patches


def build_sparse_model(cfg: _ModelConfig, *, condition_device: str = "cpu") -> LMModel:
    mel = MelSpectrogramConditioner(
        output_dim=cfg.dim,
        device=condition_device,
        sample_rate=16000,
        n_fft=2048,
        frame_rate=100,
        n_mel_bins=512,
        log_scale=True,
        eps=1e-6,
        normalize_audio=False,
    )
    inst = ClassConditioner(1000, cfg.dim, device=condition_device)
    dataset = ClassConditioner(4, cfg.dim, device=condition_device)
    provider = ConditioningProvider(
        {"self_wav": mel, "instrument_group": inst, "dataset_name": dataset},
        device=condition_device,
    )
    return LMModel(
        condition_provider=provider,
        card=cfg.card,
        dim=cfg.dim,
        num_heads=cfg.num_heads,
        hidden_scale=4,
        cfg_coef=1.0,
        autocast=TorchAutocast(enabled=False),
        num_layers=cfg.num_layers,
        max_period=10000,
        device=torch.device("meta"),
    )


def _set_tensor(model: nn.Module, key: str, tensor: torch.Tensor) -> None:
    if "." in key:
        parent_path, attr = key.rsplit(".", 1)
        parent = model.get_submodule(parent_path)
    else:
        parent, attr = model, key
    if attr in parent._parameters:
        parent._parameters[attr] = nn.Parameter(tensor, requires_grad=False)
    elif attr in parent._buffers:
        parent._buffers[attr] = tensor
    else:
        raise KeyError(key)


def _replace_module(model: nn.Module, path: str, module: nn.Module) -> None:
    parent_path, attr = path.rsplit(".", 1)
    parent = model.get_submodule(parent_path)
    setattr(parent, attr, module)
    if attr == "in_proj_module":
        # Remove the unused meta parameter. The attention patch calls the module.
        parent._parameters["in_proj_weight"] = None


class CastConditionProvider(nn.Module):
    """Run the official condition encoder in FP32 and cast once at prefill."""

    def __init__(self, base: nn.Module, dtype: torch.dtype):
        super().__init__()
        self.base = base
        self.dtype = dtype
        self.device = base.device
        self.conditioners = base.conditioners

    def tokenize(self, inputs):
        return self.base.tokenize(inputs)

    def forward(self, tokenized):
        result = self.base(tokenized)
        return {
            key: (condition.to(dtype=self.dtype), mask)
            for key, (condition, mask) in result.items()
        }


def _config(model_dir: Path) -> _ModelConfig:
    data = json.loads((model_dir / "config.json").read_text(encoding="utf-8"))
    return _ModelConfig(
        dim=int(data["dim"]),
        num_heads=int(data["num_heads"]),
        num_layers=int(data["num_layers"]),
        card=int(data["card"]),
    )


def resolve_cuda_kv_mode(requested: str) -> str:
    if requested != "q8":
        return requested
    # Native PyTorch SDPA has no direct INT8 KV input. The older full-cache
    # dequantization path is deliberately not selected because it is a known
    # performance regression. Prefer the next higher precision.
    print("[성능 보호] 네이티브 Windows INT8 KV Attention을 사용할 수 없습니다.")
    print("kv_cache=q8 요청을 fp16으로 자동 승격합니다.")
    return "fp16"


def load_derived_cuda(model_dir: Path, kv_mode: str, kv_group_size: int = 64):
    manifest = json.loads((model_dir / "manifest.json").read_text(encoding="utf-8"))
    cfg = _config(model_dir)
    device = torch.device("cuda")
    token_dtype = torch.float16
    effective_kv = resolve_cuda_kv_mode(kv_mode)

    reset_torch_patches()
    apply_torch_patches(effective_kv, kv_group_size, token_dtype)
    model = build_sparse_model(cfg)

    for index, entry in enumerate(manifest["entries"], 1):
        path = model_dir / entry["file"]
        key = entry["name"]
        if entry["kind"] == "q8_module":
            module = load_backend_module(path, device)
            _replace_module(model, entry["module_path"], module)
        else:
            payload = load_file(path, device="cpu")
            tensor = payload["value"].to(device=device)
            _set_tensor(model, key, tensor)
        if index % 20 == 0 or index == len(manifest["entries"]):
            print(f"  load {index}/{len(manifest['entries'])}")

    remaining = [
        name
        for name, tensor in list(model.named_parameters()) + list(model.named_buffers())
        if tensor is not None and getattr(tensor, "is_meta", False)
    ]
    if remaining:
        raise RuntimeError("로드되지 않은 모델 텐서: " + ", ".join(remaining[:10]))

    model.condition_provider.device = device
    for conditioner in model.condition_provider.conditioners.values():
        if hasattr(conditioner, "device"):
            conditioner.device = device
    model.condition_provider = CastConditionProvider(model.condition_provider, token_dtype)
    model.autocast = TorchAutocast(enabled=False)
    model.eval()

    tokenizer = MT3Tokenizer(
        instrument_vocabulary="MT3_FULL_PLUS", max_shift_steps=1001
    )
    gc.collect()
    torch.cuda.empty_cache()
    wrapper = TranscriptionModel(model=model, tokenizer=tokenizer, device=device)
    wrapper._effective_precision = manifest.get("effective_precision", manifest["precision"])
    wrapper._effective_backend = manifest.get("backend", "fp16")
    wrapper._effective_kv = effective_kv
    return wrapper


def load_fp32_cuda(weights: Path, kv_mode: str, kv_group_size: int = 64):
    from muscriptor import TranscriptionModel

    effective_kv = resolve_cuda_kv_mode(kv_mode)
    reset_torch_patches()
    apply_torch_patches(effective_kv, kv_group_size, torch.float32)
    model = TranscriptionModel.load_model(weights, device="cuda")
    # fp32 means no CUDA autocast in the token loop.
    model._model.autocast = TorchAutocast(enabled=False)
    model._effective_precision = "fp32"
    model._effective_backend = "native"
    model._effective_kv = effective_kv
    return model


def load_original(weights: Path, device: str):
    from muscriptor import TranscriptionModel

    reset_torch_patches()
    return TranscriptionModel.load_model(weights, device=device)
