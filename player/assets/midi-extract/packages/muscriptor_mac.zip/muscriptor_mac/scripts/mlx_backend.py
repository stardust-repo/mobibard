from __future__ import annotations

import json
import math
import warnings
from dataclasses import dataclass
from pathlib import Path

import mlx.core as mx
import mlx.nn as nn
import numpy as np
import torch
import torch.nn.functional as torch_f
from mlx_lm.models.base import scaled_dot_product_attention
from mlx_lm.models.cache import KVCache, QuantizedKVCache
from mlx.utils import tree_flatten

from muscriptor.events import ChunkBoundary, ProgressEvent, decode_model_tokens
from muscriptor.modules.conditioners import (
    ClassConditioner,
    ConditioningAttributes,
    ConditioningProvider,
    MelSpectrogramConditioner,
    WavCondition,
    nullify_all_conditions,
)
from muscriptor.tokenizer.mt3 import MT3Tokenizer, instrument_group_from_names
from muscriptor.transcription_model import (
    TranscriptionModel as TorchTranscriptionModel,
    _build_instrument_for_program,
)
from muscriptor.utils.audio import load_audio, resample

SAMPLE_RATE = 16000
SEGMENT_DURATION = 5.0

@dataclass(frozen=True)
class QuantizedWeight:
    weight: object
    scales: object
    biases: object | None
    group_size: int
    bits: int
    mode: str

class CastKVCache(KVCache):
    def __init__(self, dtype):
        super().__init__()
        self.storage_dtype = dtype

    def update_and_fetch(self, keys, values):
        if keys.dtype != self.storage_dtype:
            keys = keys.astype(self.storage_dtype)
            values = values.astype(self.storage_dtype)
        return super().update_and_fetch(keys, values)

class WeightStore:
    def __init__(self, model_dir: Path):
        self.model_dir = model_dir
        self.manifest = json.loads(
            (model_dir / "manifest.json").read_text(encoding="utf-8")
        )
        self.config = json.loads(
            (model_dir / "config.json").read_text(encoding="utf-8")
        )
        self.token_dtype = (
            mx.float16 if self.manifest["token_dtype"] == "float16" else mx.float32
        )
        from safetensors.torch import load_file

        position_tensor = load_file(
            model_dir / self.manifest["position_table_file"],
            device="cpu",
        )["position_table"]
        self.position_table = mx.array(
            position_tensor.numpy()
        ).astype(self.token_dtype)
        mx.eval(self.position_table)

        self.weights = {}
        self.condition_entries = []

        pending = []
        for index, entry in enumerate(self.manifest["entries"], 1):
            if entry["name"].startswith("condition_provider."):
                self.condition_entries.append(entry)
                continue
            loaded = mx.load(str(model_dir / entry["file"]))
            if entry["kind"] == "mlx_q8":
                quantization = entry["quantization"]
                value = QuantizedWeight(
                    weight=loaded["weight"],
                    scales=loaded["scales"],
                    biases=loaded.get("biases"),
                    group_size=int(quantization["group_size"]),
                    bits=int(quantization["bits"]),
                    mode=str(quantization["mode"]),
                )
                self.weights[entry["name"]] = value
                pending.extend([value.weight, value.scales])
                if value.biases is not None:
                    pending.append(value.biases)
            else:
                value = loaded["value"]
                self.weights[entry["name"]] = value
                pending.append(value)
            if len(pending) >= 24:
                mx.eval(*pending)
                pending.clear()
            if index % 20 == 0:
                print(f"  load {index}/{len(self.manifest['entries'])}")
        if pending:
            mx.eval(*pending)

    def get(self, name):
        return self.weights[name]

    def optional(self, name):
        return self.weights.get(name)

class TorchConditionEncoder:
    def __init__(self, store: WeightStore):
        cfg = store.config
        dim = int(cfg["dim"])
        mel = MelSpectrogramConditioner(
            output_dim=dim, device="cpu", sample_rate=SAMPLE_RATE,
            n_fft=2048, frame_rate=100, n_mel_bins=512,
            log_scale=True, eps=1e-6, normalize_audio=False,
        )
        inst = ClassConditioner(1000, dim, device="cpu")
        dataset = ClassConditioner(4, dim, device="cpu")
        self.provider = ConditioningProvider(
            {"self_wav": mel, "instrument_group": inst, "dataset_name": dataset},
            device="cpu",
        )
        state = {}
        for entry in store.condition_entries:
            from safetensors.torch import load_file
            tensor = load_file(store.model_dir / entry["file"], device="cpu")["value"]
            state[entry["name"].removeprefix("condition_provider.")] = tensor
        self.provider.load_state_dict(state, strict=True)
        self.provider.eval()
        self.token_dtype = store.token_dtype

    def encode(self, chunks, lengths, instrument_group, cfg_coef):
        samples = []
        for chunk, length in zip(chunks, lengths):
            wav = chunk.unsqueeze(0)
            condition = WavCondition(
                wav=wav,
                length=torch.tensor([length], dtype=torch.long),
                sample_rate=[SAMPLE_RATE],
                path=[None],
                seek_time=[0.0],
            )
            samples.append(ConditioningAttributes(
                wav={"self_wav": condition},
                text={"instrument_group": instrument_group, "dataset_name": None},
            ))
        if cfg_coef != 1.0:
            samples = samples + nullify_all_conditions(samples)

        tokenized = self.provider.tokenize(samples)
        with torch.no_grad():
            encoded = self.provider(tokenized)
        output = []
        for condition, _mask in encoded.values():
            array = mx.array(condition.cpu().numpy())
            if array.dtype != self.token_dtype:
                array = array.astype(self.token_dtype)
            output.append(array)
        return output

class MLXCore:
    def __init__(self, store: WeightStore):
        self.w = store
        cfg = store.config
        self.dim = int(cfg["dim"])
        self.num_heads = int(cfg["num_heads"])
        self.num_layers = int(cfg["num_layers"])
        self.card = int(cfg["card"])
        self.head_dim = self.dim // self.num_heads
        self.dtype = store.token_dtype
        # Exact same CPU-generated table bytes as the CUDA package.
        self.position_table = store.position_table

    @staticmethod
    def linear(x, weight, bias=None):
        if isinstance(weight, QuantizedWeight):
            y = mx.quantized_matmul(
                x,
                weight.weight,
                weight.scales,
                weight.biases,
                transpose=True,
                group_size=weight.group_size,
                bits=weight.bits,
                mode=weight.mode,
            )
            return y if bias is None else mx.add(y, bias)

        transposed = mx.swapaxes(weight, -1, -2)
        if bias is None:
            return mx.matmul(x, transposed)
        return mx.addmm(bias, x, transposed)

    def norm(self, x, prefix):
        return mx.fast.layer_norm(
            x,
            self.w.get(prefix + ".weight"),
            self.w.optional(prefix + ".bias"),
            1e-5,
        )

    @staticmethod
    def gelu(x):
        return nn.gelu(x)

    def position(self, batch, length, offset):
        end = int(offset) + int(length)
        if end > self.position_table.shape[1]:
            raise RuntimeError(
                f"position table overflow: {end} > {self.position_table.shape[1]}"
            )
        value = self.position_table[:, int(offset):end]
        if batch != 1:
            value = mx.broadcast_to(value, (batch, length, self.dim))
        return value

    def attention(self, x, layer, cache):
        prefix = f"transformer.layers.{layer}.self_attn"
        projected = self.linear(x, self.w.get(prefix + ".in_proj_weight"))
        b, t, _ = projected.shape
        packed = projected.reshape(b, t, 3, self.num_heads, self.head_dim)
        q = mx.transpose(packed[:, :, 0], (0, 2, 1, 3))
        k = mx.transpose(packed[:, :, 1], (0, 2, 1, 3))
        v = mx.transpose(packed[:, :, 2], (0, 2, 1, 3))
        k, v = cache.update_and_fetch(k, v)

        if not hasattr(cache, "bits") and q.dtype != k.dtype:
            q = q.astype(k.dtype)
        mask = "causal" if t > 1 else None
        out = scaled_dot_product_attention(
            q, k, v, cache,
            scale=self.head_dim ** -0.5,
            mask=mask,
        )
        if out.dtype != self.dtype:
            out = out.astype(self.dtype)
        out = mx.transpose(out, (0, 2, 1, 3)).reshape(b, t, self.dim)
        return self.linear(out, self.w.get(prefix + ".out_proj.weight"))

    def forward(self, tokens, conditions, caches, first_step):
        tokens = tokens.astype(mx.int32)
        x = self.w.get("emb.weight")[tokens]
        token_length = x.shape[1]
        if first_step:
            x = mx.concatenate([*conditions, x], axis=1)
        x = x + self.position(x.shape[0], x.shape[1], caches[0].offset)
        for layer in range(self.num_layers):
            x = x + self.attention(
                self.norm(x, f"transformer.layers.{layer}.norm1"),
                layer,
                caches[layer],
            )
            h = self.linear(
                self.norm(x, f"transformer.layers.{layer}.norm2"),
                self.w.get(f"transformer.layers.{layer}.linear1.weight"),
            )
            h = self.gelu(h)
            h = self.linear(
                h, self.w.get(f"transformer.layers.{layer}.linear2.weight")
            )
            x = x + h
        x = self.norm(x, "out_norm")
        if first_step:
            x = x[:, -token_length:]
        return self.linear(x, self.w.get("linear.weight"))

class MLXTranscriptionModel:
    def __init__(self, model_dir: Path, kv_mode: str):
        if not mx.metal.is_available():
            raise RuntimeError("MLX Metal을 사용할 수 없습니다.")
        mx.set_default_device(mx.gpu)
        print("MLX Metal:", mx.metal.device_info())

        self.store = WeightStore(model_dir)
        self.core = MLXCore(self.store)
        self.conditions = TorchConditionEncoder(self.store)
        self.kv_mode = kv_mode

        self._effective_precision = self.store.manifest.get(
            "effective_precision",
            self.store.manifest.get("precision", "fp32"),
        )
        self._effective_backend = self.store.manifest.get(
            "backend",
            "mlx_native",
        )
        self._effective_kv = kv_mode
        self._effective_kv_backend = kv_mode
        self.tokenizer = MT3Tokenizer(
            instrument_vocabulary="MT3_FULL_PLUS", max_shift_steps=1001
        )
        self._instrument_for_program = _build_instrument_for_program(self.tokenizer)

        helper = object.__new__(TorchTranscriptionModel)
        helper._tokenizer = self.tokenizer
        helper._instrument_for_program = self._instrument_for_program
        self._midi_helper = helper
        self._trace_callback = None

    def events_to_midi_bytes(self, events):
        return self._midi_helper.events_to_midi_bytes(events)

    def _cache(self):
        if self.kv_mode == "q8":
            return QuantizedKVCache(group_size=64, bits=8)
        dtype = mx.float16 if self.kv_mode == "fp16" else mx.float32
        return CastKVCache(dtype)

    def _load_wav(self, audio, sample_rate=None):
        if isinstance(audio, (str, Path)):
            wav = load_audio(audio, target_sr=SAMPLE_RATE)
        else:
            wav = audio.float()
            if wav.dim() == 1:
                wav = wav.unsqueeze(0)
            if wav.dim() == 3:
                wav = wav.squeeze(0)
            if wav.shape[0] > 1:
                wav = wav.mean(0, keepdim=True)
            if sample_rate is not None and sample_rate != SAMPLE_RATE:
                wav = resample(wav, sample_rate, SAMPLE_RATE)
        return wav.cpu()

    def _generate(self, chunks, lengths, instruments, sampling, temperature, cfg_coef):
        batch = len(chunks)
        group = instrument_group_from_names(instruments) if instruments else None
        conditions = self.conditions.encode(chunks, lengths, group, cfg_coef)
        caches = [self._cache() for _ in range(self.core.num_layers)]

        current = mx.full((batch, 1), self.core.card, dtype=mx.int32)
        done = np.zeros((batch,), dtype=bool)
        eos = self.tokenizer.eos_id

        additive = np.zeros((self.core.card,), dtype=np.float32)
        if self.core.card > 1393:
            additive[1393:] = -np.inf
        additive = mx.array(additive, dtype=mx.float32)

        for step in range(2000):
            sequence = current
            if cfg_coef != 1.0:
                sequence = mx.concatenate([current, current], axis=0)
            logits = self.core.forward(sequence, conditions, caches, step == 0)[:, -1, :]
            # Match MuScriptor's official decision boundary: token logits are
            # promoted once to FP32 before CFG, masking, sampling or argmax.
            if logits.dtype != mx.float32:
                logits = logits.astype(mx.float32)
            if cfg_coef != 1.0:
                cond, uncond = logits[:batch], logits[batch:]
                logits = uncond + (cond - uncond) * cfg_coef
            logits = logits + additive

            if self._trace_callback is not None:
                mx.eval(logits)
                self._trace_callback(step, logits)

            if sampling:
                token = mx.random.categorical(logits / temperature)
            else:
                token = mx.argmax(logits, axis=-1)

            # Materialize the token and cache state each decode step so the lazy
            # MLX graph does not grow across hundreds of autoregressive tokens.
            eval_items = [token]
            for cache in caches:
                state = cache.state
                if state:
                    eval_items.extend(value for _, value in tree_flatten(state))
            mx.eval(*eval_items)
            row = np.asarray(token.tolist(), dtype=np.int32)
            row[done] = eos
            done |= row == eos
            yield row
            if done.all():
                break
            current = mx.array(row.reshape(batch, 1))

    def transcribe(
        self, audio, use_sampling=False, temperature=1.0, cfg_coef=1.0,
        instruments=None, batch_size=6, no_eos_is_ok=True, beam_size=1,
    ):
        if beam_size != 1:
            raise ValueError("MLX 실행은 beam_size=1만 지원합니다.")
        if isinstance(audio, tuple):
            wav = self._load_wav(audio[0], audio[1])
        else:
            wav = self._load_wav(audio)

        segment = int(SEGMENT_DURATION * SAMPLE_RATE)
        total = wav.shape[-1]
        count = math.ceil(total / segment)
        chunks, lengths, seek = [], [], []
        for index in range(count):
            start = index * segment
            chunk = wav[:, start:start + segment]
            if chunk.shape[-1] < segment:
                chunk = torch_f.pad(
                    chunk,
                    (0, segment - chunk.shape[-1]),
                )

            # Match the official PyTorch path exactly: the chunk is padded
            # first, and the conditioner receives the padded 5-second length.
            # Passing the pre-padding length changes the condition mask and can
            # alter token generation or EOS behavior on short/final chunks.
            length = chunk.shape[-1]

            chunks.append(chunk)
            lengths.append(length)
            seek.append(index * SEGMENT_DURATION)

        def token_stream():
            yield ProgressEvent(completed=0, total=count)
            def boundary(index):
                next_seek = seek[index + 1] if index + 1 < count else None
                return ChunkBoundary(seek[index], next_seek)

            for start in range(0, count, batch_size):
                batch_chunks = chunks[start:start + batch_size]
                batch_lengths = lengths[start:start + batch_size]
                n = len(batch_chunks)
                buffers = [[] for _ in range(n)]
                done = [False] * n
                active = 0
                yield boundary(start)
                for row in self._generate(
                    batch_chunks, batch_lengths, instruments,
                    use_sampling, temperature, cfg_coef,
                ):
                    for j in range(n):
                        if done[j]:
                            continue
                        value = int(row[j])
                        if value == self.tokenizer.eos_id:
                            done[j] = True
                        elif j == active:
                            yield value
                        else:
                            buffers[j].append(value)
                    while active < n and done[active]:
                        active += 1
                        if active < n:
                            yield boundary(start + active)
                            yield from buffers[active]
                            buffers[active] = []
                for j in range(active, n):
                    if not done[j]:
                        message = f"chunk {start + j} did not emit EOS within 2000 tokens"
                        if no_eos_is_ok:
                            warnings.warn(message, RuntimeWarning, stacklevel=2)
                        else:
                            raise RuntimeError(message)
                    if j != active:
                        yield boundary(start + j)
                    yield from buffers[j]
                yield ProgressEvent(completed=start + n, total=count)
                mx.clear_cache()

        return decode_model_tokens(
            token_stream(),
            self.tokenizer._vocab,
            self._instrument_for_program,
            frame_rate=self.tokenizer.frame_rate,
        )

def load_mlx_model(model_dir: Path, kv_mode: str):
    return MLXTranscriptionModel(model_dir, kv_mode)
