from __future__ import annotations

from copy import deepcopy
import gc
import platform
import traceback
from pathlib import Path

import torch

from config import load_settings
from cpu_backend import prepare_and_load_cpu
from model_common import ensure_original, validate_derived
from prompts import ask_yes_no, print_oom_help
from web_runtime import serve

ROOT = Path(__file__).resolve().parents[1]


def load_original(weights, device):
    from muscriptor import TranscriptionModel
    return TranscriptionModel.load_model(weights, device=device)


def _original_settings(settings):
    effective = deepcopy(settings)
    effective["model"]["quantization"] = "official"
    effective["model"]["kv_cache"] = "official"
    return effective


def run_cpu(weights, config, settings):
    model = prepare_and_load_cpu(
        root=ROOT,
        size=settings["model"]["name"],
        requested_precision=settings["model"]["quantization"],
        requested_kv=settings["model"]["kv_cache"],
        source_weights=weights,
        source_config=config,
        batch_size=int(settings["options"]["batch_size"]),
    )
    label = (
        f"CPU / "
        f"{getattr(model, '_effective_precision', 'fp32').upper()} / "
        f"{getattr(model, '_effective_kv', 'fp32').upper()} KV"
    )
    serve(model, settings, label)


def run_original_cpu(weights, settings):
    serve(
        load_original(weights, "cpu"),
        _original_settings(settings),
        "CPU / official original FP32",
    )


def run_original_mps(weights, settings):
    serve(
        load_original(weights, "mps"),
        _original_settings(settings),
        "Apple MPS / official original",
    )


def prepare_derived(
    settings,
    weights,
    config,
    *,
    precision: str | None = None,
):
    from derive_mlx import derive_mlx, expected_format

    size = settings["model"]["name"]
    selected_precision = (
        precision
        if precision is not None
        else settings["model"]["quantization"]
    )
    target = (
        ROOT
        / "models"
        / "derived"
        / "mlx"
        / selected_precision
        / size
    )
    derived_format = expected_format(selected_precision)
    valid, reason = validate_derived(
        target,
        derived_format,
        size,
        selected_precision,
    )
    if not valid and target.exists() and any(target.iterdir()):
        print(
            f"MLX {selected_precision} 파생 모델 구성 이상: "
            f"{reason}"
        )
        if ask_yes_no(
            f"MLX {selected_precision} 파생 모델을 "
            f"삭제하고 다시 만들까요?",
            True,
        ):
            shutil = __import__("shutil")
            shutil.rmtree(target)
        else:
            raise RuntimeError(
                f"MLX {selected_precision} 파생 재생성을 "
                f"취소했습니다."
            )

    valid, _ = validate_derived(
        target,
        derived_format,
        size,
        selected_precision,
    )
    if not valid:
        derive_mlx(
            size,
            selected_precision,
            weights,
            config,
            target,
        )
    return target


def run_mlx_precision(
    settings,
    weights,
    config,
    *,
    precision: str,
):
    from mlx_backend import load_mlx_model

    derived = prepare_derived(
        settings,
        weights,
        config,
        precision=precision,
    )
    model = load_mlx_model(
        derived,
        settings["model"]["kv_cache"],
    )
    model._effective_precision = precision
    serve(
        model,
        settings,
        f"Apple MLX / {precision.upper()} token / "
        f"{settings['model']['kv_cache'].upper()} KV",
    )


def main() -> int:
    settings = load_settings(ROOT)
    size = settings["model"]["name"]
    requested_precision = settings["model"]["quantization"]
    use_original = bool(settings["model"]["use_original"])
    use_gpu = bool(settings["options"]["use_gpu"])
    ask = bool(settings["options"].get("ask_fallback", True))
    weights, config = ensure_original(ROOT, size)

    if use_original:
        if not use_gpu:
            run_original_cpu(weights, settings)
            return 0
        if not torch.backends.mps.is_available():
            print(
                "GPU 사용이 요청되었지만 "
                "PyTorch MPS를 사용할 수 없습니다."
            )
            if ask and ask_yes_no(
                "원본 CPU로 실행할까요?",
                True,
            ):
                run_original_cpu(weights, settings)
                return 0
            return 2
        try:
            run_original_mps(weights, settings)
            return 0
        except Exception as exc:
            print(f"원본 MPS 실행 실패: {exc}")
            if ask and ask_yes_no(
                "원본 CPU로 실행할까요?",
                True,
            ):
                run_original_cpu(weights, settings)
                return 0
            raise

    if not use_gpu:
        run_cpu(weights, config, settings)
        return 0

    if platform.machine() != "arm64":
        print("Apple Silicon MLX 환경이 아닙니다.")
        if ask and ask_yes_no(
            "CPU에서 Q8→16비트→FP32 순서로 "
            "가능한 경로를 시도할까요?",
            True,
        ):
            run_cpu(weights, config, settings)
            return 0
        return 2

    try:
        import mlx.core as mx
        if not mx.metal.is_available():
            raise RuntimeError("MLX Metal을 사용할 수 없습니다.")
        if settings["options"]["beam_size"] != 1:
            raise ValueError("MLX는 beam_size=1만 지원합니다.")

        try:
            run_mlx_precision(
                settings,
                weights,
                config,
                precision=requested_precision,
            )
            return 0
        except Exception as selected_exc:
            traceback.print_exc()
            print(
                f"\nMLX {requested_precision} 파생 실행 실패: "
                f"{selected_exc}"
            )
            try:
                mx.clear_cache()
            except Exception:
                pass
            gc.collect()

            is_memory_error = (
                "memory" in str(selected_exc).lower()
                or "metal" in str(selected_exc).lower()
            )
            if is_memory_error:
                print_oom_help(
                    size,
                    settings["options"]["batch_size"],
                )

            fallback_precisions: list[str] = []
            if requested_precision == "q8":
                fallback_precisions = ["fp16", "fp32"]
            elif requested_precision == "fp16":
                fallback_precisions = ["fp32"]

            for fallback_precision in fallback_precisions:
                should_try = (
                    not ask
                    or ask_yes_no(
                        f"MLX {fallback_precision.upper()} 파생으로 "
                        f"상위 정밀도 폴백할까요?",
                        True,
                    )
                )
                if not should_try:
                    continue
                try:
                    run_mlx_precision(
                        settings,
                        weights,
                        config,
                        precision=fallback_precision,
                    )
                    return 0
                except Exception as fallback_exc:
                    print(
                        f"MLX {fallback_precision} 폴백도 실패: "
                        f"{fallback_exc}"
                    )
                    try:
                        mx.clear_cache()
                    except Exception:
                        pass
                    gc.collect()

        if ask and ask_yes_no(
            "원본 PyTorch MPS 모델로 다시 실행할까요?",
            True,
        ):
            try:
                run_original_mps(weights, settings)
                return 0
            except Exception as original_exc:
                print(f"원본 MPS도 실패했습니다: {original_exc}")

        if ask and ask_yes_no(
            "CPU에서 Q8→16비트→FP32 순서로 "
            "가능한 경로를 시도할까요?",
            True,
        ):
            run_cpu(weights, config, settings)
            return 0
        return 2

    except Exception as exc:
        traceback.print_exc()
        print(f"\nMLX 초기화 실패: {exc}")
        if ask and ask_yes_no(
            "원본 PyTorch MPS 모델로 실행할까요?",
            True,
        ):
            try:
                run_original_mps(weights, settings)
                return 0
            except Exception as original_exc:
                print(f"원본 MPS도 실패했습니다: {original_exc}")
        if ask and ask_yes_no(
            "CPU 원본/양자화 경로를 시도할까요?",
            True,
        ):
            run_cpu(weights, config, settings)
            return 0
        return 2


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except SystemExit:
        raise
    except Exception as exc:
        from datetime import datetime

        log_dir = ROOT / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_path = (
            log_dir
            / f"run_error_{datetime.now():%Y%m%d_%H%M%S}.log"
        )
        details = traceback.format_exc()
        log_path.write_text(details, encoding="utf-8")
        print(details)
        print(f"[실행 실패] {exc}")
        print(f"전체 오류 로그: {log_path}")
        raise SystemExit(1)
