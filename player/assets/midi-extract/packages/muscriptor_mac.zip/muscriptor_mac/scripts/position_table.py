from __future__ import annotations

import torch


POSITION_TABLE_LENGTH = 4096


def build_position_table(
    dim: int,
    *,
    dtype: torch.dtype,
    length: int = POSITION_TABLE_LENGTH,
    max_period: float = 10000.0,
) -> torch.Tensor:
    """Build one cross-platform position table on CPU.

    The trigonometric calculation is always performed in CPU FP32 and cast once
    at the end. CUDA and MLX therefore load exactly the same table bytes.
    """
    if dim % 2 != 0:
        raise ValueError("position embedding dimension must be even")

    half = dim // 2
    positions = torch.arange(
        length,
        dtype=torch.float32,
        device="cpu",
    ).view(1, length, 1)
    adim = torch.arange(
        half,
        dtype=torch.float32,
        device="cpu",
    ).view(1, 1, half)
    phase = positions / (
        torch.tensor(max_period, dtype=torch.float32)
        ** (adim / float(half - 1))
    )
    table = torch.cat(
        [torch.cos(phase), torch.sin(phase)],
        dim=-1,
    )
    return table.to(dtype=dtype).contiguous()
