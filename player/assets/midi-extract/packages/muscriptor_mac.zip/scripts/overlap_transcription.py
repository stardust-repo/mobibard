from __future__ import annotations

import math
import sys
import time
import warnings
from dataclasses import dataclass
from typing import Iterator

import torch
import torch.nn.functional as torch_f

from muscriptor.events import NoteEndEvent, NoteStartEvent, ProgressEvent
from muscriptor.tokenizer.mt3 import instrument_group_from_names
from muscriptor.tokenizer.notes import DRUM_PROGRAM, MINIMUM_NOTE_DURATION_SEC

SAMPLE_RATE = 16000
WINDOW_SECONDS = 5.0
MIN_OVERLAP_SECONDS = 0.1
MAX_OVERLAP_SECONDS = 4.9

EDGE_SHORT_NOTE_SECONDS = 0.18
EDGE_CORROBORATION_ONSET_SECONDS = 0.08
EDGE_DRUM_GUARD_SECONDS = 0.10
DUPLICATE_INTERVAL_GAP_SECONDS = 0.01

MAX_GEN_LEN = 2000
ONSET_DEDUPE_SECONDS = 0.05
DUPLICATE_ONSET_MATCH_SECONDS = 0.05
PATTERN_ONSET_MATCH_SECONDS = 0.05
PATTERN_OFFSET_MATCH_SECONDS = 0.10
PATTERN_ASSIGNMENT_MARGIN_RATIO = 0.01
PATTERN_MAX_PROGRAMS = 12
_TIME_EPSILON = 1e-7

# Notes are exposed to the web only after no unprocessed 5-second window can
# still corroborate, extend, deduplicate, or relabel them.  The largest merge
# tolerance is 100 ms, so keeping this guard behind the next unseen window's
# start makes the emitted prefix immutable while allowing each completed batch
# to reveal almost all notes except its still-open tail.
STREAM_FINALIZATION_GUARD_SECONDS = max(
    EDGE_CORROBORATION_ONSET_SECONDS,
    ONSET_DEDUPE_SECONDS,
    DUPLICATE_ONSET_MATCH_SECONDS,
    PATTERN_ONSET_MATCH_SECONDS,
    PATTERN_OFFSET_MATCH_SECONDS,
    DUPLICATE_INTERVAL_GAP_SECONDS,
)


@dataclass(frozen=True)
class OverlapPolicy:
    overlap_seconds: float
    stride_seconds: float
    edge_zone_seconds: float
    center_zone_seconds: float
    max_observation_window_gap: int

    @classmethod
    def from_seconds(cls, overlap_seconds: float) -> "OverlapPolicy":
        value = float(overlap_seconds)
        if not MIN_OVERLAP_SECONDS <= value <= MAX_OVERLAP_SECONDS:
            raise ValueError(
                f"overlap_sec는 {MIN_OVERLAP_SECONDS:.1f}~{MAX_OVERLAP_SECONDS:.1f}초여야 합니다: {value}"
            )
        stride = WINDOW_SECONDS - value
        if stride <= 0:
            raise ValueError("overlap_sec는 5초 분석 창보다 작아야 합니다.")

        # Keep three trust regions for every supported overlap.  At 2.5 seconds
        # this is exactly 0.5 / 1.5 / 0.5.  Short overlaps scale both edge zones
        # down to one quarter each, preserving a central ensemble region.
        edge = min(0.5, value / 4.0)
        center = max(0.0, value - (2.0 * edge))

        # With large overlaps one event may be observed by more than two windows.
        # This bound covers every window pair whose 5-second inputs overlap.
        max_gap = max(1, math.ceil((WINDOW_SECONDS - _TIME_EPSILON) / stride) - 1)
        return cls(
            overlap_seconds=value,
            stride_seconds=stride,
            edge_zone_seconds=edge,
            center_zone_seconds=center,
            max_observation_window_gap=max_gap,
        )


@dataclass(frozen=True)
class WindowInput:
    index: int
    start_time: float
    duration: float
    chunk: torch.Tensor

    @property
    def end_time(self) -> float:
        return self.start_time + self.duration


@dataclass
class LocalNote:
    program: int
    instrument: str
    pitch: int
    onset: float
    offset: float
    is_drum: bool
    leading_tie: bool
    trailing_open: bool
    source_window: int

    @property
    def key(self) -> tuple[int, int]:
        return self.program, self.pitch


@dataclass
class WindowResult:
    window: WindowInput
    notes: list[LocalNote]
    leading_ties: set[tuple[int, int]]
    trailing_open: set[tuple[int, int]]
    emitted_eos: bool


@dataclass
class GlobalNote:
    # ``program`` is the canonical part identity used only for cross-window
    # matching.  ``selected_program`` and ``instrument`` are the output label
    # chosen from the most recent corroborating window.
    program: int
    selected_program: int
    instrument: str
    pitch: int
    onset: float
    offset: float
    is_drum: bool
    source_window: int
    priority_window: int
    source_edge_margin: float
    source_is_owner: bool
    trailing_open: bool

    @property
    def key(self) -> tuple[int, int]:
        return self.program, self.pitch


@dataclass(frozen=True)
class ProgramPatternMatch:
    left_program: int
    right_program: int
    note_count: int
    score: float
    boundary_continuation: bool


def _load_wav(model, audio) -> torch.Tensor:
    if isinstance(audio, tuple):
        tensor, sample_rate = audio
        wav = model._load_wav(tensor, sample_rate)
    else:
        try:
            wav = model._load_wav(audio, None)
        except TypeError:
            wav = model._load_wav(audio)
    if wav.ndim != 2 or wav.shape[0] != 1:
        raise RuntimeError(f"오버랩 처리는 mono [1, T] 파형을 기대합니다: {tuple(wav.shape)}")
    if wav.shape[-1] <= 0:
        raise ValueError("빈 오디오는 변환할 수 없습니다.")
    return wav


def _build_windows(
    wav: torch.Tensor, policy: OverlapPolicy
) -> tuple[list[WindowInput], float]:
    total_samples = int(wav.shape[-1])
    total_duration = total_samples / SAMPLE_RATE
    segment_samples = int(round(WINDOW_SECONDS * SAMPLE_RATE))
    stride_samples = int(round(policy.stride_seconds * SAMPLE_RATE))

    starts = [0]
    while starts[-1] + segment_samples < total_samples:
        starts.append(starts[-1] + stride_samples)

    windows: list[WindowInput] = []
    for index, start in enumerate(starts):
        available = min(segment_samples, total_samples - start)
        chunk = wav[:, start : start + available]
        if available < segment_samples:
            chunk = torch_f.pad(chunk, (0, segment_samples - available))
        windows.append(
            WindowInput(
                index=index,
                start_time=start / SAMPLE_RATE,
                duration=available / SAMPLE_RATE,
                chunk=chunk,
            )
        )
    return windows, total_duration


def _parse_leading_ties(
    tokens: list[int], vocab
) -> tuple[set[tuple[int, int]], int | None, int | None]:
    ties: set[tuple[int, int]] = set()
    program: int | None = None
    for position, token in enumerate(tokens):
        event = vocab[token]
        if event.type == "tie":
            return ties, position, program
        if event.type == "shift":
            return set(), None, None
        if event.type == "program":
            program = int(event.value)
        elif event.type == "pitch" and program is not None:
            ties.add((program, int(event.value)))
    return set(), None, None


def _decode_window_tokens(
    *,
    window: WindowInput,
    tokens: list[int],
    vocab,
    frame_rate: int,
    instrument_for_program,
    emitted_eos: bool,
) -> WindowResult:
    leading_ties, tie_position, prologue_program = _parse_leading_ties(tokens, vocab)
    if tie_position is None:
        return WindowResult(
            window=window,
            notes=[],
            leading_ties=set(),
            trailing_open=set(),
            emitted_eos=emitted_eos,
        )

    # A tie prologue only describes notes that started before this window. The
    # first window has no previous audio in this transcription, so match the
    # official decoder and ignore its guessed leading ties.
    seeded_ties = leading_ties if window.index > 0 else set()
    open_notes: dict[tuple[int, int], tuple[float, bool]] = {
        key: (0.0, True) for key in seeded_ties if key[0] != DRUM_PROGRAM
    }
    notes: list[LocalNote] = []
    tick_state = 0
    program: int | None = prologue_program
    velocity: int | None = None

    def instrument_name(program_value: int) -> str:
        return "drums" if program_value == DRUM_PROGRAM else instrument_for_program(program_value)

    def close_note(key: tuple[int, int], end_time: float, trailing: bool) -> None:
        opened = open_notes.pop(key, None)
        if opened is None:
            return
        onset, from_tie = opened
        clipped_end = min(max(end_time, onset + MINIMUM_NOTE_DURATION_SEC), window.duration)
        if clipped_end <= onset + _TIME_EPSILON:
            return
        notes.append(
            LocalNote(
                program=key[0],
                instrument=instrument_name(key[0]),
                pitch=key[1],
                onset=onset,
                offset=clipped_end,
                is_drum=False,
                leading_tie=from_tie,
                trailing_open=trailing,
                source_window=window.index,
            )
        )

    for token in tokens[tie_position + 1 :]:
        event = vocab[token]
        etype = event.type
        if etype == "shift":
            if event.value > 0:
                tick_state = int(event.value)
        elif etype == "program":
            program = int(event.value)
        elif etype == "velocity":
            velocity = int(event.value)
        elif etype == "drum":
            event_time = tick_state / frame_rate
            if event_time < window.duration:
                notes.append(
                    LocalNote(
                        program=DRUM_PROGRAM,
                        instrument="drums",
                        pitch=int(event.value),
                        onset=event_time,
                        offset=min(event_time + MINIMUM_NOTE_DURATION_SEC, window.duration),
                        is_drum=True,
                        leading_tie=False,
                        trailing_open=False,
                        source_window=window.index,
                    )
                )
        elif etype == "pitch":
            if program is None or velocity is None:
                continue
            event_time = tick_state / frame_rate
            if event_time >= window.duration:
                continue
            key = (program, int(event.value))
            if key in open_notes:
                close_note(key, event_time, trailing=False)
            if velocity > 0 and program != DRUM_PROGRAM:
                open_notes[key] = (event_time, False)

    trailing_open = set(open_notes)
    for key in list(open_notes):
        close_note(key, window.duration, trailing=True)

    notes.sort(key=lambda note: (note.onset, note.offset, note.program, note.pitch))
    return WindowResult(
        window=window,
        notes=notes,
        leading_ties=seeded_ties,
        trailing_open=trailing_open,
        emitted_eos=emitted_eos,
    )


def _is_mlx_model(model) -> bool:
    backend = str(getattr(model, "_effective_backend", "")).lower()
    return backend.startswith("mlx") and hasattr(model, "_generate")


def _torch_token_batches(
    model,
    windows: list[WindowInput],
    *,
    instruments: list[str] | None,
    batch_size: int,
    use_sampling: bool,
    temperature: float,
    cfg_coef: float,
    no_eos_is_ok: bool,
    beam_size: int,
    cancel_event=None,
):
    tokenizer = model._tokenizer
    instrument_group = instrument_group_from_names(instruments) if instruments else None
    forbidden_tokens = None
    if instruments:
        forbidden_tokens = torch.tensor(
            tokenizer.forbidden_token_ids(instruments),
            device=model._device,
            dtype=torch.long,
        )

    for batch_start in range(0, len(windows), batch_size):
        if cancel_event is not None and cancel_event.is_set():
            return
        batch_windows = windows[batch_start : batch_start + batch_size]
        if batch_start == 0:
            print(
                "[muscriptor-overlap] runtime batch: "
                f"configured={batch_size}, actual={len(batch_windows)}",
                file=sys.stderr,
                flush=True,
            )
        conditions = [
            model._build_conditions(window.chunk, instrument_group)[0]
            for window in batch_windows
        ]
        token_lists: list[list[int]] = [[] for _ in batch_windows]
        done = [False] * len(batch_windows)

        generation = model._model.generate(
            prompt=None,
            conditions=conditions,
            max_gen_len=MAX_GEN_LEN,
            use_sampling=use_sampling,
            temp=temperature,
            top_k=0,
            top_p=0.0,
            cfg_coef=cfg_coef,
            early_stop_on_token=tokenizer.eos_id,
            beam_size=beam_size,
            forbidden_tokens=forbidden_tokens,
        )
        try:
            for step in generation:
                if cancel_event is not None and cancel_event.is_set():
                    return
                row = step.tolist()
                for index, value in enumerate(row):
                    if done[index]:
                        continue
                    token = int(value)
                    if token == tokenizer.eos_id:
                        done[index] = True
                    else:
                        token_lists[index].append(token)
                if all(done):
                    break
        finally:
            close = getattr(generation, "close", None)
            if callable(close):
                close()
            generation = None
            conditions.clear()

        for local_index, emitted in enumerate(done):
            if emitted:
                continue
            window = batch_windows[local_index]
            message = (
                f"overlap window {window.index} (seek={window.start_time:.1f}s) "
                f"did not emit EOS within {MAX_GEN_LEN} tokens"
            )
            if no_eos_is_ok:
                warnings.warn(message, RuntimeWarning, stacklevel=2)
            else:
                raise RuntimeError(message)
        yield batch_start, batch_windows, token_lists, done


def _mlx_token_batches(
    model,
    windows: list[WindowInput],
    *,
    instruments: list[str] | None,
    batch_size: int,
    use_sampling: bool,
    temperature: float,
    cfg_coef: float,
    no_eos_is_ok: bool,
    beam_size: int,
    cancel_event=None,
):
    if beam_size != 1:
        raise ValueError("MLX 오버랩 처리는 beam_size=1만 지원합니다.")
    tokenizer = model._tokenizer

    for batch_start in range(0, len(windows), batch_size):
        if cancel_event is not None and cancel_event.is_set():
            return
        batch_windows = windows[batch_start : batch_start + batch_size]
        if batch_start == 0:
            print(
                "[muscriptor-overlap] runtime batch: "
                f"configured={batch_size}, actual={len(batch_windows)}",
                file=sys.stderr,
                flush=True,
            )
        chunks = [window.chunk for window in batch_windows]
        lengths = [int(window.chunk.shape[-1]) for window in batch_windows]
        token_lists: list[list[int]] = [[] for _ in batch_windows]
        done = [False] * len(batch_windows)

        generation = model._generate(
            chunks,
            lengths,
            instruments,
            use_sampling,
            temperature,
            cfg_coef,
            prompt=None,
            max_gen_len=MAX_GEN_LEN,
            cancel_event=cancel_event,
        )
        try:
            for row in generation:
                if cancel_event is not None and cancel_event.is_set():
                    return
                for index in range(len(batch_windows)):
                    if done[index]:
                        continue
                    token = int(row[index])
                    if token == tokenizer.eos_id:
                        done[index] = True
                    else:
                        token_lists[index].append(token)
                if all(done):
                    break
        finally:
            close = getattr(generation, "close", None)
            if callable(close):
                close()
            generation = None

        for local_index, emitted in enumerate(done):
            if emitted:
                continue
            window = batch_windows[local_index]
            message = (
                f"overlap window {window.index} (seek={window.start_time:.1f}s) "
                f"did not emit EOS within {MAX_GEN_LEN} tokens"
            )
            if no_eos_is_ok:
                warnings.warn(message, RuntimeWarning, stacklevel=2)
            else:
                raise RuntimeError(message)

        try:
            import mlx.core as mx

            mx.clear_cache()
        except Exception:
            pass
        yield batch_start, batch_windows, token_lists, done


def _core_bounds(results: list[WindowResult], index: int, total_duration: float) -> tuple[float, float]:
    current = results[index].window
    if index == 0:
        core_start = 0.0
    else:
        previous = results[index - 1].window
        core_start = (previous.end_time + current.start_time) / 2.0

    if index + 1 == len(results):
        core_end = total_duration
    else:
        following = results[index + 1].window
        core_end = (current.end_time + following.start_time) / 2.0
    return core_start, core_end


def _leading_span_by_key(
    result: WindowResult, aliases: dict[int, int]
) -> dict[tuple[int, int], LocalNote]:
    spans: dict[tuple[int, int], LocalNote] = {}
    for note in result.notes:
        if not note.leading_tie:
            continue
        key = (aliases.get(note.program, note.program), note.pitch)
        previous = spans.get(key)
        if previous is None or note.offset > previous.offset:
            spans[key] = note
    return spans


def _matching_regular_span(
    result: WindowResult,
    key: tuple[int, int],
    original_onset: float,
    aliases: dict[int, int],
) -> LocalNote | None:
    best: LocalNote | None = None
    best_delta = float("inf")
    for note in result.notes:
        canonical_key = (aliases.get(note.program, note.program), note.pitch)
        if note.leading_tie or canonical_key != key:
            continue
        global_onset = result.window.start_time + note.onset
        delta = abs(global_onset - original_onset)
        if delta <= DUPLICATE_ONSET_MATCH_SECONDS and delta < best_delta:
            best = note
            best_delta = delta
    return best


def _global_span(result: WindowResult, note: LocalNote) -> tuple[float, float]:
    return (
        result.window.start_time + note.onset,
        result.window.start_time + note.offset,
    )


def _overlap_patterns(
    result: WindowResult, overlap_start: float, overlap_end: float
) -> dict[int, list[LocalNote]]:
    patterns: dict[int, list[LocalNote]] = {}
    for note in result.notes:
        if note.is_drum:
            continue
        onset, offset = _global_span(result, note)
        if offset <= overlap_start + _TIME_EPSILON:
            continue
        if onset >= overlap_end - _TIME_EPSILON:
            continue
        patterns.setdefault(note.program, []).append(note)
    for notes in patterns.values():
        notes.sort(
            key=lambda note: (
                _global_span(result, note)[0],
                note.pitch,
                _global_span(result, note)[1],
            )
        )
    return patterns


def _pattern_note_score(
    left_result: WindowResult,
    left: LocalNote,
    right_result: WindowResult,
    right: LocalNote,
    policy: OverlapPolicy,
) -> tuple[float, bool] | None:
    if left.pitch != right.pitch:
        return None

    left_onset, left_offset = _global_span(left_result, left)
    right_onset, right_offset = _global_span(right_result, right)
    onset_delta = abs(left_onset - right_onset)
    offset_delta = abs(left_offset - right_offset)
    interval_overlap = min(left_offset, right_offset) - max(left_onset, right_onset)

    # Strongest single-note evidence: the left window leaves the note open and
    # the right window independently emits the same-pitch leading tie.  This is
    # the cross-instrument continuation case discussed for the overlap mode.
    if left.trailing_open and right.leading_tie:
        boundary = right_result.window.start_time
        if (
            left_onset < boundary + PATTERN_ONSET_MATCH_SECONDS
            and left_offset >= boundary - PATTERN_ONSET_MATCH_SECONDS
            and right_onset <= boundary + _TIME_EPSILON
            and interval_overlap > _TIME_EPSILON
        ):
            score = (
                10_000.0
                + min(interval_overlap, policy.overlap_seconds) * 100.0
                - min(offset_delta, 1.0) * 10.0
            )
            return score, True

    # Both windows heard the attack.  An edge-clipped/open span is allowed to
    # disagree on the offset; two explicit endings must still be close.
    if onset_delta <= PATTERN_ONSET_MATCH_SECONDS:
        if (
            not left.trailing_open
            and not right.trailing_open
            and offset_delta > PATTERN_OFFSET_MATCH_SECONDS
        ):
            return None
        score = (
            8_000.0
            - onset_delta * 1_000.0
            - min(offset_delta, 1.0) * 20.0
        )
        return score, False

    # A note that started before the right window can be represented as a tie
    # there even when the left window emitted an explicit ending in the shared
    # second.  Matching the ending avoids turning it into a second attack.
    if (
        right.leading_tie
        and interval_overlap > _TIME_EPSILON
        and offset_delta <= PATTERN_OFFSET_MATCH_SECONDS
    ):
        score = 6_000.0 - offset_delta * 1_000.0
        return score, False

    return None


def _match_program_pattern(
    left_result: WindowResult,
    left_program: int,
    left_notes: list[LocalNote],
    right_result: WindowResult,
    right_program: int,
    right_notes: list[LocalNote],
    policy: OverlapPolicy,
) -> ProgramPatternMatch | None:
    # The production rule follows the conservative
    # premise: same instrument count and the complete same note pattern, with
    # only the program label changing.  Partial patterns are not remapped.
    if not left_notes or len(left_notes) != len(right_notes):
        return None

    scored_pairs: list[tuple[float, bool, int, int]] = []
    for left_index, left_note in enumerate(left_notes):
        for right_index, right_note in enumerate(right_notes):
            scored = _pattern_note_score(
                left_result,
                left_note,
                right_result,
                right_note,
                policy,
            )
            if scored is None:
                continue
            score, boundary_continuation = scored
            scored_pairs.append(
                (score, boundary_continuation, left_index, right_index)
            )

    scored_pairs.sort(reverse=True)
    used_left: set[int] = set()
    used_right: set[int] = set()
    selected: list[tuple[float, bool, int, int]] = []
    for item in scored_pairs:
        _score, _boundary, left_index, right_index = item
        if left_index in used_left or right_index in used_right:
            continue
        used_left.add(left_index)
        used_right.add(right_index)
        selected.append(item)

    if len(selected) != len(left_notes):
        return None

    # Ensure the matched pitch/time sequence did not cross.  Repeated pitches
    # may otherwise admit an accidental greedy pairing.
    ordered = sorted(selected, key=lambda item: item[2])
    right_order = [item[3] for item in ordered]
    if right_order != sorted(right_order):
        return None

    boundary_only = len(selected) == 1 and selected[0][1]
    if len(selected) == 1 and not boundary_only:
        # A lone simultaneous attack can be a real unison.  A single note is
        # merged across programs only when it is an explicit open->tie carry.
        return None

    return ProgramPatternMatch(
        left_program=left_program,
        right_program=right_program,
        note_count=len(selected),
        score=sum(item[0] for item in selected),
        boundary_continuation=boundary_only,
    )


def _infer_adjacent_program_matches(
    left: WindowResult, right: WindowResult, policy: OverlapPolicy
) -> list[ProgramPatternMatch]:
    overlap_start = max(left.window.start_time, right.window.start_time)
    overlap_end = min(left.window.end_time, right.window.end_time)
    if overlap_end <= overlap_start + _TIME_EPSILON:
        return []

    # Infer cross-instrument identity from the dynamically scaled central
    # trust zone, not from the two outer edge zones.  A span that starts in an
    # edge still participates when it continues into the centre; an isolated
    # edge blip cannot relabel an entire part.
    pattern_start = overlap_start + policy.edge_zone_seconds
    pattern_end = overlap_end - policy.edge_zone_seconds
    if pattern_end <= pattern_start + _TIME_EPSILON:
        pattern_start, pattern_end = overlap_start, overlap_end

    left_patterns = _overlap_patterns(left, pattern_start, pattern_end)
    right_patterns = _overlap_patterns(right, pattern_start, pattern_end)

    # Do not manufacture or delete an instrument part.  Cross-program mapping
    # is attempted only when both observations contain the same number of
    # active melodic programs in the trusted shared region.
    if not left_patterns or len(left_patterns) != len(right_patterns):
        return []

    common_programs = set(left_patterns) & set(right_patterns)
    left_changed = sorted(set(left_patterns) - common_programs)
    right_changed = sorted(set(right_patterns) - common_programs)
    if not left_changed or len(left_changed) != len(right_changed):
        return []
    if len(left_changed) > PATTERN_MAX_PROGRAMS:
        return []

    candidates: dict[int, list[ProgramPatternMatch]] = {}
    right_index = {program: index for index, program in enumerate(right_changed)}
    for left_program in left_changed:
        matches: list[ProgramPatternMatch] = []
        for right_program in right_changed:
            match = _match_program_pattern(
                left,
                left_program,
                left_patterns[left_program],
                right,
                right_program,
                right_patterns[right_program],
                policy,
            )
            if match is not None:
                matches.append(match)
        if not matches:
            return []
        candidates[left_program] = matches

    if any(
        not any(match.right_program == right_program for matches in candidates.values() for match in matches)
        for right_program in right_changed
    ):
        return []

    # Find the best complete one-to-one assignment.  Keep a runner-up as an
    # ambiguity check so identical unison patterns are not arbitrarily crossed.
    left_order = sorted(left_changed, key=lambda program: len(candidates[program]))
    states: dict[int, list[tuple[float, tuple[ProgramPatternMatch, ...]]]] = {
        0: [(0.0, ())]
    }
    for left_program in left_order:
        next_states: dict[int, list[tuple[float, tuple[ProgramPatternMatch, ...]]]] = {}
        for mask, options in states.items():
            for score, assignment in options:
                for match in candidates[left_program]:
                    bit = 1 << right_index[match.right_program]
                    if mask & bit:
                        continue
                    next_mask = mask | bit
                    next_states.setdefault(next_mask, []).append(
                        (score + match.score, assignment + (match,))
                    )

        states = {}
        for mask, options in next_states.items():
            options.sort(key=lambda item: item[0], reverse=True)
            unique: list[tuple[float, tuple[ProgramPatternMatch, ...]]] = []
            seen: set[tuple[tuple[int, int], ...]] = set()
            for option in options:
                signature = tuple(
                    sorted(
                        (match.left_program, match.right_program)
                        for match in option[1]
                    )
                )
                if signature in seen:
                    continue
                seen.add(signature)
                unique.append(option)
                if len(unique) == 2:
                    break
            states[mask] = unique

    final = states.get((1 << len(right_changed)) - 1, [])
    if not final:
        return []
    best_score, best_assignment = final[0]
    if len(final) > 1:
        second_score = final[1][0]
        required_margin = max(1.0, abs(best_score) * PATTERN_ASSIGNMENT_MARGIN_RATIO)
        if best_score - second_score <= required_margin:
            return []
    return list(best_assignment)


def _programs_in_result(result: WindowResult) -> set[int]:
    return {note.program for note in result.notes if not note.is_drum}


def _build_program_aliases(
    results: list[WindowResult], policy: OverlapPolicy
) -> tuple[list[dict[int, int]], dict[str, int]]:
    if not results:
        return [], {
            "instrument_pattern_boundaries": 0,
            "instrument_pattern_program_pairs": 0,
            "instrument_pattern_matched_notes": 0,
            "instrument_pattern_single_ties": 0,
            "instrument_alias_collisions_avoided": 0,
            "instrument_normalized_program_slots": 0,
        }

    aliases: list[dict[int, int]] = []
    first_programs = _programs_in_result(results[0])
    aliases.append({program: program for program in first_programs})

    applied_boundaries = 0
    applied_pairs = 0
    matched_notes = 0
    single_ties = 0
    collisions_avoided = 0

    for index in range(1, len(results)):
        previous_programs = _programs_in_result(results[index - 1])
        current_programs = _programs_in_result(results[index])
        previous_aliases = aliases[index - 1]
        current_aliases = {program: program for program in current_programs}

        # Preserve an already-established identity when the same raw program
        # continues into the next window.
        for program in previous_programs & current_programs:
            current_aliases[program] = previous_aliases.get(program, program)

        inferred = _infer_adjacent_program_matches(
            results[index - 1], results[index], policy
        )
        proposed_right_programs: set[int] = set()
        for match in inferred:
            canonical = previous_aliases.get(match.left_program, match.left_program)
            current_aliases[match.right_program] = canonical
            proposed_right_programs.add(match.right_program)

        # If two simultaneously active raw programs would collapse into one
        # canonical program, keep them separate.  That is the evidence pattern
        # for a possible real doubled/unison part rather than a label switch.
        by_canonical: dict[int, list[int]] = {}
        for raw_program, canonical in current_aliases.items():
            by_canonical.setdefault(canonical, []).append(raw_program)
        colliding_raw = {
            raw_program
            for raw_programs in by_canonical.values()
            if len(raw_programs) > 1
            for raw_program in raw_programs
        }
        if colliding_raw:
            collisions_avoided += len(colliding_raw)
            for raw_program in colliding_raw:
                current_aliases[raw_program] = raw_program

        applied = [
            match
            for match in inferred
            if match.right_program in proposed_right_programs
            and current_aliases.get(match.right_program, match.right_program)
            != match.right_program
        ]
        if applied:
            applied_boundaries += 1
            applied_pairs += len(applied)
            matched_notes += sum(match.note_count for match in applied)
            single_ties += sum(match.boundary_continuation for match in applied)

        aliases.append(current_aliases)

    return aliases, {
        "instrument_pattern_boundaries": applied_boundaries,
        "instrument_pattern_program_pairs": applied_pairs,
        "instrument_pattern_matched_notes": matched_notes,
        "instrument_pattern_single_ties": single_ties,
        "instrument_alias_collisions_avoided": collisions_avoided,
        "instrument_normalized_program_slots": sum(
            raw_program != canonical
            for window_aliases in aliases
            for raw_program, canonical in window_aliases.items()
        ),
    }


def _low_trust_edge_kind(
    note: GlobalNote, results: list[WindowResult], policy: OverlapPolicy
) -> str | None:
    """Return the low-confidence edge touched by this observation.

    Only edges that are covered by an adjacent window count.  The beginning of
    the first window and the end of the last window have no alternative view,
    so they are never discarded by this overlap filter.
    """
    result = results[note.source_window]
    local_onset = note.onset - result.window.start_time
    if note.source_window > 0 and local_onset < policy.edge_zone_seconds - _TIME_EPSILON:
        return "leading"
    if (
        note.source_window + 1 < len(results)
        and local_onset >= result.window.duration - policy.edge_zone_seconds - _TIME_EPSILON
    ):
        return "trailing"
    return None


def _candidate_is_corroborated(
    note: GlobalNote, peers: list[GlobalNote], policy: OverlapPolicy
) -> bool:
    """Check whether another overlapping window independently saw the event."""
    for other in peers:
        if other is note or other.source_window == note.source_window:
            continue
        if abs(other.source_window - note.source_window) > policy.max_observation_window_gap:
            continue
        if other.is_drum != note.is_drum:
            continue
        if abs(other.onset - note.onset) > EDGE_CORROBORATION_ONSET_SECONDS:
            continue
        if note.is_drum:
            return True
        interval_gap = max(note.onset, other.onset) - min(note.offset, other.offset)
        if interval_gap <= DUPLICATE_INTERVAL_GAP_SECONDS:
            return True
    return False


def _filter_edge_noise(
    candidates: list[GlobalNote],
    results: list[WindowResult],
    policy: OverlapPolicy,
) -> tuple[list[GlobalNote], dict[str, int]]:
    """Suppress only short, unconfirmed detections from shared outer edges.

    The midpoint owner is always retained.  A non-owner observation in the
    dynamically scaled outer edge of its source window is also retained when
    another overlapping window corroborates it or when it is long enough to be
    a plausible musical event.  The central ensemble zone keeps its recall.
    """
    by_key: dict[tuple[int, int], list[GlobalNote]] = {}
    for candidate in candidates:
        by_key.setdefault(candidate.key, []).append(candidate)

    kept: list[GlobalNote] = []
    edge_candidates = 0
    corroborated_kept = 0
    long_fallback_kept = 0
    melodic_rejected = 0
    drum_rejected = 0
    centre_fallback_kept = 0

    for note in candidates:
        edge_kind = _low_trust_edge_kind(note, results, policy)
        if note.source_is_owner or edge_kind is None:
            kept.append(note)
            if not note.source_is_owner:
                centre_fallback_kept += 1
            continue

        edge_candidates += 1
        if _candidate_is_corroborated(note, by_key[note.key], policy):
            kept.append(note)
            corroborated_kept += 1
            continue

        duration = max(0.0, note.offset - note.onset)
        if note.is_drum:
            # Drum notes intentionally have tiny durations.  Filter them only
            # at the exact 100 ms edge where decode artefacts are most likely;
            # another overlapping owner window still covers the same audio.
            if note.source_edge_margin < EDGE_DRUM_GUARD_SECONDS:
                drum_rejected += 1
                continue
            kept.append(note)
            long_fallback_kept += 1
            continue

        if duration < EDGE_SHORT_NOTE_SECONDS:
            melodic_rejected += 1
            continue

        kept.append(note)
        long_fallback_kept += 1

    return kept, {
        "edge_zone_candidates": edge_candidates,
        "edge_corroborated_notes_kept": corroborated_kept,
        "edge_long_fallback_notes_kept": long_fallback_kept,
        "edge_short_melodic_notes_rejected": melodic_rejected,
        "edge_drum_hits_rejected": drum_rejected,
        "edge_short_notes_rejected": melodic_rejected + drum_rejected,
        "center_fallback_candidates_kept": centre_fallback_kept,
    }


def _dedupe_candidates(
    candidates: list[GlobalNote], policy: OverlapPolicy
) -> tuple[list[GlobalNote], int, int, int, int]:
    by_key: dict[tuple[int, int], list[GlobalNote]] = {}
    for note in candidates:
        by_key.setdefault(note.key, []).append(note)

    output: list[GlobalNote] = []
    removed = 0
    cross_instrument_removed = 0
    later_window_priority_merges = 0
    later_window_program_priority_merges = 0
    for notes in by_key.values():
        notes.sort(key=lambda note: (note.onset, note.source_window))
        kept: list[GlobalNote] = []
        for note in notes:
            duplicate_index: int | None = None
            for index in range(len(kept) - 1, -1, -1):
                previous = kept[index]
                delta = note.onset - previous.onset
                if delta > ONSET_DEDUPE_SECONDS:
                    break
                interval_gap = max(note.onset, previous.onset) - min(
                    note.offset, previous.offset
                )
                same_observation = interval_gap <= DUPLICATE_INTERVAL_GAP_SECONDS
                if note.is_drum and previous.is_drum:
                    same_observation = abs(delta) <= ONSET_DEDUPE_SECONDS
                if (
                    abs(delta) <= ONSET_DEDUPE_SECONDS
                    and same_observation
                    and note.source_window != previous.source_window
                    and abs(note.source_window - previous.source_window) <= policy.max_observation_window_gap
                ):
                    duplicate_index = index
                    break
            if duplicate_index is None:
                kept.append(note)
                continue

            previous = kept[duplicate_index]
            # Unique detections from either window remain untouched.  Only after
            # two observations have been identified as the same event does the
            # most recent corroborating window get priority for onset, program,
            # and instrument.  Owner/edge margin are tie-breakers only.  The
            # longest observed offset and open state are still preserved.
            previous_score = (
                previous.priority_window,
                previous.source_window,
                previous.source_is_owner,
                previous.source_edge_margin,
            )
            note_score = (
                note.priority_window,
                note.source_window,
                note.source_is_owner,
                note.source_edge_margin,
            )
            winner = note if note_score > previous_score else previous
            loser = previous if winner is note else note
            winner.offset = max(previous.offset, note.offset)
            winner.trailing_open = previous.trailing_open or note.trailing_open
            kept[duplicate_index] = winner
            removed += 1
            later_window_priority_merges += 1
            if previous.selected_program != note.selected_program:
                cross_instrument_removed += 1
                if winner.selected_program != loser.selected_program:
                    later_window_program_priority_merges += 1
        output.extend(kept)

    output.sort(key=lambda note: (note.onset, note.offset, note.instrument, note.pitch))
    return (
        output,
        removed,
        cross_instrument_removed,
        later_window_priority_merges,
        later_window_program_priority_merges,
    )


def _merge_windows(
    results: list[WindowResult], total_duration: float, policy: OverlapPolicy
) -> tuple[list[GlobalNote], dict]:
    aliases, instrument_pattern_stats = _build_program_aliases(results, policy)
    leading_spans = [
        _leading_span_by_key(result, aliases[index])
        for index, result in enumerate(results)
    ]
    candidates: list[GlobalNote] = []
    raw_note_count = sum(len(result.notes) for result in results)
    owned_note_count = 0
    fallback_candidate_count = 0
    tie_extensions = 0
    duplicate_span_extensions = 0
    cross_instrument_tie_extensions = 0
    cross_instrument_duplicate_extensions = 0
    normalized_notes = 0
    later_continuation_priority_updates = 0
    later_continuation_program_changes = 0

    for index, result in enumerate(results):
        core_start, core_end = _core_bounds(results, index, total_duration)
        is_last = index + 1 == len(results)
        for local in result.notes:
            if local.leading_tie:
                continue
            canonical_program = aliases[index].get(local.program, local.program)
            canonical_key = (canonical_program, local.pitch)
            if canonical_program != local.program:
                normalized_notes += 1
            onset = result.window.start_time + local.onset
            if onset >= total_duration:
                continue

            # The overlap midpoint defines the preferred owner, but a note is
            # not discarded merely because it came from the other window.  If
            # the owner missed it, that one-sided detection is exactly the
            # recovery benefit the overlap ensemble is designed to preserve.
            source_is_owner = not (
                onset + _TIME_EPSILON < core_start
                or (not is_last and onset >= core_end - _TIME_EPSILON)
            )
            if source_is_owner:
                owned_note_count += 1
            else:
                fallback_candidate_count += 1
            offset = min(total_duration, result.window.start_time + local.offset)
            trailing = local.trailing_open
            selected_program = local.program
            selected_instrument = local.instrument
            priority_window = index
            if trailing and not local.is_drum:
                next_index = index + 1
                while next_index < len(results):
                    span = leading_spans[next_index].get(canonical_key)
                    extension_kind = "tie"
                    if span is None:
                        span = _matching_regular_span(
                            results[next_index],
                            canonical_key,
                            onset,
                            aliases[next_index],
                        )
                        extension_kind = "duplicate"
                    if span is None:
                        break
                    span_end = min(
                        total_duration,
                        results[next_index].window.start_time + span.offset,
                    )
                    if span_end <= onset + _TIME_EPSILON:
                        break
                    offset = span_end
                    if next_index > priority_window:
                        later_continuation_priority_updates += 1
                        if span.program != selected_program:
                            later_continuation_program_changes += 1
                        priority_window = next_index
                        selected_program = span.program
                        selected_instrument = span.instrument
                    if extension_kind == "tie":
                        tie_extensions += 1
                        if span.program != local.program:
                            cross_instrument_tie_extensions += 1
                    else:
                        duplicate_span_extensions += 1
                        if span.program != local.program:
                            cross_instrument_duplicate_extensions += 1
                    if not span.trailing_open:
                        trailing = False
                        break
                    next_index += 1

            minimum_end = onset + MINIMUM_NOTE_DURATION_SEC
            offset = min(total_duration, max(offset, minimum_end))
            if offset <= onset + _TIME_EPSILON:
                continue
            candidates.append(
                GlobalNote(
                    program=canonical_program,
                    selected_program=selected_program,
                    instrument=selected_instrument,
                    pitch=local.pitch,
                    onset=onset,
                    offset=offset,
                    is_drum=local.is_drum,
                    source_window=index,
                    priority_window=priority_window,
                    source_edge_margin=min(
                        local.onset,
                        max(0.0, result.window.duration - local.onset),
                    ),
                    source_is_owner=source_is_owner,
                    trailing_open=trailing,
                )
            )

    filtered_candidates, edge_filter_stats = _filter_edge_noise(
        candidates, results, policy
    )
    (
        merged,
        deduplicated,
        cross_instrument_deduplicated,
        later_window_priority_merges,
        later_window_program_priority_merges,
    ) = _dedupe_candidates(filtered_candidates, policy)
    stats = {
        "mode": "overlap_three_zone_later_window_priority",
        "window_seconds": WINDOW_SECONDS,
        "overlap_seconds": policy.overlap_seconds,
        "stride_seconds": policy.stride_seconds,
        "edge_zone_seconds": policy.edge_zone_seconds,
        "center_zone_seconds": policy.center_zone_seconds,
        "max_observation_window_gap": policy.max_observation_window_gap,
        "edge_short_note_seconds": EDGE_SHORT_NOTE_SECONDS,
        "edge_corroboration_onset_seconds": EDGE_CORROBORATION_ONSET_SECONDS,
        "window_count": len(results),
        "raw_local_notes": raw_note_count,
        "owned_notes_before_dedupe": owned_note_count,
        "fallback_candidates_before_edge_filter": fallback_candidate_count,
        "candidates_after_edge_filter": len(filtered_candidates),
        "fallback_candidates_after_edge_filter": sum(
            not note.source_is_owner for note in filtered_candidates
        ),
        "fallback_notes_kept": sum(not note.source_is_owner for note in merged),
        "tie_span_extensions": tie_extensions,
        "duplicate_span_extensions": duplicate_span_extensions,
        "cross_instrument_tie_extensions": cross_instrument_tie_extensions,
        "cross_instrument_duplicate_extensions": cross_instrument_duplicate_extensions,
        "deduplicated_onsets": deduplicated,
        "cross_instrument_deduplicated_onsets": cross_instrument_deduplicated,
        "later_window_priority_merges": later_window_priority_merges,
        "later_window_program_priority_merges": later_window_program_priority_merges,
        "later_continuation_priority_updates": later_continuation_priority_updates,
        "later_continuation_program_changes": later_continuation_program_changes,
        "instrument_normalized_notes": normalized_notes,
        "final_notes": len(merged),
        "onset_dedupe_seconds": ONSET_DEDUPE_SECONDS,
        **edge_filter_stats,
        **instrument_pattern_stats,
    }
    return merged, stats


def _note_fingerprint(note: GlobalNote) -> tuple:
    """Return a deterministic identity for an already-merged output note.

    Re-merging the processed prefix after every generation batch is deliberate:
    it lets the ordinary overlap rules decide which notes are final without
    maintaining a second incremental merger.  Fingerprints suppress notes that
    were already sent during an earlier pass.  An occurrence ordinal is added
    by :func:`_new_finalized_notes`, so even pathological identical notes remain
    representable.
    """
    return (
        int(note.selected_program),
        str(note.instrument),
        int(note.pitch),
        int(round(float(note.onset) * 1_000_000.0)),
        int(round(float(note.offset) * 1_000_000.0)),
        bool(note.is_drum),
    )


def _stream_safe_cutoff(
    windows: list[WindowInput], completed: int, total_duration: float
) -> float:
    """Time before which merged notes can no longer be changed by future input.

    Once windows ``[0, completed)`` have finished, the first unprocessed window
    begins at ``windows[completed].start_time``.  Future windows cannot observe
    audio before that point.  Holding an extra merge-tolerance guard protects
    onset/offset matching at the exact boundary.  On the final batch the whole
    duration is safe.
    """
    if completed >= len(windows):
        return float(total_duration)
    next_unseen_start = float(windows[completed].start_time)
    return max(
        0.0,
        min(
            float(total_duration),
            next_unseen_start - STREAM_FINALIZATION_GUARD_SECONDS,
        ),
    )


def _new_finalized_notes(
    notes: list[GlobalNote],
    safe_cutoff: float,
    emitted_keys: set[tuple],
) -> tuple[list[GlobalNote], list[tuple]]:
    """Select immutable notes not already exposed to the web client."""
    ordered = sorted(
        notes,
        key=lambda note: (
            note.onset,
            note.offset,
            note.instrument,
            note.pitch,
            note.source_window,
            note.priority_window,
        ),
    )
    occurrences: dict[tuple, int] = {}
    selected: list[GlobalNote] = []
    selected_keys: list[tuple] = []
    for note in ordered:
        fingerprint = _note_fingerprint(note)
        occurrence = occurrences.get(fingerprint, 0)
        occurrences[fingerprint] = occurrence + 1
        stable_key = fingerprint + (occurrence,)
        if note.offset > safe_cutoff + _TIME_EPSILON:
            continue
        if stable_key in emitted_keys:
            continue
        selected.append(note)
        selected_keys.append(stable_key)
    return selected, selected_keys


def _events_from_notes(
    notes: list[GlobalNote], *, start_index: int = 0
) -> Iterator[NoteStartEvent | NoteEndEvent]:
    timeline: list[tuple[float, int, NoteStartEvent | NoteEndEvent]] = []
    for local_index, note in enumerate(notes):
        start = NoteStartEvent(
            pitch=note.pitch,
            start_time=note.onset,
            index=start_index + local_index,
            instrument=note.instrument,
        )
        end = NoteEndEvent(end_time=note.offset, start_event=start)
        timeline.append((note.onset, 1, start))
        timeline.append((note.offset, 0, end))
    timeline.sort(key=lambda item: (item[0], item[1]))
    for _, _, event in timeline:
        yield event


def transcribe_with_overlap(
    model,
    audio,
    *,
    overlap_sec: float,
    use_sampling: bool = False,
    temperature: float = 1.0,
    cfg_coef: float = 1.0,
    instruments: list[str] | None = None,
    batch_size: int = 1,
    no_eos_is_ok: bool = True,
    beam_size: int = 1,
    cancel_event=None,
):
    """Transcribe independent 5-second windows and merge their shared audio.

    Every shared interval is divided into two scaled low-trust edge zones and
    one central ensemble zone.  Unique observations remain available for
    recall; only confirmed duplicate/continuation decisions prefer the later
    window.  After every generated batch, the already-immutable prefix is
    merged and streamed immediately to the web UI.  Only the tail that a future
    window can still extend or correct remains buffered.
    """
    if batch_size < 1:
        raise ValueError("오버랩 모드의 batch_size는 1 이상이어야 합니다.")
    if temperature <= 0:
        raise ValueError("temperature는 0보다 커야 합니다.")

    policy = OverlapPolicy.from_seconds(overlap_sec)
    started = time.perf_counter()
    wav = _load_wav(model, audio)
    windows, total_duration = _build_windows(wav, policy)
    tokenizer = model._tokenizer
    print(
        f"[muscriptor-overlap] audio: {total_duration:.1f}s → "
        f"{len(windows)} window(s), batch={batch_size}, {WINDOW_SECONDS:.1f}s window / "
        f"{policy.overlap_seconds:.1f}s overlap / {policy.stride_seconds:.1f}s stride / "
        f"zones {policy.edge_zone_seconds:.2f}+{policy.center_zone_seconds:.2f}+"
        f"{policy.edge_zone_seconds:.2f}s",
        file=sys.stderr,
    )

    yield ProgressEvent(completed=0, total=len(windows))
    results: list[WindowResult | None] = [None] * len(windows)
    batch_iter = _mlx_token_batches if _is_mlx_model(model) else _torch_token_batches

    emitted_keys: set[tuple] = set()
    next_event_index = 0
    streamed_before_final = 0
    stream_passes = 0
    stream_passes_with_notes = 0
    final_notes: list[GlobalNote] | None = None
    final_stats: dict | None = None

    batch_stream = batch_iter(
        model,
        windows,
        instruments=instruments,
        batch_size=batch_size,
        use_sampling=use_sampling,
        temperature=temperature,
        cfg_coef=cfg_coef,
        no_eos_is_ok=no_eos_is_ok,
        beam_size=beam_size,
        cancel_event=cancel_event,
    )
    try:
        for batch_start, batch_windows, token_lists, done in batch_stream:
            if cancel_event is not None and cancel_event.is_set():
                return
            for local_index, window in enumerate(batch_windows):
                results[window.index] = _decode_window_tokens(
                    window=window,
                    tokens=token_lists[local_index],
                    vocab=tokenizer._vocab,
                    frame_rate=tokenizer.frame_rate,
                    instrument_for_program=model._instrument_for_program,
                    emitted_eos=done[local_index],
                )

            completed = min(batch_start + len(batch_windows), len(windows))
            processed_results = results[:completed]
            if any(result is None for result in processed_results):
                raise RuntimeError("완료된 오버랩 창 결과 일부가 비어 있습니다.")
            typed_results = [result for result in processed_results if result is not None]

            # Re-run the normal merger on the completed prefix.  Its safe prefix is
            # immutable because every future 5-second window starts after the cutoff.
            merged_notes, partial_stats = _merge_windows(
                typed_results, total_duration, policy
            )
            safe_cutoff = _stream_safe_cutoff(windows, completed, total_duration)
            new_notes, new_keys = _new_finalized_notes(
                merged_notes, safe_cutoff, emitted_keys
            )

            if new_notes:
                yield from _events_from_notes(
                    new_notes,
                    start_index=next_event_index,
                )
                next_event_index += len(new_notes)
                emitted_keys.update(new_keys)
                stream_passes_with_notes += 1
                if completed < len(windows):
                    streamed_before_final += len(new_notes)

            stream_passes += 1
            buffered = sum(
                note.offset > safe_cutoff + _TIME_EPSILON for note in merged_notes
            )
            print(
                "[muscriptor-overlap] web stream: "
                f"windows={completed}/{len(windows)}, "
                f"finalized-through={safe_cutoff:.2f}s, "
                f"sent={len(new_notes)}, buffered={buffered}",
                file=sys.stderr,
            )

            if completed == len(windows):
                final_notes = merged_notes
                final_stats = partial_stats
            else:
                # Notes are emitted first, then the progress anchor.  The browser
                # therefore sees the newly completed piano-roll region immediately.
                yield ProgressEvent(completed=completed, total=len(windows))

    finally:
        close = getattr(batch_stream, "close", None)
        if callable(close):
            close()
        batch_stream = None

    if cancel_event is not None and cancel_event.is_set():
        return

    if any(result is None for result in results):
        raise RuntimeError("오버랩 창 결과 일부가 생성되지 않았습니다.")
    if final_notes is None or final_stats is None:
        typed_results = [result for result in results if result is not None]
        final_notes, final_stats = _merge_windows(
            typed_results, total_duration, policy
        )
        final_new_notes, final_new_keys = _new_finalized_notes(
            final_notes, total_duration, emitted_keys
        )
        if final_new_notes:
            yield from _events_from_notes(
                final_new_notes,
                start_index=next_event_index,
            )
            next_event_index += len(final_new_notes)
            emitted_keys.update(final_new_keys)

    stats = final_stats
    stats["elapsed_seconds"] = time.perf_counter() - started
    stats["stream_finalization_guard_seconds"] = STREAM_FINALIZATION_GUARD_SECONDS
    stats["stream_merge_passes"] = stream_passes
    stats["stream_merge_passes_with_notes"] = stream_passes_with_notes
    stats["streamed_notes_before_final_batch"] = streamed_before_final
    stats["streamed_note_count"] = next_event_index

    if next_event_index != len(final_notes):
        raise RuntimeError(
            "오버랩 스트리밍 노트 수가 최종 병합 결과와 일치하지 않습니다: "
            f"streamed={next_event_index}, final={len(final_notes)}"
        )

    print(
        "[muscriptor-overlap] merge: "
        f"raw={stats['raw_local_notes']}, owned={stats['owned_notes_before_dedupe']}, "
        f"fallback-kept={stats['fallback_notes_kept']}, "
        f"edge-rejected={stats['edge_short_notes_rejected']}, "
        f"edge-confirmed={stats['edge_corroborated_notes_kept']}, "
        f"tie-extended={stats['tie_span_extensions']}, "
        f"duplicate-extended={stats['duplicate_span_extensions']}, "
        f"instrument-map={stats['instrument_pattern_program_pairs']}, "
        f"cross-deduped={stats['cross_instrument_deduplicated_onsets']}, "
        f"later-priority={stats['later_window_priority_merges']}, "
        f"deduped={stats['deduplicated_onsets']}, final={stats['final_notes']}, "
        f"web-early={stats['streamed_notes_before_final_batch']}",
        file=sys.stderr,
    )
    yield ProgressEvent(completed=len(windows), total=len(windows))
    print(
        f"[muscriptor-overlap] transcribe total: {stats['elapsed_seconds']:.2f}s "
        f"({total_duration:.1f}s audio)",
        file=sys.stderr,
    )
