# Vendored and lifecycle-patched from MuScriptor v0.3.0 commit d73147e75e5b9b0c0a79ebe154587db4fd603e0c (MIT).
"""FastAPI server exposing transcription as an SSE event stream.

POST /transcribe with an audio file (multipart/form-data field `file`; WAV,
or any format soundfile/libsndfile can read — mp3, flac, ogg, m4a, …) returns
`text/event-stream`. Each event's data is a JSON dict tagged by `type`:
`start` / `end` note events (same shape as `muscriptor.main._event_to_dict`),
`progress` chunk anchors (`{completed, total}`), and a final
`transcription_complete` event carrying the base64-encoded .mid file.

POST /transcribe/midi takes the same upload but blocks until transcription
completes and returns the raw `audio/midi` bytes directly (no SSE, no
base64), with a `Content-Disposition: attachment` header. Audio longer than
15 minutes is rejected with 413.
"""

import asyncio
import base64
import dataclasses
import io
import json
import os
import tempfile
import threading
import time
import wave
from pathlib import Path
from typing import Annotated, Callable

from fastapi import FastAPI, File, Form, Header, HTTPException, UploadFile
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles

from stream_lifecycle import FinalizingStreamingResponse, ManagedSyncIterator
from constants import CANCEL_RUNTIME_REVISION, WEB_PATCH_SCHEMA

from muscriptor.events import NoteEndEvent, NoteStartEvent, ProgressEvent
from muscriptor.soundfonts import SF3_URL
from muscriptor.tokenizer.mt3 import MT3_FULL_PLUS_GROUP_NAMES
from muscriptor.transcription_model import TranscriptionModel
from muscriptor.utils.audio import _read_non_wav_file, _read_wav_file
from muscriptor.utils.download import download_if_necessary


def _make_release_once(lock: threading.Lock):
    """Return a callable that releases `lock` at most once.

    Safe to call from multiple cleanup paths (generator finally + managed
    response finalizer), possibly from different threads, without risking a
    double-release RuntimeError.
    """
    guard = threading.Lock()
    released = False

    def release():
        nonlocal released
        with guard:
            if released:
                return
            released = True
        lock.release()

    return release


_MAX_TRANSCRIBE_MIDI_DURATION_S = 15 * 60


class _NoStoreShellMiddleware:
    """Add cache-busting headers without BaseHTTPMiddleware.

    FastAPI's ``@app.middleware("http")`` uses BaseHTTPMiddleware, which
    wraps streaming responses in another in-memory stream and changes their
    disconnect/cancellation path.  A tiny pure-ASGI middleware preserves the
    custom transcription response lifecycle exactly.
    """

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        path = scope.get("path", "") if scope.get("type") == "http" else ""
        no_store = path in {"/", "/index.html"} or path.startswith(
            "/muscriptor-convenience-"
        )

        async def send_with_headers(message):
            if no_store and message.get("type") == "http.response.start":
                blocked = {b"cache-control", b"pragma", b"expires", b"x-muscriptor-web-patch"}
                headers = [
                    (key, value)
                    for key, value in message.get("headers", [])
                    if key.lower() not in blocked
                ]
                headers.extend(
                    [
                        (b"cache-control", b"no-store, no-cache, must-revalidate"),
                        (b"pragma", b"no-cache"),
                        (b"expires", b"0"),
                        (b"x-muscriptor-web-patch", str(WEB_PATCH_SCHEMA).encode("ascii")),
                    ]
                )
                message = {**message, "headers": headers}
            await send(message)

        await self.app(scope, receive, send_with_headers)


def event_to_dict(ev: NoteStartEvent | NoteEndEvent) -> dict:
    if isinstance(ev, NoteStartEvent):
        return {"type": "start", **dataclasses.asdict(ev)}
    return {
        "type": "end",
        "end_time": ev.end_time,
        "start_event_index": ev.start_event_index,
    }


def create_app(model: TranscriptionModel, web_dir: str | Path | None = None) -> FastAPI:
    app = FastAPI(title="muscriptor")
    app.add_middleware(_NoStoreShellMiddleware)

    def client_tag(value: str | None) -> str:
        if not value:
            return "none"
        return value if len(value) <= 12 else f"...{value[-8:]}"

    transcribe_lock = threading.Lock()
    lock_timeout_s = 60.0
    # State of the run currently holding the lock (or the last one to have held
    # it), guarded by `cancel_guard`: its cancel event and the id of the client
    # that started it. A new /transcribe from the SAME client (a resubmit in
    # the same browser tab) sets the cancel event so the in-flight run stops at
    # its next event boundary instead of transcribing to completion for a client
    # that has moved on. A request from a DIFFERENT client never preempts — it
    # waits for the lock like any other contender, so two independent browser
    # windows don't kill each other's transcription. This scoping must be done
    # here rather than by watching the socket: browser aborts don't always reach
    # us (e.g. port forwards / proxies keep the upstream connection open after
    # the browser aborts), so a same-tab resubmit can't be detected as a
    # disconnect.
    cancel_guard = threading.Lock()
    current_cancel: threading.Event | None = None
    current_done: threading.Event | None = None
    current_client: str | None = None
    current_stop: Callable[[], None] | None = None

    def request_transcription_cancel(*, reason: str = "external request") -> bool:
        """Set the active token-loop cancellation flag without locks or I/O.

        Uvicorn calls this from Python's signal handler.  A signal can interrupt
        the main thread while it already owns ``cancel_guard`` or stdout's
        internal lock, so this hook intentionally performs only an atomic
        reference read and ``Event.set()``.  The worker emits normal cleanup
        diagnostics after it unwinds through the completion/cancellation path.
        """
        del reason  # The signal path must remain side-effect free apart from Event.set().
        cancel_to_set = current_cancel
        if cancel_to_set is None:
            return False
        cancel_to_set.set()
        return True

    app.state.request_transcription_cancel = request_transcription_cancel

    @app.on_event("shutdown")
    async def stop_active_transcription_on_shutdown() -> None:
        """Unwind an active generator before Uvicorn tears down its loop.

        The response task is normally cancelled first during Ctrl+C, but the
        explicit application hook covers version/order differences in Uvicorn
        and Starlette.  It intentionally runs the stop callback synchronously:
        the default executor may already be shutting down at this point.
        """
        with cancel_guard:
            cancel_to_set = current_cancel
            done_to_wait = current_done
            stop_to_call = current_stop

        if cancel_to_set is None and done_to_wait is None:
            return

        print("[memory-cleanup] application shutdown cleanup started", flush=True)
        if cancel_to_set is not None:
            cancel_to_set.set()
        if stop_to_call is not None:
            try:
                stop_to_call()
            except BaseException as exc:
                print(
                    f"[memory-cleanup] application shutdown stop warning: {exc}",
                    flush=True,
                )
        elif done_to_wait is not None and not done_to_wait.wait(30.0):
            print(
                "[memory-cleanup] application shutdown wait timed out; "
                "the process exit will release the accelerator context",
                flush=True,
            )
        print("[memory-cleanup] application shutdown cleanup finished", flush=True)

    async def acquire_transcribe_lock(
        client_id: str | None, cancellable: bool
    ) -> tuple[threading.Event | None, threading.Event, Callable[[], None]]:
        """Acquire the single-transcription lock, preempting only a run started
        by this same `client_id` (a resubmit). A different client — or an
        anonymous API caller with no id — never preempts and is never preempted;
        it just waits for the lock (up to `lock_timeout_s`, then 503).

        Returns `(cancel, done, release)`: `cancel` is the new run's cancel
        event (`None` when `cancellable` is False, e.g. the blocking
        /transcribe/midi render); `done` is set only after the real worker and
        nested generators have unwound; `release` frees the lock at most once.
        """
        nonlocal current_cancel, current_done, current_client, current_stop
        deadline = time.monotonic() + lock_timeout_s
        while True:
            stop_previous: Callable[[], None] | None = None
            with cancel_guard:
                # Re-signal each iteration so that even a same-client run which
                # started while we were already waiting (a resubmit that beat us
                # to the lock) gets cancelled too — the newest request from a
                # given client always wins. Runs from other clients are left be.
                if (
                    current_cancel is not None
                    and client_id is not None
                    and current_client == client_id
                ):
                    current_cancel.set()
                    stop_previous = current_stop
            # Starlette does not close a synchronous StreamingResponse iterator
            # when the browser aborts it.  Actively close the old iterator so a
            # suspended overlap batch cannot keep accelerator KV tensors alive.
            if stop_previous is not None:
                # Keep generator ownership deterministic.  This may briefly
                # block request dispatch, but it cannot be abandoned by an
                # executor shutdown while accelerator tensors are still live.
                stop_previous()
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise HTTPException(
                    status_code=503,
                    detail="server busy: another transcription is in progress",
                )
            acquired = await asyncio.to_thread(
                transcribe_lock.acquire, True, min(1.0, remaining)
            )
            if acquired:
                break
        cancel = threading.Event() if cancellable else None
        done = threading.Event()
        with cancel_guard:
            current_cancel = cancel
            current_done = done
            current_client = client_id
            current_stop = None

        release_lock_once = _make_release_once(transcribe_lock)

        def release_current() -> None:
            nonlocal current_cancel, current_done, current_client, current_stop
            # Clear only the state owned by this run. A newer request may already
            # have replaced it while waiting for the shared transcription lock.
            with cancel_guard:
                if current_cancel is cancel and current_client == client_id:
                    current_cancel = None
                    current_done = None
                    current_client = None
                    current_stop = None
            done.set()
            release_lock_once()

        return cancel, done, release_current

    def register_current_stop(
        cancel: threading.Event | None,
        client_id: str | None,
        stop: Callable[[], None],
    ) -> None:
        nonlocal current_stop
        with cancel_guard:
            if current_cancel is cancel and current_client == client_id:
                current_stop = stop

    @app.get("/health")
    async def health():
        return {
            "status": "ok",
            "web_patch_schema": WEB_PATCH_SCHEMA,
            "cancel_runtime": CANCEL_RUNTIME_REVISION,
        }

    @app.get("/instruments")
    async def list_instruments():
        return {"instruments": list(MT3_FULL_PLUS_GROUP_NAMES.keys())}

    @app.post("/transcribe/cancel")
    async def cancel_transcription(
        x_client_id: Annotated[str | None, Header()] = None,
        x_cancel_reason: Annotated[str | None, Header()] = None,
        x_muscriptor_web_patch: Annotated[str | None, Header()] = None,
    ):
        """Cancel this browser tab's active run or clean an already-finished run.

        The official web UI's ``Transcribe another file`` action resets its local
        state without necessarily starting another /transcribe request. This
        endpoint gives that action an explicit server-side cancellation path.
        """
        cancel_requested = False
        client_match = False
        done_to_wait: threading.Event | None = None
        stop_to_call: Callable[[], None] | None = None
        with cancel_guard:
            active_run_present = current_done is not None
            # Normal path: exact per-tab client id match. Compatibility path:
            # an older cached web shell may have started /transcribe without a
            # client id, while the refreshed cancellation bridge already sends
            # one. Since the server owns only one transcription at a time, that
            # sole anonymous run can be safely stopped by the local bridge.
            client_match = bool(
                current_cancel is not None
                and (current_client == x_client_id or current_client is None)
            )
            if client_match:
                current_cancel.set()
                done_to_wait = current_done
                stop_to_call = current_stop
                cancel_requested = True

        print(
            "[memory-cleanup] cancel request received - "
            f"reason={x_cancel_reason or 'unspecified'}, "
            f"client={client_tag(x_client_id)}, active={active_run_present}, "
            f"client_match={client_match}, bridge={bool(x_muscriptor_web_patch)}",
            flush=True,
        )

        # Merely setting the cancellation flag is not enough for a synchronous
        # StreamingResponse: after the browser disconnects, Starlette can leave
        # its Python iterator suspended at the last yielded SSE chunk.  Close
        # that exact iterator so all nested overlap/KV-cache generators unwind.
        stream_closed = False
        if stop_to_call is not None:
            stop_to_call()
            stream_closed = True

        # Do not move the model while the token worker still owns live tensors.
        # The managed close above performs generator cleanup first and only then
        # marks `done`.  A timeout leaves the model untouched rather than racing
        # an in-flight accelerator operation.
        # With no active run this endpoint is a post-completion cleanup request.
        # If a run exists but belongs to another tab (or is the non-cancellable
        # /transcribe/midi endpoint), never offload its live model underneath it.
        stopped = not active_run_present
        if done_to_wait is not None:
            deadline = time.monotonic() + 120.0
            while not done_to_wait.is_set() and time.monotonic() < deadline:
                await asyncio.sleep(0.05)
            stopped = done_to_wait.is_set()
            if not stopped:
                print(
                    "[memory-cleanup] cancellation wait timed out; "
                    "backend memory was not reclaimed while generation is still active",
                    flush=True,
                )

        # The stream generator normally performs this during its finally block.
        # Repeat it after `done` as an idempotent last pass, and also cover the
        # case where there was no active stream (already-completed result page).
        cleanup = getattr(model, "cleanup_memory", None)
        if callable(cleanup) and stopped:
            cleanup(reason="새 파일 준비", offload_model=True)

        base_model = getattr(model, "_base", model)
        model_offloaded = bool(
            getattr(base_model, "_convenience_mps_offloaded", False)
            or getattr(base_model, "_convenience_cuda_offloaded", False)
        )
        result = {
            "cancel_requested": cancel_requested,
            "client_match": client_match,
            "stream_closed": stream_closed,
            "active_run": active_run_present,
            "stopped": stopped,
            "memory_cleaned": bool(stopped),
            "model_offloaded": model_offloaded,
        }
        print(f"[memory-cleanup] cancel result - {result}", flush=True)
        return result

    @app.get("/soundfonts/MuseScore_General.sf3")
    async def soundfont() -> FileResponse:
        """Compressed soundfont for the web UI's in-browser synthesizer.

        Fetched from SF3_URL on first request (in a worker thread, so the
        event loop keeps serving) and cached locally.
        """
        path = await asyncio.to_thread(download_if_necessary, SF3_URL)
        return FileResponse(path, media_type="application/octet-stream")

    @app.post("/transcribe")
    async def transcribe(
        file: Annotated[UploadFile, File()],
        instruments: Annotated[list[str], Form(default_factory=list)],
        x_client_id: Annotated[str | None, Header()] = None,
    ) -> FinalizingStreamingResponse:
        data = await file.read()
        # PCM WAV goes through the stdlib reader (keeps WAV decoding byte-for-byte
        # identical to the CLI); anything that isn't a readable WAV (mp3, flac,
        # ogg, m4a, …) falls back to soundfile/libsndfile. A genuinely
        # undecodable upload (corrupt/truncated file, or a format libsndfile
        # can't read) is the client's fault, so report it as a 400 rather than
        # letting it surface as a 500.
        try:
            wav, sr = _read_wav_file(io.BytesIO(data))
        except (wave.Error, EOFError):
            try:
                wav, sr = _read_non_wav_file(io.BytesIO(data))
            except Exception as e:
                raise HTTPException(
                    status_code=400,
                    detail=f"could not decode audio file '{file.filename}': {e}",
                ) from e

        unknown = [n for n in instruments if n not in MT3_FULL_PLUS_GROUP_NAMES]
        if unknown:
            raise HTTPException(
                status_code=400,
                detail=f"unknown instrument name(s): {', '.join(unknown)}",
            )

        # Acquire the single-transcription lock, preempting only a resubmit from
        # this same client (see acquire_transcribe_lock). The response owns a
        # deterministic finalizer which closes the synchronous iterator on
        # normal completion, errors, explicit cancellation, and disconnects.
        # Only after the real generator frames unwind is `done` signalled and
        # the lock released.
        cancel, done, release_lock = await acquire_transcribe_lock(
            x_client_id, cancellable=True
        )
        assert cancel is not None
        print(
            "[memory-cleanup] transcription stream registered - "
            f"client={client_tag(x_client_id)}, web_patch={WEB_PATCH_SCHEMA}",
            flush=True,
        )

        def gen():
            model_stream = None
            try:
                events: list[NoteStartEvent | NoteEndEvent] = []
                # MuScriptor v0.3.0 adds optional beat/tempo detection. Run it
                # once for this audio and attach the same grid to the final MIDI
                # and SSE payload while keeping note generation on our patched
                # overlap/cancellation lifecycle.
                beat_grid = model.detect_beat_grid_for((wav, sr), "best-effort")
                if cancel.is_set():
                    return
                # The official model honours batch_size=1 here.  The local
                # ConfiguredModel wrapper intentionally applies settings.toml instead;
                # in overlap mode it emits the immutable merged prefix after every
                # configured batch, so the piano roll still receives notes progressively.
                # no_eos_is_ok=True keeps one runaway window from aborting the stream.
                model_stream = model.transcribe(
                    (wav, sr),
                    instruments=instruments or None,
                    batch_size=1,
                    no_eos_is_ok=True,
                    cancel_event=cancel,
                )
                for ev in model_stream:
                    # A newer request preempted this run — stop generating
                    # (closing the model.transcribe generator) and release the
                    # lock via the finally, at most one chunk after the signal.
                    if cancel.is_set():
                        return
                    if isinstance(ev, ProgressEvent):
                        # Coarse chunk-completion anchor — forward it but keep it
                        # out of the note list the MIDI file is built from.
                        payload = json.dumps(
                            {
                                "type": "progress",
                                "completed": ev.completed,
                                "total": ev.total,
                            }
                        )
                        yield f"data: {payload}\n\n"
                        continue
                    events.append(ev)
                    payload = json.dumps(event_to_dict(ev))
                    yield f"data: {payload}\n\n"
                # All notes streamed — build the MIDI file in memory (reusing the
                # exact `muscriptor transcribe` logic) and send it as a final event
                # with the bytes base64-encoded.
                if cancel.is_set():
                    return
                midi_bytes = model.events_to_midi_bytes(
                    iter(events), beat_grid=beat_grid
                )
                midi_b64 = base64.b64encode(midi_bytes).decode("ascii")
                payload = json.dumps(
                    {
                        # MuScriptor v0.3.0's React client enables Download only
                        # when it receives this exact completion event name.
                        "type": "transcription_complete",
                        "data": midi_b64,
                        "beat_grid": (
                            dataclasses.asdict(beat_grid)
                            if beat_grid is not None
                            else None
                        ),
                    }
                )
                yield f"data: {payload}\n\n"
            finally:
                # A return caused by cancellation or an SSE disconnect must
                # close the nested model generator immediately.  Lock release
                # is in its own finally so even Ctrl+C during accelerator synchronization
                # cannot strand the server in a permanently-busy state.
                try:
                    close = getattr(model_stream, "close", None)
                    if callable(close):
                        try:
                            close()
                        except BaseException as exc:
                            print(
                                f"[memory-cleanup] model stream close warning: {exc}",
                                flush=True,
                            )
                    model_stream = None
                    cleanup = getattr(model, "cleanup_memory", None)
                    if callable(cleanup):
                        try:
                            cleanup(
                                reason="중단" if cancel.is_set() else "완료",
                                offload_model=True,
                            )
                        except BaseException as exc:
                            print(
                                f"[memory-cleanup] model cleanup warning: {exc}",
                                flush=True,
                            )
                finally:
                    release_lock()

        managed_stream = ManagedSyncIterator(gen(), cancel)
        finalizer_guard = threading.Lock()
        finalized = False

        def finalize_stream() -> None:
            """Close the actual SSE iterator exactly once, then verify cleanup."""
            nonlocal finalized
            with finalizer_guard:
                if finalized:
                    return
                finalized = True

                # This blocks only until an in-progress token step observes the
                # already-set cancellation event. close() then drives `gen()`'s
                # finally and every nested overlap/model generator finally.
                managed_stream.cancel_and_close()

                # Closing a Python generator before its first next() does not
                # execute its body or finally block. Cover that narrow race so
                # the model and lock are still released if a client disconnects
                # before Starlette begins iterating the response.
                if not done.is_set():
                    try:
                        cleanup = getattr(model, "cleanup_memory", None)
                        if callable(cleanup):
                            try:
                                cleanup(reason="연결 종료", offload_model=True)
                            except BaseException as exc:
                                print(
                                    f"[memory-cleanup] early-stream cleanup warning: {exc}",
                                    flush=True,
                                )
                    finally:
                        release_lock()

        register_current_stop(cancel, x_client_id, finalize_stream)

        return FinalizingStreamingResponse(
            managed_stream,
            finalizer=finalize_stream,
            media_type="text/event-stream",
            headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
        )

    @app.post("/transcribe/midi")
    async def transcribe_midi(
        file: Annotated[UploadFile, File()],
        instruments: Annotated[list[str], Form(default_factory=list)],
        x_client_id: Annotated[str | None, Header()] = None,
    ) -> Response:
        """Transcribe an audio file and return the .mid file directly.

        Unlike /transcribe, this blocks until transcription finishes and
        returns the raw MIDI bytes (no SSE, no base64) with a
        Content-Disposition header, so a plain HTTP client can save the
        response straight to disk.
        """
        data = await file.read()
        try:
            wav, sr = _read_wav_file(io.BytesIO(data))
        except (wave.Error, EOFError):
            try:
                wav, sr = _read_non_wav_file(io.BytesIO(data))
            except Exception as e:
                raise HTTPException(
                    status_code=400,
                    detail=f"could not decode audio file '{file.filename}': {e}",
                ) from e

        duration_s = wav.shape[-1] / sr
        if duration_s > _MAX_TRANSCRIBE_MIDI_DURATION_S:
            raise HTTPException(
                status_code=413,
                detail=(
                    f"audio file is {duration_s / 60:.1f} minutes long; "
                    f"the limit is {_MAX_TRANSCRIBE_MIDI_DURATION_S // 60:.0f} minutes"
                ),
            )

        unknown = [n for n in instruments if n not in MT3_FULL_PLUS_GROUP_NAMES]
        if unknown:
            raise HTTPException(
                status_code=400,
                detail=f"unknown instrument name(s): {', '.join(unknown)}",
            )

        # Same mutual exclusion as /transcribe, via the shared helper. This run
        # is not cancellable (it doesn't stream, so there's nothing to stop
        # mid-flight); cancellable=False records that, so nothing tries to
        # preempt a blocking MIDI render. A non-browser API caller sends no
        # client id and so neither preempts nor is preempted — it just waits for
        # the lock like any other contender.
        _cancel, _done, release_lock = await acquire_transcribe_lock(
            x_client_id, cancellable=False
        )
        try:
            midi_bytes = await asyncio.to_thread(
                model.transcribe_to_midi,
                (wav, sr),
                instruments=instruments or None,
            )
        finally:
            try:
                cleanup = getattr(model, "cleanup_memory", None)
                if callable(cleanup):
                    try:
                        await asyncio.to_thread(
                            cleanup,
                            reason="완료",
                            offload_model=True,
                        )
                    except BaseException as exc:
                        print(
                            f"[memory-cleanup] blocking MIDI cleanup warning: {exc}",
                            flush=True,
                        )
            finally:
                release_lock()

        return Response(
            content=midi_bytes,
            media_type="audio/midi",
            headers={"Content-Disposition": 'attachment; filename="result.mid"'},
        )

    @app.post("/auralize")
    async def auralize(
        midi: Annotated[UploadFile, File()],
        audio: Annotated[UploadFile | None, File()] = None,
        mode: Annotated[str, Form()] = "mix",
    ):
        """Render a transcription as WAV.

        mode="mix": stereo, original audio (L) + FluidSynth synthesis (R);
        requires the `audio` upload. mode="synth": mono, just the synthesis.
        """
        from muscriptor.utils.auralization import auralize as do_auralize
        from muscriptor.utils.auralization import synthesize

        if mode not in ("mix", "synth"):
            raise HTTPException(status_code=400, detail=f"unknown mode: {mode!r}")
        if mode == "mix" and audio is None:
            raise HTTPException(
                status_code=400, detail="mode='mix' requires an audio file"
            )

        midi_data = await midi.read()
        tmp_paths: list[str] = []

        with tempfile.NamedTemporaryFile(suffix=".mid", delete=False) as tmp_midi:
            tmp_midi.write(midi_data)
            midi_tmp = tmp_midi.name
            tmp_paths.append(midi_tmp)

        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp_out:
            out_tmp = tmp_out.name
            tmp_paths.append(out_tmp)

        try:
            if mode == "synth":
                synthesize(midi_path=midi_tmp, output_path=out_tmp)
            else:
                audio_data = await audio.read()
                suffix = Path(audio.filename or "audio.wav").suffix.lower() or ".wav"
                with tempfile.NamedTemporaryFile(
                    suffix=suffix, delete=False
                ) as tmp_audio:
                    tmp_audio.write(audio_data)
                    tmp_paths.append(tmp_audio.name)
                do_auralize(
                    midi_path=midi_tmp,
                    original_audio_path=tmp_audio.name,
                    output_path=out_tmp,
                )
            with open(out_tmp, "rb") as f:
                wav_bytes = f.read()
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))
        finally:
            for p in tmp_paths:
                if os.path.exists(p):
                    os.unlink(p)

        return Response(content=wav_bytes, media_type="audio/wav")

    if web_dir is not None:
        web_path = Path(web_dir)
        if web_path.is_dir():
            app.mount("/", StaticFiles(directory=web_path, html=True), name="web")

    return app
