from __future__ import annotations

import gc
import threading


def close_iterator(iterator) -> None:
    """Close a generator/iterator when it exposes close(), suppressing cleanup errors."""
    if iterator is None:
        return
    close = getattr(iterator, "close", None)
    if not callable(close):
        return
    try:
        close()
    except BaseException as exc:
        print(f"[memory-cleanup] iterator close warning: {exc}", flush=True)


def _backend_name(model) -> str:
    return str(getattr(model, "_effective_backend", "")).lower()


def _format_mib(value: int | None) -> str:
    if value is None or value < 0:
        return "n/a"
    return f"{value / (1024 * 1024):.1f} MiB"


def _safe_memory_value(target, name: str) -> int | None:
    function = getattr(target, name, None)
    if not callable(function):
        return None
    try:
        return int(function())
    except BaseException:
        return None


def _mlx_stats(mx) -> tuple[int | None, int | None, int | None]:
    return (
        _safe_memory_value(mx, "get_active_memory"),
        _safe_memory_value(mx, "get_cache_memory"),
        _safe_memory_value(mx, "get_peak_memory"),
    )


def _torch_core_module(model):
    try:
        import torch

        core = getattr(model, "_model", None)
        if isinstance(core, torch.nn.Module):
            return core
        if isinstance(model, torch.nn.Module):
            return model
    except BaseException:
        return None
    return None


def _set_device_attribute(target, name: str, value) -> None:
    try:
        if target is not None and hasattr(target, name):
            setattr(target, name, value)
    except BaseException:
        pass


def restore_backend_model(model, *, reason: str = "변환 준비") -> bool:
    """Restore a torch MPS model that was moved to CPU after the previous run.

    MLX uses unified memory, so there is no CPU/GPU copy to restore. Its resident
    weights stay available while only per-run arrays and allocator cache are
    reclaimed.
    """
    backend = _backend_name(model)
    if "mps" not in backend:
        return False
    if not bool(getattr(model, "_convenience_mps_offloaded", False)):
        return False

    try:
        import torch
    except BaseException:
        return False

    lock = getattr(model, "_convenience_memory_lock", None)
    if lock is None:
        lock = threading.RLock()
        setattr(model, "_convenience_memory_lock", lock)

    with lock:
        if not bool(getattr(model, "_convenience_mps_offloaded", False)):
            return False
        core = _torch_core_module(model)
        if core is None or not torch.backends.mps.is_available():
            return False

        device = torch.device("mps")
        print(f"[memory-cleanup] MPS model restoring ({reason})...", flush=True)
        core.to(device)
        _set_device_attribute(core, "device", device)
        _set_device_attribute(model, "_device", device)
        synchronize = getattr(torch.mps, "synchronize", None)
        if callable(synchronize):
            synchronize()
        setattr(model, "_convenience_mps_offloaded", False)
        print(f"[memory-cleanup] MPS model restored ({reason})", flush=True)
        return True


def _offload_mps_model(model, *, reason: str) -> bool:
    if "mps" not in _backend_name(model):
        return False

    try:
        import torch
    except BaseException:
        return False
    if not torch.backends.mps.is_available():
        return False

    lock = getattr(model, "_convenience_memory_lock", None)
    if lock is None:
        lock = threading.RLock()
        setattr(model, "_convenience_memory_lock", lock)

    with lock:
        core = _torch_core_module(model)
        if core is not None and not bool(
            getattr(model, "_convenience_mps_offloaded", False)
        ):
            synchronize = getattr(torch.mps, "synchronize", None)
            if callable(synchronize):
                synchronize()
            cpu = torch.device("cpu")
            core.to(cpu)
            _set_device_attribute(core, "device", cpu)
            _set_device_attribute(model, "_device", cpu)
            setattr(model, "_convenience_mps_offloaded", True)

        gc.collect()
        synchronize = getattr(torch.mps, "synchronize", None)
        if callable(synchronize):
            synchronize()
        empty_cache = getattr(torch.mps, "empty_cache", None)
        if callable(empty_cache):
            empty_cache()
        gc.collect()
        if callable(empty_cache):
            empty_cache()
        print(f"[memory-cleanup] MPS model offloaded to CPU ({reason})", flush=True)
        return True


def cleanup_backend_cache(model, *, reason: str, offload_model: bool = False) -> None:
    """Deterministically release per-run backend memory after generators unwind.

    ``offload_model`` is honored by the official PyTorch MPS fallback. MLX has a
    unified-memory model and cannot be meaningfully moved between CPU and GPU;
    its model weights remain resident while temporary arrays and the free cache
    are reclaimed.
    """
    backend = _backend_name(model)
    lock = getattr(model, "_convenience_memory_lock", None)
    if lock is None:
        lock = threading.RLock()
        setattr(model, "_convenience_memory_lock", lock)

    with lock:
        if backend.startswith("mlx"):
            try:
                import mlx.core as mx

                before_active, before_cache, before_peak = _mlx_stats(mx)
                gc.collect()
                synchronize = getattr(mx, "synchronize", None)
                if callable(synchronize):
                    synchronize()
                mx.clear_cache()
                # A second pass catches arrays finalized by generator/frame
                # destruction during the first collection.
                gc.collect()
                if callable(synchronize):
                    synchronize()
                mx.clear_cache()
                after_active, after_cache, after_peak = _mlx_stats(mx)
                print(
                    "[memory-cleanup] MLX temporary memory cleared "
                    f"({reason}) - active {_format_mib(before_active)} -> "
                    f"{_format_mib(after_active)}, cache "
                    f"{_format_mib(before_cache)} -> {_format_mib(after_cache)}, "
                    f"peak={_format_mib(after_peak if after_peak is not None else before_peak)}",
                    flush=True,
                )
                if after_cache not in (None, 0):
                    print(
                        "[memory-cleanup] warning: MLX cache remains after clear_cache "
                        f"({_format_mib(after_cache)})",
                        flush=True,
                    )
            except BaseException as exc:
                print(f"[memory-cleanup] MLX cache warning: {exc}", flush=True)
            return

        if "mps" in backend:
            try:
                if offload_model and _offload_mps_model(model, reason=reason):
                    return
                import torch

                gc.collect()
                synchronize = getattr(torch.mps, "synchronize", None)
                if callable(synchronize):
                    synchronize()
                empty_cache = getattr(torch.mps, "empty_cache", None)
                if callable(empty_cache):
                    empty_cache()
                print(f"[memory-cleanup] MPS cache cleared ({reason})", flush=True)
            except BaseException as exc:
                print(f"[memory-cleanup] MPS cache warning: {exc}", flush=True)
            return

        if "cuda" in backend:
            # This branch is not expected in the macOS package, but keeping it
            # makes the wrapper safe when the official model is imported in a
            # cross-platform development environment.
            try:
                import torch

                if torch.cuda.is_available():
                    gc.collect()
                    torch.cuda.synchronize()
                    torch.cuda.empty_cache()
                    ipc_collect = getattr(torch.cuda, "ipc_collect", None)
                    if callable(ipc_collect):
                        ipc_collect()
                    print(f"[memory-cleanup] CUDA cache cleared ({reason})", flush=True)
            except BaseException as exc:
                print(f"[memory-cleanup] CUDA cache warning: {exc}", flush=True)
            return

        gc.collect()
