from __future__ import annotations

import asyncio
import threading
from collections.abc import Callable, Iterable, Iterator
from typing import Any

from starlette.responses import StreamingResponse


class ManagedSyncIterator(Iterator[Any]):
    """Serialize ``next()`` and ``close()`` for a thread-pooled sync stream.

    Starlette adapts a synchronous iterator with ``iterate_in_threadpool``.
    Depending on the Starlette/ASGI version, a browser disconnect can cancel
    only the async adapter while the underlying synchronous generator remains
    suspended at its last ``yield``.  Such a suspended frame keeps the overlap
    generator, conditions and accelerator KV cache alive.

    ``cancel_and_close`` sets the model cancellation flag *before* waiting for
    the current ``next()`` call.  The token loop therefore exits at its next
    cancellation checkpoint, after which the exact generator is closed while
    no other thread is executing it.
    """

    def __init__(self, iterable: Iterable[Any], cancel_event: threading.Event):
        self._iterator: Iterator[Any] | None = iter(iterable)
        self._cancel_event = cancel_event
        self._lock = threading.RLock()
        self._closed = False

    def __iter__(self) -> "ManagedSyncIterator":
        return self

    def __next__(self) -> Any:
        with self._lock:
            iterator = self._iterator
            if self._closed or iterator is None:
                raise StopIteration
            try:
                return next(iterator)
            except StopIteration:
                self._closed = True
                self._iterator = None
                raise
            except BaseException:
                # The wrapped generator's own finally blocks run while the
                # exception propagates. Drop our final reference afterwards.
                self._closed = True
                self._iterator = None
                raise

    @property
    def closed(self) -> bool:
        with self._lock:
            return self._closed

    def request_cancel(self) -> None:
        """Signal cancellation without waiting for the active token step."""
        self._cancel_event.set()

    def cancel_and_close(self) -> None:
        """Stop generation and deterministically unwind every nested frame."""
        self.request_cancel()

        with self._lock:
            iterator = self._iterator
            if self._closed or iterator is None:
                return

            # Remove the shared reference before user cleanup. The local
            # reference lives only until close() finishes unwinding the stack.
            self._closed = True
            self._iterator = None
            close = getattr(iterator, "close", None)
            if callable(close):
                try:
                    close()
                except BaseException as exc:
                    # Cleanup must not turn Ctrl+C or a client disconnect into
                    # an unhandled ASGI exception. The server-side generator
                    # already received its cancellation signal above.
                    print(
                        f"[memory-cleanup] managed stream close warning: {exc}",
                        flush=True,
                    )


class FinalizingStreamingResponse(StreamingResponse):
    """Streaming response with deterministic disconnect and shutdown cleanup.

    Starlette 0.50+ does not listen for ``http.disconnect`` on ASGI 2.4; it
    relies on a failed ``send()`` instead.  A synchronous model iterator can be
    busy for a long time before its next send, and may remain suspended after
    the browser returns to the welcome screen.  This response always runs an
    explicit disconnect listener, independent of ASGI spec version.

    Cleanup is synchronous and idempotent.  It is deliberately not detached to
    the event-loop executor: during Ctrl+C that executor may already be shutting
    down, which previously produced errors such as "cannot schedule new futures
    after shutdown" and left the model generator alive.
    """

    def __init__(self, *args, finalizer: Callable[[], None], **kwargs):
        super().__init__(*args, **kwargs)
        self._stream_finalizer = finalizer
        self._finalizer_guard = threading.Lock()
        self._finalized = False

    def _finalize_once(self, reason: str) -> None:
        with self._finalizer_guard:
            if self._finalized:
                return
            self._finalized = True

        print(f"[memory-cleanup] stream finalizer started ({reason})", flush=True)
        try:
            self._stream_finalizer()
        except BaseException as exc:
            # Never let cleanup obscure the user's Ctrl+C or generate a second
            # ASGI traceback. The process exit itself releases the CUDA context.
            print(
                f"[memory-cleanup] stream finalizer warning ({reason}): {exc}",
                flush=True,
            )
        else:
            print(f"[memory-cleanup] stream finalizer finished ({reason})", flush=True)

    async def __call__(self, scope, receive, send) -> None:
        stream_task = asyncio.create_task(
            self.stream_response(send), name="muscriptor-sse-stream"
        )
        disconnect_task = asyncio.create_task(
            self.listen_for_disconnect(receive), name="muscriptor-sse-disconnect"
        )
        pending: set[asyncio.Task] = set()
        propagate: BaseException | None = None
        final_reason = "stream complete"

        try:
            done, pending = await asyncio.wait(
                {stream_task, disconnect_task},
                return_when=asyncio.FIRST_COMPLETED,
            )

            if disconnect_task in done:
                final_reason = "client disconnect"
                print("[memory-cleanup] client disconnect detected", flush=True)
                # This sets the token-loop cancellation flag before waiting for
                # the worker thread, then closes the exact generator.
                self._finalize_once(final_reason)
                if not stream_task.done():
                    stream_task.cancel()
            else:
                # Consume the stream result so genuine model exceptions are not
                # lost. OSError is the ASGI 2.4 form of a client disconnect.
                try:
                    await stream_task
                except OSError:
                    final_reason = "client send failure"
                    print("[memory-cleanup] client send failure detected", flush=True)
                except asyncio.CancelledError:
                    final_reason = "stream task cancelled"
                except BaseException as exc:
                    final_reason = "stream error"
                    propagate = exc
                self._finalize_once(final_reason)
                if not disconnect_task.done():
                    disconnect_task.cancel()

        except asyncio.CancelledError:
            # Uvicorn cancels active HTTP tasks during Ctrl+C. Finish the model
            # generator now and consume the cancellation so shutdown is clean.
            final_reason = "server shutdown"
            print("[memory-cleanup] server shutdown cancellation received", flush=True)
            self._finalize_once(final_reason)
        except BaseException as exc:
            final_reason = "response error"
            propagate = exc
            self._finalize_once(final_reason)
        finally:
            self._finalize_once(final_reason)
            for task in (stream_task, disconnect_task, *pending):
                if not task.done():
                    task.cancel()
            # The model worker has already been joined by the finalizer. These
            # are now lightweight async wrappers; collect them without exposing
            # CancelledError as a Ctrl+C traceback.
            await asyncio.gather(stream_task, disconnect_task, return_exceptions=True)
            if self.background is not None:
                try:
                    await self.background()
                except BaseException as exc:
                    print(
                        f"[memory-cleanup] response background warning: {exc}",
                        flush=True,
                    )

        if propagate is not None:
            raise propagate
