from __future__ import annotations

import json
import math
import sys
import time
import warnings
from dataclasses import dataclass
from pathlib import Path

import mlx.core as mx
import mlx.nn as nn
import numpy as np
import torch
import torch.nn.functional as torch_f
from mlx_lm.models.base import scaled_dot_product_attention
from mlx_lm.models.cache import KVCache, QuantizedKVCache
from mlx.utils import tree_flatten

from muscriptor.events import ChunkBoundary, OpenNoteTracker, ProgressEvent, decode_model_tokens
from muscriptor.modules.conditioners import (
    ClassConditioner,
    ConditioningAttributes,
    ConditioningProvider,
    MelSpectrogramConditioner,
    WavCondition,
    nullify_all_conditions,
)
from muscriptor.tokenizer.mt3 import MT3Tokenizer, instrument_group_from_names
from muscriptor.transcription_model import (
    TranscriptionModel as TorchTranscriptionModel,
    _build_instrument_for_program,
)
from muscriptor.utils.audio import load_audio, resample

SAMPLE_RATE = 16000
SEGMENT_DURATION = 5.0
MAX_GEN_LEN = 2000


def _build_additive_mask(card: int, tokenizer, instruments: list[str] | None) -> np.ndarray:
    additive = np.zeros((card,), dtype=np.float32)
    if card > 1393:
        additive[1393:] = -np.inf
    if instruments:
        for token_id in tokenizer.forbidden_token_ids(instruments):
            if 0 <= token_id < card:
                additive[token_id] = -np.inf
    return additive


@dataclass(frozen=True)
class QuantizedWeight:
    weight: object
    scales: object
    biases: object | None
    group_size: int
    bits: int
    mode: str


class CastKVCache(KVCache):
    def __init__(self, dtype):
        super().__init__()
        self.storage_dtype = dtype

    def update_and_fetch(self, keys, values):
        if keys.dtype != self.storage_dtype:
            keys = keys.astype(self.storage_dtype)
            values = values.astype(self.storage_dtype)
        return super().update_and_fetch(keys, values)


class WeightStore:
    def __init__(self, model_dir: Path):
        self.model_dir = model_dir
        self.manifest = json.loads(
            (model_dir / "manifest.json").read_text(encoding="utf-8")
        )
        self.config = json.loads(
            (model_dir / "config.json").read_text(encoding="utf-8")
        )
        self.token_dtype = (
            mx.float16 if self.manifest["token_dtype"] == "float16" else mx.float32
        )
        self.weights: dict[str, object] = {}
        self.condition_entries: list[dict] = []

        pending: list[object] = []
        entries = self.manifest["entries"]
        for index, entry in enumerate(entries, 1):
            if entry["name"].startswith("condition_provider."):
                self.condition_entries.append(entry)
                continue
            loaded = mx.load(str(model_dir / entry["file"]))
            if entry["kind"] == "mlx_q8_ffn":
                quantization = entry["quantization"]
                value = QuantizedWeight(
                    weight=loaded["weight"],
                    scales=loaded["scales"],
                    biases=loaded.get("biases"),
                    group_size=int(quantization["group_size"]),
                    bits=int(quantization["bits"]),
                    mode=str(quantization["mode"]),
                )
                self.weights[entry["name"]] = value
                pending.extend([value.weight, value.scales])
                if value.biases is not None:
                    pending.append(value.biases)
            else:
                value = loaded["value"]
                self.weights[entry["name"]] = value
                pending.append(value)
            if len(pending) >= 24:
                mx.eval(*pending)
                pending.clear()
            if index % 20 == 0 or index == len(entries):
                print(f"  load {index}/{len(entries)}")
        if pending:
            mx.eval(*pending)

    def get(self, name: str):
        return self.weights[name]

    def optional(self, name: str):
        return self.weights.get(name)


class TorchConditionEncoder:
    def __init__(self, store: WeightStore):
        cfg = store.config
        dim = int(cfg["dim"])
        mel = MelSpectrogramConditioner(
            output_dim=dim,
            device="cpu",
            sample_rate=SAMPLE_RATE,
            n_fft=2048,
            frame_rate=100,
            n_mel_bins=512,
            log_scale=True,
            eps=1e-6,
            normalize_audio=False,
        )
        instrument = ClassConditioner(1000, dim, device="cpu")
        dataset = ClassConditioner(4, dim, device="cpu")
        self.provider = ConditioningProvider(
            {
                "self_wav": mel,
                "instrument_group": instrument,
                "dataset_name": dataset,
            },
            device="cpu",
        )
        state = {}
        from safetensors.torch import load_file

        for entry in store.condition_entries:
            tensor = load_file(
                store.model_dir / entry["file"], device="cpu"
            )["value"]
            state[entry["name"].removeprefix("condition_provider.")] = tensor
        self.provider.load_state_dict(state, strict=True)
        self.provider.eval()
        self.token_dtype = store.token_dtype

    def encode(self, chunks, lengths, instrument_group, cfg_coef):
        samples = []
        for chunk, length in zip(chunks, lengths):
            condition = WavCondition(
                wav=chunk.unsqueeze(0),
                length=torch.tensor([length], dtype=torch.long),
                sample_rate=[SAMPLE_RATE],
                path=[None],
                seek_time=[0.0],
            )
            samples.append(
                ConditioningAttributes(
                    wav={"self_wav": condition},
                    text={
                        "instrument_group": instrument_group,
                        "dataset_name": None,
                    },
                )
            )
        if cfg_coef != 1.0:
            samples = samples + nullify_all_conditions(samples)

        tokenized = self.provider.tokenize(samples)
        with torch.no_grad():
            encoded = self.provider(tokenized)
        output = []
        for condition, _mask in encoded.values():
            array = mx.array(condition.detach().cpu().numpy())
            if array.dtype != self.token_dtype:
                array = array.astype(self.token_dtype)
            output.append(array)
        return output


class MLXCore:
    def __init__(self, store: WeightStore):
        self.w = store
        cfg = store.config
        self.dim = int(cfg["dim"])
        self.num_heads = int(cfg["num_heads"])
        self.num_layers = int(cfg["num_layers"])
        self.card = int(cfg["card"])
        self.head_dim = self.dim // self.num_heads
        self.dtype = store.token_dtype

    @staticmethod
    def linear(x, weight, bias=None):
        if isinstance(weight, QuantizedWeight):
            y = mx.quantized_matmul(
                x,
                weight.weight,
                weight.scales,
                weight.biases,
                transpose=True,
                group_size=weight.group_size,
                bits=weight.bits,
                mode=weight.mode,
            )
            return y if bias is None else mx.add(y, bias)
        transposed = mx.swapaxes(weight, -1, -2)
        if bias is None:
            return mx.matmul(x, transposed)
        return mx.addmm(bias, x, transposed)

    def norm(self, x, prefix):
        return mx.fast.layer_norm(
            x,
            self.w.get(prefix + ".weight"),
            self.w.optional(prefix + ".bias"),
            1e-5,
        )

    @staticmethod
    def gelu(x):
        return nn.gelu(x)

    def position(self, batch: int, length: int, offset: int):
        half = self.dim // 2
        positions = mx.arange(offset, offset + length, dtype=mx.float32).reshape(1, length, 1)
        dimensions = mx.arange(half, dtype=mx.float32).reshape(1, 1, half)
        exponent = dimensions / float(half - 1)
        denominator = mx.exp(mx.log(mx.array(10000.0, dtype=mx.float32)) * exponent)
        phase = positions / denominator
        value = mx.concatenate([mx.cos(phase), mx.sin(phase)], axis=-1)
        value = value.astype(self.dtype)
        if batch != 1:
            value = mx.broadcast_to(value, (batch, length, self.dim))
        return value

    def attention(self, x, layer: int, cache):
        prefix = f"transformer.layers.{layer}.self_attn"
        projected = self.linear(x, self.w.get(prefix + ".in_proj_weight"))
        batch, length, _ = projected.shape
        packed = projected.reshape(
            batch, length, 3, self.num_heads, self.head_dim
        )
        q = mx.transpose(packed[:, :, 0], (0, 2, 1, 3))
        k = mx.transpose(packed[:, :, 1], (0, 2, 1, 3))
        v = mx.transpose(packed[:, :, 2], (0, 2, 1, 3))
        k, v = cache.update_and_fetch(k, v)

        if not hasattr(cache, "bits") and q.dtype != k.dtype:
            q = q.astype(k.dtype)
        mask = "causal" if length > 1 else None
        out = scaled_dot_product_attention(
            q,
            k,
            v,
            cache,
            scale=self.head_dim ** -0.5,
            mask=mask,
        )
        if out.dtype != self.dtype:
            out = out.astype(self.dtype)
        out = mx.transpose(out, (0, 2, 1, 3)).reshape(
            batch, length, self.dim
        )
        return self.linear(out, self.w.get(prefix + ".out_proj.weight"))

    def forward(self, tokens, conditions, caches, first_step: bool):
        tokens = tokens.astype(mx.int32)
        x = self.w.get("emb.weight")[tokens]
        token_length = x.shape[1]
        if first_step:
            x = mx.concatenate([*conditions, x], axis=1)
        x = x + self.position(x.shape[0], x.shape[1], int(caches[0].offset))
        for layer in range(self.num_layers):
            x = x + self.attention(
                self.norm(x, f"transformer.layers.{layer}.norm1"),
                layer,
                caches[layer],
            )
            h = self.linear(
                self.norm(x, f"transformer.layers.{layer}.norm2"),
                self.w.get(f"transformer.layers.{layer}.linear1.weight"),
            )
            h = self.gelu(h)
            h = self.linear(
                h,
                self.w.get(f"transformer.layers.{layer}.linear2.weight"),
            )
            x = x + h
        x = self.norm(x, "out_norm")
        if first_step:
            x = x[:, -token_length:]
        return self.linear(x, self.w.get("linear.weight"))


class MLXTranscriptionModel:
    def __init__(self, model_dir: Path, kv_mode: str):
        if not mx.metal.is_available():
            raise RuntimeError("MLX Metal을 사용할 수 없습니다.")
        mx.set_default_device(mx.gpu)
        print("MLX Metal:", mx.metal.device_info())

        self.store = WeightStore(model_dir)
        self.core = MLXCore(self.store)
        self.conditions = TorchConditionEncoder(self.store)
        self.kv_mode = self._resolve_kv(kv_mode)
        self._effective_precision = self.store.manifest.get(
            "effective_precision", self.store.manifest["precision"]
        )
        self._effective_backend = "mlx_native_v022"
        self._effective_kv = self.kv_mode
        self._effective_kv_backend = (
            "mlx_lm.QuantizedKVCache"
            if self.kv_mode == "q8"
            else "mlx_lm.KVCache"
        )

        self.tokenizer = MT3Tokenizer(
            instrument_vocabulary="MT3_FULL_PLUS", max_shift_steps=1001
        )
        self._tokenizer = self.tokenizer
        self._instrument_for_program = _build_instrument_for_program(self.tokenizer)
        helper = object.__new__(TorchTranscriptionModel)
        helper._tokenizer = self.tokenizer
        helper._instrument_for_program = self._instrument_for_program
        self._midi_helper = helper
        self._trace_callback = None

    def _resolve_kv(self, requested: str) -> str:
        if requested == "auto":
            return "fp16" if self.store.token_dtype == mx.float16 else "fp32"
        return requested

    def events_to_midi_bytes(self, events):
        return self._midi_helper.events_to_midi_bytes(events)

    def transcribe_to_midi(self, audio, **kwargs):
        return self.events_to_midi_bytes(self.transcribe(audio, **kwargs))

    def _cache(self):
        if self.kv_mode == "q8":
            return QuantizedKVCache(group_size=64, bits=8)
        dtype = mx.float16 if self.kv_mode == "fp16" else mx.float32
        return CastKVCache(dtype)

    def _load_wav(self, audio, sample_rate=None):
        if isinstance(audio, (str, Path)):
            wav = load_audio(audio, target_sr=SAMPLE_RATE)
        else:
            wav = audio.float()
            if wav.dim() == 1:
                wav = wav.unsqueeze(0)
            if wav.dim() == 3:
                wav = wav.squeeze(0)
            if wav.shape[0] > 1:
                wav = wav.mean(0, keepdim=True)
            if sample_rate is not None and sample_rate != SAMPLE_RATE:
                wav = resample(wav, sample_rate, SAMPLE_RATE)
        return wav.cpu()

    def _generate(
        self,
        chunks,
        lengths,
        instruments,
        sampling,
        temperature,
        cfg_coef,
        *,
        prompt: list[int] | None,
        max_gen_len: int,
        cancel_event=None,
    ):
        batch = len(chunks)
        if prompt and batch != 1:
            raise ValueError("프롤로그 prompt는 batch_size=1에서만 지원됩니다.")

        conditions = None
        caches = []
        current = None
        additive_mx = None
        logits = None
        token = None
        sequence = None
        eval_items = None
        cache = None
        state = None
        value = None
        conditioned = None
        unconditioned = None
        try:
            if cancel_event is not None and cancel_event.is_set():
                return
            instrument_group = (
                instrument_group_from_names(instruments) if instruments else None
            )
            conditions = self.conditions.encode(
                chunks, lengths, instrument_group, cfg_coef
            )
            if cancel_event is not None and cancel_event.is_set():
                return
            caches = [self._cache() for _ in range(self.core.num_layers)]

            initial = np.full((batch, 1), self.core.card, dtype=np.int32)
            prompt_tokens = list(prompt or [])
            if prompt_tokens:
                current_np = np.concatenate(
                    [initial, np.asarray(prompt_tokens, dtype=np.int32).reshape(1, -1)],
                    axis=1,
                )
            else:
                current_np = initial
            current = mx.array(current_np, dtype=mx.int32)

            for prompt_token in prompt_tokens:
                if cancel_event is not None and cancel_event.is_set():
                    return
                yield np.asarray([prompt_token], dtype=np.int32)

            done = np.zeros((batch,), dtype=bool)
            eos = self.tokenizer.eos_id
            additive = _build_additive_mask(
                self.core.card, self.tokenizer, instruments
            )
            additive_mx = mx.array(additive, dtype=mx.float32)

            remaining = max(0, max_gen_len - len(prompt_tokens))
            for step in range(remaining):
                if cancel_event is not None and cancel_event.is_set():
                    return
                sequence = current
                if cfg_coef != 1.0:
                    sequence = mx.concatenate([current, current], axis=0)
                logits = self.core.forward(
                    sequence, conditions, caches, first_step=(step == 0)
                )[:, -1, :]
                if logits.dtype != mx.float32:
                    logits = logits.astype(mx.float32)
                if cfg_coef != 1.0:
                    conditioned, unconditioned = logits[:batch], logits[batch:]
                    logits = unconditioned + (conditioned - unconditioned) * cfg_coef
                logits = logits + additive_mx

                if self._trace_callback is not None:
                    mx.eval(logits)
                    self._trace_callback(step, logits)

                if sampling:
                    token = mx.random.categorical(logits / temperature)
                else:
                    token = mx.argmax(logits, axis=-1)

                eval_items = [token]
                for cache in caches:
                    state = cache.state
                    if state:
                        eval_items.extend(value for _, value in tree_flatten(state))
                mx.eval(*eval_items)
                row = np.asarray(token.tolist(), dtype=np.int32)
                if cancel_event is not None and cancel_event.is_set():
                    return
                row[done] = eos
                done |= row == eos
                yield row
                if done.all():
                    break
                current = mx.array(row.reshape(batch, 1), dtype=mx.int32)
        finally:
            # Generator.close() lands here on a user cancellation. Drop every
            # per-run MLX reference before clearing the allocator cache.
            caches.clear()
            conditions = None
            current = None
            additive_mx = None
            logits = None
            token = None
            sequence = None
            eval_items = None
            cache = None
            state = None
            value = None
            conditioned = None
            unconditioned = None
            try:
                mx.clear_cache()
            except Exception:
                pass

    def transcribe(
        self,
        audio,
        use_sampling: bool = False,
        temperature: float = 1.0,
        cfg_coef: float = 1.0,
        instruments: list[str] | None = None,
        batch_size: int | None = None,
        no_eos_is_ok: bool = True,
        beam_size: int = 1,
        prelude_forcing: bool = True,
        cancel_event=None,
    ):
        if beam_size != 1:
            raise ValueError("MLX 백엔드는 beam_size=1만 지원합니다.")
        if temperature <= 0:
            raise ValueError("temperature는 0보다 커야 합니다.")
        if batch_size is None:
            batch_size = 1 if prelude_forcing else 4
        if prelude_forcing and batch_size > 1:
            raise ValueError(
                f"batch_size={batch_size}에서는 프롤로그 강제를 사용할 수 없습니다. "
                "프롤로그 강제 호출은 batch_size=1만 지원합니다."
            )

        started = time.perf_counter()
        if isinstance(audio, tuple):
            wav = self._load_wav(audio[0], audio[1])
        else:
            wav = self._load_wav(audio)

        segment = int(SEGMENT_DURATION * SAMPLE_RATE)
        total = wav.shape[-1]
        count = math.ceil(total / segment)
        duration = total / SAMPLE_RATE
        print(
            f"[muscriptor-mlx] audio: {duration:.1f}s → {count} chunk(s) of {SEGMENT_DURATION}s",
            file=sys.stderr,
        )

        chunks, lengths, seek_times = [], [], []
        for index in range(count):
            start = index * segment
            chunk = wav[:, start : start + segment]
            if chunk.shape[-1] < segment:
                chunk = torch_f.pad(chunk, (0, segment - chunk.shape[-1]))
            chunks.append(chunk)
            lengths.append(chunk.shape[-1])
            seek_times.append(index * SEGMENT_DURATION)

        def token_stream():
            tracker = None
            if prelude_forcing and batch_size == 1:
                tracker = OpenNoteTracker(
                    self.tokenizer._vocab, self.tokenizer.frame_rate
                )

            def boundary(index: int):
                next_seek = seek_times[index + 1] if index + 1 < count else None
                return ChunkBoundary(seek_times[index], next_seek)

            for batch_start in range(0, count, batch_size):
                if cancel_event is not None and cancel_event.is_set():
                    return
                batch_chunks = chunks[batch_start : batch_start + batch_size]
                batch_lengths = lengths[batch_start : batch_start + batch_size]
                n = len(batch_chunks)
                buffers = [[] for _ in range(n)]
                done = [False] * n
                active = 0

                first_boundary = boundary(batch_start)
                prompt = None
                if tracker is not None:
                    tracker.feed(first_boundary)
                    if batch_start > 0:
                        prompt = self.tokenizer.tie_section_token_ids(
                            tracker.open_keys()
                        )
                yield first_boundary

                generation = self._generate(
                    batch_chunks,
                    batch_lengths,
                    instruments,
                    use_sampling,
                    temperature,
                    cfg_coef,
                    prompt=prompt,
                    max_gen_len=MAX_GEN_LEN,
                    cancel_event=cancel_event,
                )
                try:
                    for row in generation:
                        if cancel_event is not None and cancel_event.is_set():
                            return
                        for j in range(n):
                            if done[j]:
                                continue
                            value = int(row[j])
                            if value == self.tokenizer.eos_id:
                                done[j] = True
                            else:
                                if tracker is not None:
                                    tracker.feed(value)
                                if j == active:
                                    yield value
                                else:
                                    buffers[j].append(value)
                        while active < n and done[active]:
                            active += 1
                            if active < n:
                                yield boundary(batch_start + active)
                                yield from buffers[active]
                                buffers[active] = []
                finally:
                    close = getattr(generation, "close", None)
                    if callable(close):
                        close()
                    generation = None

                for j in range(active, n):
                    if not done[j]:
                        chunk_index = batch_start + j
                        message = (
                            f"chunk {chunk_index} (seek={seek_times[chunk_index]:.1f}s) "
                            f"did not emit EOS within {MAX_GEN_LEN} tokens"
                        )
                        if no_eos_is_ok:
                            warnings.warn(message, RuntimeWarning, stacklevel=2)
                        else:
                            raise RuntimeError(message)
                    if j != active:
                        yield boundary(batch_start + j)
                        yield from buffers[j]

                yield ProgressEvent(completed=batch_start + n, total=count)
                mx.clear_cache()

        def event_stream():
            token_iterator = None
            decoded_iterator = None
            try:
                if cancel_event is not None and cancel_event.is_set():
                    return
                yield ProgressEvent(completed=0, total=count)
                token_iterator = token_stream()
                decoded_iterator = decode_model_tokens(
                    token_iterator,
                    self.tokenizer._vocab,
                    self._instrument_for_program,
                    frame_rate=self.tokenizer.frame_rate,
                )
                for event in decoded_iterator:
                    if cancel_event is not None and cancel_event.is_set():
                        return
                    yield event
                if cancel_event is None or not cancel_event.is_set():
                    print(
                        f"[muscriptor-mlx] transcribe total: {time.perf_counter() - started:.2f}s "
                        f"({duration:.1f}s audio)",
                        file=sys.stderr,
                    )
            finally:
                for iterator in (decoded_iterator, token_iterator):
                    close = getattr(iterator, "close", None)
                    if callable(close):
                        try:
                            close()
                        except BaseException:
                            pass
                decoded_iterator = None
                token_iterator = None
                chunks.clear()
                lengths.clear()
                seek_times.clear()
                try:
                    mx.synchronize()
                except BaseException:
                    pass
                try:
                    mx.clear_cache()
                except BaseException:
                    pass

        return event_stream()


def load_mlx_model(model_dir: Path, kv_mode: str):
    return MLXTranscriptionModel(model_dir, kv_mode)
