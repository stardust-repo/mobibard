from __future__ import annotations

import gc
import platform
import shutil
import sys
import traceback
from datetime import datetime
from pathlib import Path

import torch

from config import load_settings
from derived_common import validate_derived
from model_store import ensure_original, source_identity
from prompts import ask_yes_no, print_oom_help
from runtime_guard import verify_upstream
from web_runtime import serve

ROOT = Path(__file__).resolve().parents[1]
VALID_BACKENDS = {"auto", "mlx", "official", "cpu"}
MLX_DERIVED_FORMAT = "muscriptor-convenience-mlx-v022-r1"


def _dispatch(model, settings: dict, mode_label: str) -> None:
    if len(sys.argv) > 1:
        raise ValueError(f"알 수 없는 실행 인자입니다: {sys.argv[1:]}")
    serve(model, settings, mode_label)


def _dtype_for_official(precision: str):
    if precision == "auto":
        return None
    if precision == "fp32":
        return "float32"
    if precision == "fp16":
        return "float16"
    raise ValueError("공식 백엔드는 q8 모델 정밀도를 지원하지 않습니다.")


def load_official(weights: Path, device: str, precision: str):
    from muscriptor import TranscriptionModel

    model = TranscriptionModel.load_model(
        weights,
        device=device,
        dtype=_dtype_for_official(precision),
    )
    if precision == "auto":
        if device == "mps":
            effective_precision = "fp16 weights"
        elif device == "cuda":
            effective_precision = "fp32 weights + fp16 autocast"
        else:
            effective_precision = "fp32 weights"
    else:
        effective_precision = f"{precision} weights"
    model._effective_precision = f"official/{effective_precision}"
    model._effective_backend = f"official_{device}"
    model._effective_kv = "official/native"
    return model


def prepare_derived(settings: dict, weights: Path, config: Path, precision: str) -> Path:
    size = settings["model"]["name"]
    target = ROOT / "models" / "derived" / "mlx" / precision / size
    source = source_identity(weights, config)
    valid, reason = validate_derived(
        target,
        expected_format=MLX_DERIVED_FORMAT,
        backend="mlx",
        size=size,
        precision=precision,
        source=source,
    )
    if not valid and target.exists() and any(target.iterdir()):
        print("기존 MLX 파생 모델 무효:", reason)
        auto = bool(settings["runtime"]["rebuild_invalid_derived"])
        if auto or ask_yes_no("기존 파생 모델을 삭제하고 다시 만들까요?", True):
            shutil.rmtree(target, ignore_errors=True)
        else:
            raise RuntimeError("파생 모델 재생성을 취소했습니다.")
    valid, _ = validate_derived(
        target,
        expected_format=MLX_DERIVED_FORMAT,
        backend="mlx",
        size=size,
        precision=precision,
        source=source,
    )
    if not valid:
        from derive_mlx import derive_mlx

        derive_mlx(
            size=size,
            precision=precision,
            source_weights=weights,
            source_config=config,
            source=source,
            output_dir=target,
        )
    return target


def run_mlx(settings: dict, weights: Path, config: Path, precision: str) -> None:
    if settings["decode"]["beam_size"] != 1:
        raise ValueError("MLX 백엔드는 beam_size=1만 지원합니다.")
    from mlx_backend import load_mlx_model

    derived = prepare_derived(settings, weights, config, precision)
    model = load_mlx_model(derived, settings["model"]["kv_cache"])
    _dispatch(
        model,
        settings,
        f"Apple MLX custom / {precision.upper()} / "
        f"{getattr(model, '_effective_kv', 'native').upper()} KV",
    )


def run_official(settings: dict, weights: Path, device: str) -> None:
    requested_precision = settings["model"]["precision"]
    precision = requested_precision
    if device == "cpu" and precision in {"fp16", "q8"}:
        print(
            f"공식 CPU 백엔드는 요청 정밀도 {precision.upper()} 대신 "
            "안정적인 공식 기본 FP32 경로를 사용합니다."
        )
        precision = "auto"
    elif precision == "q8":
        raise ValueError("공식 GPU 백엔드는 q8 모델 정밀도를 지원하지 않습니다.")
    model = load_official(weights, device, precision)
    _dispatch(
        model,
        settings,
        f"official v0.2.2 / {device.upper()} / {precision.upper()}",
    )


def main() -> int:
    verify_upstream()
    settings = load_settings(ROOT)
    backend = settings["model"]["backend"]
    if backend not in VALID_BACKENDS:
        raise ValueError("macOS model.backend는 auto, mlx, official, cpu 중 하나여야 합니다.")
    ask = bool(settings["runtime"]["ask_fallback"])
    size = settings["model"]["name"]
    is_arm = platform.machine().lower() == "arm64"
    weights, config = ensure_original(ROOT, size, ask=ask)

    if backend == "cpu":
        precision = settings["model"]["precision"]
        if precision in {"q8", "fp16"} and platform.machine().lower() == "x86_64":
            precision = "auto"
        effective = {**settings, "model": {**settings["model"], "precision": precision}}
        run_official(effective, weights, "cpu")
        return 0

    if backend == "official":
        device = "mps" if is_arm and torch.backends.mps.is_available() else "cpu"
        run_official(settings, weights, device)
        return 0

    if backend == "mlx" and not is_arm:
        raise RuntimeError("MLX 백엔드는 Apple Silicon(arm64)에서만 지원합니다.")

    if is_arm:
        try:
            import mlx.core as mx

            if not mx.metal.is_available():
                raise RuntimeError("MLX Metal을 사용할 수 없습니다.")
            requested = settings["model"]["precision"]
            precision = "fp16" if requested == "auto" else requested
            try_order = [precision]
            if precision == "q8":
                try_order.extend(["fp16", "fp32"])
            elif precision == "fp16":
                try_order.append("fp32")

            last_error = None
            for index, candidate in enumerate(dict.fromkeys(try_order)):
                if index > 0 and ask and not ask_yes_no(
                    f"MLX {candidate.upper()} 정밀도로 폴백할까요?", True
                ):
                    continue
                try:
                    run_mlx(settings, weights, config, candidate)
                    return 0
                except Exception as exc:
                    last_error = exc
                    traceback.print_exc()
                    print(f"MLX {candidate.upper()} 실행 실패: {exc}")
                    text = str(exc).lower()
                    if "memory" in text or "metal" in text:
                        print_oom_help(size, settings["decode"]["batch_size"])
                    try:
                        mx.clear_cache()
                    except Exception:
                        pass
                    gc.collect()
            if last_error is not None:
                print("모든 MLX 후보가 실패했습니다:", last_error)
        except Exception as exc:
            traceback.print_exc()
            print("MLX 초기화 실패:", exc)

    if backend == "mlx":
        return 2

    if is_arm and torch.backends.mps.is_available() and (
        not ask or ask_yes_no("공식 MPS 백엔드로 실행할까요?", True)
    ):
        precision = settings["model"]["precision"]
        if precision == "q8":
            precision = "auto"
        effective = {**settings, "model": {**settings["model"], "precision": precision}}
        try:
            run_official(effective, weights, "mps")
            return 0
        except Exception as exc:
            print("공식 MPS 실행도 실패했습니다:", exc)

    if not ask or ask_yes_no("공식 CPU 백엔드로 실행할까요?", True):
        precision = settings["model"]["precision"]
        if precision in {"q8", "fp16"}:
            precision = "auto"
        effective = {**settings, "model": {**settings["model"], "precision": precision}}
        run_official(effective, weights, "cpu")
        return 0
    return 2


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except SystemExit:
        raise
    except Exception as exc:
        log_dir = ROOT / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_path = log_dir / f"run_error_{datetime.now():%Y%m%d_%H%M%S}.log"
        details = traceback.format_exc()
        log_path.write_text(details, encoding="utf-8")
        print(details)
        print(f"[실행 실패] {exc}")
        print(f"전체 오류 로그: {log_path}")
        raise SystemExit(1)
