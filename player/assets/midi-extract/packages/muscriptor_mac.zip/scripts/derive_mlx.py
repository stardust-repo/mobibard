from __future__ import annotations

import gc
import json
import shutil
from pathlib import Path

import mlx.core as mx
import torch
from safetensors import safe_open
from safetensors.torch import save_file

from derived_common import (
    is_condition_key,
    is_ffn_weight,
    manifest_header,
    remap_key,
    validate_derived,
)

FORMAT = "muscriptor-convenience-mlx-v022-r1"
Q8_GROUP_SIZE = 64
Q8_BITS = 8
Q8_MODE = "affine"


def derive_mlx(
    *,
    size: str,
    precision: str,
    source_weights: Path,
    source_config: Path,
    source: dict,
    output_dir: Path,
) -> Path:
    valid, _ = validate_derived(
        output_dir,
        expected_format=FORMAT,
        backend="mlx",
        size=size,
        precision=precision,
        source=source,
    )
    if valid:
        return output_dir
    if precision not in {"fp32", "fp16", "q8"}:
        raise ValueError("MLX 파생 정밀도는 fp32, fp16, q8 중 하나여야 합니다.")
    if not mx.metal.is_available():
        raise RuntimeError("MLX Metal을 사용할 수 없습니다.")

    mx.set_default_device(mx.gpu)
    building = output_dir.with_name(output_dir.name + ".building")
    shutil.rmtree(building, ignore_errors=True)
    (building / "weights").mkdir(parents=True, exist_ok=True)
    shutil.copy2(source_config, building / "config.json")

    token_dtype = "float32" if precision == "fp32" else "float16"
    print(f"\n[{size}] MLX {precision.upper()} 파생 모델 생성")
    print("- 공식 v0.2.2 프롤로그 강제/악기 하드 마스크 이식")
    print("- conditioner: CPU FP32")
    print(f"- token round: {token_dtype}")
    if precision == "q8":
        print("- Q8 범위: transformer FFN linear1/linear2만")
        print(
            f"- MLX affine packed Q8: group_size={Q8_GROUP_SIZE}, bits={Q8_BITS}"
        )

    entries: list[dict] = []
    with safe_open(source_weights, framework="pt", device="cpu") as handle:
        keys = list(handle.keys())
        for index, source_key in enumerate(keys, 1):
            key = remap_key(source_key)
            tensor = handle.get_tensor(source_key)
            filename = f"{index:05d}.safetensors"
            path = building / "weights" / filename
            entry = {
                "name": key,
                "file": f"weights/{filename}",
                "shape": list(tensor.shape),
            }

            if precision == "q8" and is_ffn_weight(key):
                if tensor.shape[-1] % Q8_GROUP_SIZE != 0:
                    raise RuntimeError(
                        f"{key} 입력 차원 {tensor.shape[-1]}은 "
                        f"group_size={Q8_GROUP_SIZE}로 나누어지지 않습니다."
                    )
                source_weight = mx.array(
                    tensor.to(torch.float16).contiguous().numpy()
                )
                weight, scales, biases = mx.quantize(
                    source_weight,
                    group_size=Q8_GROUP_SIZE,
                    bits=Q8_BITS,
                    mode=Q8_MODE,
                )
                items = {"weight": weight, "scales": scales}
                if biases is not None:
                    items["biases"] = biases
                    mx.eval(weight, scales, biases)
                else:
                    mx.eval(weight, scales)
                mx.save_safetensors(str(path), items)
                entry.update(
                    kind="mlx_q8_ffn",
                    quantization={
                        "group_size": Q8_GROUP_SIZE,
                        "bits": Q8_BITS,
                        "mode": Q8_MODE,
                    },
                )
                del source_weight, weight, scales, biases
            else:
                if is_condition_key(key) or precision == "fp32":
                    stored = tensor.float().contiguous()
                    kind = "fp32"
                else:
                    stored = tensor.to(torch.float16).contiguous()
                    kind = "fp16"
                save_file({"value": stored}, path)
                entry.update(kind=kind)
                del stored

            entries.append(entry)
            del tensor
            if index % 20 == 0 or index == len(keys):
                print(f"  {index}/{len(keys)} tensors")
                gc.collect()
                mx.clear_cache()

    manifest = {
        **manifest_header(backend="mlx", size=size, precision=precision, source=source),
        "format": FORMAT,
        "effective_precision": precision,
        "token_dtype": token_dtype,
        "condition_compute": "cpu_fp32",
        "position_embedding": "dynamic fp32 sinusoid, cast once at transformer boundary",
        "q8_scope": "transformer FFN linear1 + linear2 only" if precision == "q8" else "none",
        "q8_runtime": "mx.quantized_matmul" if precision == "q8" else None,
        "entries": entries,
    }
    (building / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    shutil.rmtree(output_dir, ignore_errors=True)
    output_dir.parent.mkdir(parents=True, exist_ok=True)
    building.replace(output_dir)
    return output_dir
