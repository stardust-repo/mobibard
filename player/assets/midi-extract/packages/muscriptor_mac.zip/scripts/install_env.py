from __future__ import annotations

import importlib.metadata
import os
import platform
import subprocess
import sys
import traceback
from datetime import datetime
from pathlib import Path

from constants import UPSTREAM_VERSION

ROOT = Path(__file__).resolve().parents[1]
LOG_DIR = ROOT / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)
LOG_PATH = LOG_DIR / f"install_{datetime.now():%Y%m%d_%H%M%S}.log"


def run(command: list[str], *, allow_failure: bool = False) -> bool:
    print("\n>", " ".join(command))
    with LOG_PATH.open("a", encoding="utf-8") as log:
        log.write("\n> " + " ".join(command) + "\n")
        process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            env={**os.environ, "PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8"},
        )
        assert process.stdout is not None
        for line in process.stdout:
            print(line, end="")
            log.write(line)
        code = process.wait()
    if code != 0 and not allow_failure:
        raise RuntimeError(f"명령 실패({code}): {' '.join(command)}")
    return code == 0


def version_of(name: str) -> str:
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return "미설치"


def main() -> int:
    machine = platform.machine().lower()
    if sys.version_info < (3, 10):
        raise RuntimeError("Python 3.10 이상이 필요합니다.")
    if machine == "x86_64" and sys.version_info >= (3, 13):
        raise RuntimeError("Intel Mac은 Python 3.12 이하를 사용해야 합니다.")

    print("Python:", sys.version.replace("\n", " "))
    print("실행 파일:", sys.executable)
    print("Architecture:", machine)
    print("설치 로그:", LOG_PATH)
    pip = [sys.executable, "-m", "pip"]
    run(pip + ["install", "--upgrade", "pip", "setuptools", "wheel"])

    if machine == "x86_64":
        run(pip + ["install", "--upgrade", "numpy<2", "torch<2.3"])

    run(
        pip
        + [
            "install",
            "--upgrade",
            f"muscriptor=={UPSTREAM_VERSION}",
            "beat-this>=1.1",
            "huggingface_hub>=0.34",
            "safetensors>=0.4",
            "tomli>=2.0; python_version<'3.11'",
        ]
    )

    if machine == "arm64":
        run(
            pip
            + [
                "install",
                "--upgrade",
                "mlx==0.32.0",
                "mlx-lm==0.31.3",
            ]
        )
    else:
        print("Intel Mac에서는 MLX를 설치하지 않고 공식 CPU 백엔드를 사용합니다.")

    from runtime_guard import find_web_dir, verify_upstream

    verify_upstream()
    import torch

    print("\n[설치 확인]")
    print("muscriptor:", version_of("muscriptor"))
    print("PyTorch:", torch.__version__)
    print("MPS available:", torch.backends.mps.is_available())
    if machine == "arm64":
        import mlx.core as mx

        print("MLX:", version_of("mlx"))
        print("MLX-LM:", version_of("mlx-lm"))
        print("Metal available:", mx.metal.is_available())
        if mx.metal.is_available():
            print("Metal device:", mx.metal.device_info())
    print("최신 호환 웹 UI:", find_web_dir() or "누락")
    if find_web_dir() is None:
        raise RuntimeError(
            "설치된 MuScriptor 패키지에 web_dist가 없습니다. "
            "PyPI의 공식 0.3.0 wheel을 설치했는지 확인하세요."
        )
    print("\n환경 설치가 완료되었습니다.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception:
        traceback.print_exc()
        print(f"\n[설치 실패] 전체 로그: {LOG_PATH}")
        raise SystemExit(1)
